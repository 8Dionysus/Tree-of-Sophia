# Local Item adoption forensic boundary

File: tos.file.synthetic.first
SHA-256: a41b5db58acb034720442d84e053fc857af0607db8635e84693dbecaa919342f
Retains one unchanged previously acquired local file; the input is preserved.
The inventory enumerates resources only. No OCR, correction, translation, source reading,
copyright clearance, publication authorization or semantic acceptance was performed.
Copy and metadata publication are separate stages; retained transaction evidence owns recovery.
