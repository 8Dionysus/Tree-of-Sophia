"""Bounded source-metadata correction with exact retained source packages.

Called only by the separately delegated source command route. No admission,
claim rewriting, model execution, payload access or graph publication.
"""
from datetime import datetime, timezone
import ctypes
import errno
import json
import os
from pathlib import Path
import stat
import tempfile

import source_commands as source
import source_command_contracts as contract

HISTORY = 'source-revision-history.json'
MAX_PACKAGE_BYTES = 8 * 1024 * 1024
MAX_FILES = 64
MAX_REVISIONS = 128
SELECTED_PROTOCOL = 'tos_selected_source_metadata_v1'


def _encode(value):
    return (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + '\n').encode()


def _selected(config):
    return config.get('schema_version') in source.SELECTED_REVISION_CONFIGS


def _package(directory, *, archive=False):
    """Fail closed on non-flat packages, symlinks and over-budget metadata."""
    os.close(source._owned_path(directory, directory=True))
    before = directory.stat()
    paths = sorted(directory.iterdir())
    if not 1 <= len(paths) <= MAX_FILES + int(archive):
        raise ValueError('source package file-count budget exceeded')
    files, total = {}, 0
    for path in paths:
        if not stat.S_ISREG(path.lstat().st_mode):
            raise PermissionError('revision requires a flat regular-file metadata package')
        raw = source._read(path, source.MAX_SET_BYTES)
        total += len(raw)
        if total > MAX_PACKAGE_BYTES + (source.MAX_SET_BYTES if archive else 0):
            raise ValueError('source package byte budget exceeded')
        files[path.name] = raw
    after = directory.stat()
    if (before.st_ino, before.st_mtime_ns, before.st_ctime_ns) != (after.st_ino, after.st_mtime_ns, after.st_ctime_ns):
        raise source.JournalConflict('source package changed during inspection')
    return files


def _file_refs(files):
    return {name: {'sha256': source._digest(raw), 'bytes': len(raw)} for name, raw in files.items()}


def _selected_names(path):
    """A v2 publication unit, never an implicit redefinition of a v1 package."""
    return (path.name, path.stem + '.human-forms.json', HISTORY)


def _selected_package(path):
    """Read only the exact record/form/history files; do not enumerate children."""
    descriptor = source._owned_path(path.parent, directory=True)
    try:
        before = os.fstat(descriptor)
        files = {}
        for name in _selected_names(path):
            target = path.parent / name
            try:
                raw = source._read(target, source.MAX_SET_BYTES)
            except FileNotFoundError:
                if name == path.name:
                    raise
                continue
            files[name] = raw
        after = os.fstat(descriptor)
        current = path.parent.stat()
        if ((before.st_dev, before.st_ino, before.st_mtime_ns, before.st_ctime_ns)
                != (after.st_dev, after.st_ino, after.st_mtime_ns, after.st_ctime_ns)
                or (after.st_dev, after.st_ino) != (current.st_dev, current.st_ino)):
            raise source.JournalConflict('selected metadata parent changed during inspection')
        if sum(map(len, files.values())) > MAX_PACKAGE_BYTES:
            raise ValueError('selected source metadata exceeds its byte budget')
        return files
    finally:
        os.close(descriptor)


def _revision(files):
    return source._digest(source._canonical(_file_refs(files)))


def _history(files, record):
    subject = source.metadata_subject(record)
    history = source._json_object(files[HISTORY]) if HISTORY in files else {
        'schema_version': 'tos_source_revision_history_v1', 'record_id': subject.id, 'receipts': []}
    source._keys(history, {'schema_version', 'record_id', 'receipts'})
    if (history['schema_version'] not in {'tos_source_revision_history_v1', 'tos_source_revision_history_v2'}
            or history['record_id'] != subject.id
            or not isinstance(history['receipts'], list) or len(history['receipts']) > MAX_REVISIONS):
        raise source.JournalCorruption('invalid source revision history')
    if HISTORY in files and not history['receipts']:
        raise source.JournalCorruption('stored source revision history requires at least one receipt')
    previous, commands = None, set()
    for receipt in history['receipts']:
        selected = 'publication' in receipt
        if selected and history['schema_version'] != 'tos_source_revision_history_v2':
            raise source.JournalCorruption('selected metadata needs explicit v2 retained history')
        source._keys(receipt, {'command_id', 'request_digest', 'principal_id', 'authority_ref',
            'owner_configuration', 'recorded_at', 'reason', 'previous_source', 'source',
            'previous_revision', 'archive_path', 'dependencies', 'changed_fields', 'forms', 'grants_admission', 'request'}
            | ({'publication'} if selected else set()))
        if selected:
            publication = receipt['publication']
            source._keys(publication, {'protocol', 'transaction_id', 'selected_files'})
            names = publication['selected_files']
            if (publication['protocol'] != SELECTED_PROTOCOL
                    or not isinstance(publication['transaction_id'], str)
                    or not isinstance(names, list) or len(names) != 3
                    or any(not isinstance(name, str) or Path(name).name != name for name in names)
                    or len(set(names)) != 3 or HISTORY not in names):
                raise source.JournalCorruption('invalid selected metadata publication binding')
        source._instant(receipt['recorded_at'])
        if receipt['request'].get('operation') == 'work.expression.create':
            from source_expression_commands import validate_parent_receipt
            validate_parent_receipt(receipt)
        if receipt['request'].get('operation') == 'expression.responsibility.attach':
            from source_responsibility_commands import validate_parent_receipt
            validate_parent_receipt(receipt)
        if receipt['request'].get('operation') == 'expression.edition.create':
            from source_edition_commands import validate_parent_receipt
            validate_parent_receipt(receipt)
        if receipt['request'].get('operation') == 'item.adopt':
            from source_item_commands import validate_parent_receipt
            validate_parent_receipt(receipt)
        if receipt['request'].get('operation') == 'collection.work.attach':
            from source_collection_commands import validate_parent_receipt
            validate_parent_receipt(receipt)
        if (not isinstance(receipt['command_id'], str) or receipt['command_id'] in commands
                or source._digest(source._canonical(receipt['request'])) != receipt['request_digest']
                or receipt['command_id'] != receipt['request']['command_id']
                or receipt['previous_source'] != receipt['request']['expected_source']
                or receipt['previous_revision'] != receipt['request']['expected_revision']
                or receipt['owner_configuration'] != receipt['request']['expected_configuration']
                or receipt['dependencies'] != receipt['request']['expected_dependencies']
                or receipt['reason'] != receipt['request']['reason']
                or receipt['changed_fields'] != sorted(receipt['request']['fields'])
                or receipt['grants_admission'] is not False
                or receipt['source']['id'] != subject.id
                or receipt['previous_source']['id'] != subject.id
                or receipt['source']['version'] != receipt['previous_source']['version'] + 1
                or previous is not None and receipt['previous_source'] != previous):
            raise source.JournalCorruption('broken source revision lineage')
        commands.add(receipt['command_id'])
        previous = receipt['source']
    if previous is not None and previous != subject.ref:
        raise source.JournalCorruption('current source is not the retained revision head')
    return history


def _validate_record(config, record):
    root = Path(config['source_root'])
    if config['schema_version'] == source.NATIVE_METADATA_REVISION_CONFIG:
        from source_native_metadata_commands import validate_record
        return validate_record(config, record)
    if config['schema_version'] in {source.CORPUS_REVISION_CONFIG, *source.CORPUS_SELECTED_REVISION_CONFIGS}:
        profile = source._configured_corpus_profile(config)
        schema_raw = source._read(root / profile['schema_ref'], source.MAX_COMMAND_BYTES)
        schema = source._json_object(schema_raw)
        source.Draft202012Validator.check_schema(schema)
        source.Draft202012Validator(schema, format_checker=source.FormatChecker()).validate(record)
        if (record['schema_version'] != profile['schema_version'] or record['record_type'] != profile['record_type']
                or record['record_id'] != config['record_id']):
            raise PermissionError('native correction must match the exact delegated Corpus descriptor')
        return {profile['schema_ref']: source._digest(schema_raw)}
    if config['schema_version'] in source.PROFILE_REVISION_CONFIGS:
        profiles, profile = source._configured_profile(config)
        profiles.validate(profile['record_type'], record)
        return source._profile_input_snapshot(profiles)
    if record.get('schema_version') != 'tos_historical_record_v1':
        raise PermissionError('legacy revision requires the historical source schema')
    from source_witness_bibliographic_graph_common import historical_schema_validator
    historical_schema_validator(root).validate(record)
    return {path: source._digest(source._read(root / path, source.MAX_SET_BYTES))
            for path in ('ToS/contracts/historical-record.schema.json', 'ToS/contracts/corpus-record.schema.json')}


def _dependencies(config, record):
    inputs = _validate_record(config, record)
    for path in ('mechanics/growth-cycle/parts/branch-growth-cycle/scripts/source_commands.py', contract.MODULE_REF,
                 'mechanics/growth-cycle/parts/branch-growth-cycle/scripts/source_revisions.py',
                 'mechanics/growth-cycle/parts/branch-growth-cycle/scripts/human_forms.py',
                 'mechanics/growth-cycle/parts/branch-growth-cycle/scripts/knowledge_assessment.py',
                 'scripts/source_record_profiles.py', 'scripts/native_text_binding.py', 'scripts/source_owner_context.py',
                 'scripts/source_witness_human_forms.py',
                 'ToS/contracts/human-form.schema.json', 'ToS/contracts/human-form-set.schema.json',
                 'ToS/contracts/human-form-template.schema.json'):
        inputs[path] = source._digest(source._read(source.ROOT / path, source.MAX_SET_BYTES))
    if _selected(config):
        for path in ('scripts/source_metadata_snapshot.py',
                     'mechanics/growth-cycle/parts/branch-growth-cycle/scripts/source_metadata_transactions.py',
                     'mechanics/growth-cycle/parts/branch-growth-cycle/scripts/source_selected_revisions.py'):
            inputs[path] = source._digest(source._read(source.ROOT / path, source.MAX_SET_BYTES))
    return source._digest(source._canonical(inputs))


def _scope(config, request, *, operation='record.revise'):
    if operation not in config['allowed_operations']:
        raise PermissionError('record revision is not delegated')
    fields = request['fields']
    if not isinstance(fields, dict) or not fields or not set(fields) <= set(config['allowed_fields']):
        raise PermissionError('source field correction is outside delegated scope')
    selections = request['forms']
    if not isinstance(selections, list) or not 1 <= len(selections) <= 32:
        raise ValueError('source revision requires bounded form selections')
    identifiers = set()
    for item in selections:
        source._keys(item, {'form_id', 'field_id'})
        if item['form_id'] not in config['allowed_form_ids']:
            raise PermissionError('source revision form identity is not delegated')
        if item['form_id'] in identifiers:
            raise ValueError('duplicate revision form identity')
        identifiers.add(item['form_id'])
    if not isinstance(request['reason'], str) or not 1 <= len(request['reason'].strip()) <= 4096:
        raise ValueError('revision requires a bounded authored reason')


def _proposal(config, path, files, record, request, *, scope_operation='record.revise'):
    _scope(config, request, operation=scope_operation)
    revised = {**record, **request['fields'], 'record_version': record['record_version'] + 1}
    _validate_record(config, revised)
    if config['schema_version'] == source.NATIVE_METADATA_REVISION_CONFIG:
        from source_native_metadata_commands import validate_descriptive_delta
        validate_descriptive_delta(record, revised, config['record_type'])
    subject = source.metadata_subject(revised)
    formname = path.stem + '.human-forms.json'
    payload = source._json_object(files[formname]) if formname in files else None
    if payload is not None:
        source._validate_history(payload)
        if {form['form_id'] for form in payload['forms']} - {item['form_id'] for item in request['forms']}:
            raise ValueError('revision must explicitly rebind every current form')
    changes = [source.prepare_metadata_change(revised, payload, config['principal_id'], **item) for item in request['forms']]
    value = source._apply(payload, subject, changes)
    views = source.materialize_metadata_forms(revised, value, access_allowed=True)
    if not all(view['state'] == 'ready' for view in views) or not any(view['role'] == 'name' for view in views):
        raise ValueError('revision forms must be ready source copies including a name')
    output = {**files, path.name: _encode(revised), formname: _encode(value)}
    if len(output[path.name]) > source.MAX_COMMAND_BYTES:
        raise ValueError('revised source record exceeds the existing metadata reader budget')
    return revised, subject, output, views, [source._form_ref(change['form']) for change in changes]


def _archive_path(config, revision):
    identifier = source._digest(config['record_id'].encode()).removeprefix('sha256:')
    return Path('ToS/source-witnesses/.record-revisions') / (identifier + '-' + revision.removeprefix('sha256:'))


def _read_archive_files(root, config, receipt):
    """Verify a byte-bound package independently of its selected record shape."""
    relative = _archive_path(config, receipt['previous_revision'])
    if receipt['archive_path'] != relative.as_posix():
        raise source.JournalCorruption('archive locator is not derived from exact subject and package')
    directory = root / relative
    contents = _package(directory, archive=True)
    manifest = source._json_object(contents.pop('manifest.json'))
    selected = manifest.get('schema_version') == 'tos_source_package_archive_v2'
    source._keys(manifest, {'schema_version', 'source_path', 'source', 'revision', 'files'}
                 | ({'publication_protocol'} if selected else set()))
    if (manifest['schema_version'] not in {'tos_source_package_archive_v1', 'tos_source_package_archive_v2'}
            or selected and manifest['publication_protocol'] != SELECTED_PROTOCOL
            or manifest['source_path'] != config['source_path']
            or manifest['source'] != receipt['previous_source'] or manifest['revision'] != receipt['previous_revision']
            or not isinstance(manifest['files'], dict)):
        raise source.JournalCorruption('archive metadata does not bind the requested revision')
    restored, locations = {}, {}
    for name, binding in manifest['files'].items():
        source._keys(binding, {'blob', 'sha256', 'bytes'})
        blob = binding['blob']
        if (not isinstance(name, str) or Path(name).name != name
                or blob != binding['sha256'].removeprefix('sha256:') + '.blob'
                or blob not in contents or source._digest(contents[blob]) != binding['sha256']
                or len(contents[blob]) != binding['bytes']):
            raise source.JournalCorruption('archive byte binding is invalid')
        restored[name] = contents[blob]
        locations[name] = {'archive_path': (relative / blob).as_posix(), 'sha256': binding['sha256'], 'bytes': binding['bytes']}
    if selected and (not set(restored) <= set(_selected_names(Path(config['source_path'])))
                     or Path(config['source_path']).name not in restored):
        raise source.JournalCorruption('selected archive exceeds its exact metadata scope')
    if _revision(restored) != receipt['previous_revision']:
        raise source.JournalCorruption('archive package digest is invalid')
    if set(contents) != {binding['blob'] for binding in manifest['files'].values()}:
        raise source.JournalCorruption('archive contains unbound files')
    return restored, locations


def _read_archive(root, config, receipt):
    restored, locations = _read_archive_files(root, config, receipt)
    old = source._json_object(restored[Path(config['source_path']).name])
    if source.metadata_subject(old).ref != receipt['previous_source']:
        raise source.JournalCorruption('archived source bytes do not bind the previous source ref')
    if 'request' in receipt:
        revised = {**old, **receipt['request']['fields'], 'record_version': old['record_version'] + 1}
        if source.metadata_subject(revised).ref != receipt['source']:
            raise source.JournalCorruption('retained request does not produce the recorded source successor')
    return restored, locations


def _verify_record_history(files, record, source_path, read_archive):
    """Verify the retained predecessor closure before extending a record chain.

    The caller supplies its own public or protected archive reader. Each read
    verifies the complete package bytes and reconstructs the successor. Compare
    the archived receipt prefix too: a shortened current ledger must not turn
    an already revised record into a fresh historical baseline.
    """
    history = _history(files, record)
    basename = Path(source_path).name
    for index, receipt in enumerate(history['receipts']):
        archived, _ = read_archive(receipt)
        previous = source._json_object(archived[basename])
        previous_history = _history(archived, previous)
        if previous_history['receipts'] != history['receipts'][:index]:
            raise source.JournalCorruption('retained record history differs from its archived predecessor prefix')
    return history


def _stage(root, files, prefix):
    staging = Path(tempfile.mkdtemp(prefix=prefix, suffix='.pending', dir=root / 'ToS'))
    try:
        for name, raw in files.items():
            source._publish(staging / name, raw)
    except BaseException:
        # Abrupt process loss leaves this exact staging outside source scanners.
        # Ordinary exception cleanup concerns only files created in this call.
        _discard_staging(staging, files)
        raise
    return staging


def _discard_staging(staging, files):
    if staging.exists():
        for name in files:
            (staging / name).unlink(missing_ok=True)
        staging.rmdir()


def _archive(root, config, files, subject, revision, *, reader=None):
    if reader is None:
        _verify_record_history(files, subject.payload, config['source_path'],
                               lambda receipt: _read_archive(root, config, receipt))
    reader = reader or _read_archive
    relative = _archive_path(config, revision)
    receipt = {'archive_path': relative.as_posix(), 'previous_source': subject.ref, 'previous_revision': revision}
    if (root / relative).exists():
        if reader(root, config, receipt)[0] != files:
            raise source.JournalCorruption('existing archive does not preserve this package')
        return relative
    target = root / relative
    target.parent.mkdir(mode=0o700, exist_ok=True)
    os.close(source._owned_path(target.parent, directory=True))
    source._sync_directory(target.parent.parent)
    refs = {name: {**binding, 'blob': binding['sha256'].removeprefix('sha256:') + '.blob'}
            for name, binding in _file_refs(files).items()}
    archived = {refs[name]['blob']: raw for name, raw in files.items()}
    archived['manifest.json'] = _encode({
        'schema_version': 'tos_source_package_archive_v2' if _selected(config) else 'tos_source_package_archive_v1',
        'source_path': config['source_path'], 'source': subject.ref, 'revision': revision, 'files': refs,
        **({'publication_protocol': SELECTED_PROTOCOL} if _selected(config) else {})})
    staging = _stage(root, archived, '.source-archive-')
    try:
        source._publish_new_directory(staging, target)
    finally:
        _discard_staging(staging, archived)
    if reader(root, config, receipt)[0] != files:
        raise source.JournalCorruption('stored archive differs from prior source bytes')
    return relative


def _exchange(staging, target):
    """Linux directory exchange; no non-atomic multi-file fallback."""
    libc = ctypes.CDLL(None, use_errno=True)
    try:
        rename = libc.renameat2
    except AttributeError:
        raise OSError(errno.ENOSYS, 'atomic directory exchange unavailable') from None
    rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
    rename.restype = ctypes.c_int
    if rename(-100, os.fsencode(staging), -100, os.fsencode(target), 2) != 0:
        code = ctypes.get_errno()
        raise OSError(code, os.strerror(code))
    source._sync_directory(target.parent)
    source._sync_directory(staging.parent)


def run_revision(owner, config, configuration, path, request):
    if _selected(config):
        from source_selected_revisions import run_selected_revision
        return run_selected_revision(owner, config, configuration, path, request)
    root = Path(config['source_root'])
    operation = request.get('operation')
    source.command_handler(config['schema_version']).validate_request(request)

    def inspect():
        files = _package(path.parent)
        record = source._json_object(files[path.name])
        if (record.get('record_id') != config['record_id']
                or config['schema_version'] != source.CORPUS_REVISION_CONFIG
                and record.get('visibility') not in {'public', 'public_metadata_only'}):
            raise PermissionError('source revision subject or visibility is outside this adapter')
        # Corpus has no visibility extension. Its exact schema and this explicit
        # public-metadata adapter are required; it is not a default for other schemas.
        _validate_record(config, record)
        subject = source.Record.from_payload(record['record_id'], record['record_version'], record)
        history = _history(files, record)
        return files, record, subject, history

    def result(files, record, subject, receipt=None, replayed=False):
        formname = path.stem + '.human-forms.json'
        payload = source._json_object(files[formname]) if formname in files else None
        return {'schema_version': 'tos_local_source_revision_result_v1', 'authentication': 'local-unix-account',
            'owner_configuration': configuration, 'source_path': config['source_path'], 'source': subject.ref,
            'revision': _revision(files), 'command_operations': ['describe', 'prepare-revise', 'record.revise', 'inspect-version'],
            'supported_operations': ['record.revise'], 'allowed_operations': config['allowed_operations'],
            'allowed_fields': config['allowed_fields'], 'allowed_form_ids': config['allowed_form_ids'],
            **({'profile_type_id': config['profile_type_id'],
                'source_record_profile': source._configured_profile(config)[1]}
               if config['schema_version'] in source.PROFILE_REVISION_CONFIGS else {}),
            **({'record_type': config['record_type'], 'source_profile': source._configured_corpus_profile(config)}
               if config['schema_version'] == source.CORPUS_REVISION_CONFIG else {}),
            'receipt': receipt, 'replayed': replayed, 'grants_admission': False,
            'materializations': source.materialize_metadata_forms(record, payload, access_allowed=True) if payload else []}

    files, record, subject, history = inspect()
    if operation == 'describe':
        return result(files, record, subject)
    if operation == 'inspect-version':
        for receipt in history['receipts']:
            if receipt['previous_source'] == request['source']:
                archived, locations = _read_archive(root, config, receipt)
                return {**result(files, record, subject), 'record': source._json_object(archived[path.name]),
                        'inspected_source': request['source'], 'files': locations}
        raise source.JournalConflict('requested exact source version is not retained in committed history')
    _scope(config, request)  # Scope revocation applies even to a retry.
    if operation == 'prepare-revise':
        if len(history['receipts']) >= MAX_REVISIONS:
            raise ValueError('source revision history capacity reached')
        revised, proposed, _, views, refs = _proposal(config, path, files, record, request)
        return {**result(files, record, subject), 'prepared_source': proposed.ref, 'prepared_forms': refs,
                'prepared_materializations': views, 'expected_dependencies': _dependencies(config, record)}
    if not isinstance(request['command_id'], str) or not 1 <= len(request['command_id']) <= 256:
        raise ValueError('invalid source revision command identity')
    digest = source._digest(source._canonical(request))
    with source._locked(root / 'ToS/source-witnesses/historical-create'):
        latest, latest_digest, latest_path = source._configuration(owner)
        if latest_digest != configuration or latest_path != path:
            raise source.JournalConflict('revision delegation changed before transaction')
        files, record, subject, history = inspect()
        for receipt in history['receipts']:
            if receipt['command_id'] == request['command_id']:
                if receipt['request_digest'] != digest:
                    raise source.JournalConflict('source revision command identity was reused')
                _read_archive(root, config, receipt)
                source._sync_directory(path.parent.parent)
                return result(files, record, subject, receipt, True)
        revision, dependencies = _revision(files), _dependencies(config, record)
        if (request['expected_configuration'] != configuration or request['expected_source'] != subject.ref
                or request['expected_revision'] != revision or request['expected_dependencies'] != dependencies):
            raise source.JournalConflict('source revision snapshot or dependencies are stale')
        if len(history['receipts']) >= MAX_REVISIONS:
            raise ValueError('source revision history capacity reached; retain history and route to archive reader')
        revised, proposed, output, views, refs = _proposal(config, path, files, record, request)
        archive = _archive_path(config, revision)
        receipt = {'command_id': request['command_id'], 'request_digest': digest,
            'principal_id': config['principal_id'], 'authority_ref': config['authority_ref'],
            'owner_configuration': configuration, 'recorded_at': datetime.now(timezone.utc).isoformat(),
            'reason': request['reason'], 'previous_source': subject.ref, 'source': proposed.ref,
            'previous_revision': revision, 'archive_path': archive.as_posix(), 'dependencies': dependencies,
            'changed_fields': sorted(request['fields']), 'forms': refs, 'grants_admission': False, 'request': request}
        output[HISTORY] = _encode({**history, 'receipts': [*history['receipts'], receipt]})
        if (len(output) > MAX_FILES or any(len(raw) > source.MAX_SET_BYTES for raw in output.values())
                or sum(map(len, output.values())) > MAX_PACKAGE_BYTES):
            raise ValueError('revised source package exceeds its byte or file-count budget')
        _archive(root, config, files, subject, revision)
        staging = _stage(root, output, '.source-revision-')
        try:
            if (_package(path.parent) != files or source._configuration(owner)[1] != configuration
                    or _dependencies(config, record) != dependencies):
                raise source.JournalConflict('source revision inputs changed before publication')
            _verify_record_history(files, record, config['source_path'],
                                   lambda previous: _read_archive(root, config, previous))
            _exchange(staging, path.parent)
        finally:
            # If exchange completed even when its response/fsync failed, this
            # contains OLD bytes. Remove only an exact, independently verified
            # duplicate of the retained archive; otherwise leave it for recovery.
            if staging.exists():
                remaining = _package(staging)
                if remaining == files and _read_archive(root, config, receipt)[0] == files:
                    _discard_staging(staging, files)
                elif remaining == output:
                    _discard_staging(staging, output)
        return result(output, revised, proposed, receipt)


def command_handlers():
    proposal = {'fields', 'forms', 'reason'}
    operations = (contract.describe(),
        contract.operation('prepare-revise', proposal, definition='Prepare explicitly selected descriptive fields and source-copy form successors.', grants=('record.revise',)),
        contract.operation('record.revise', proposal | contract.COMMIT_KEYS,
            definition='Publish one exact flat metadata-package successor and retain its predecessor.', mutation='record_successor', grants=('record.revise',)),
        contract.inspect_version())
    return tuple(contract.Handler(identifier, (schema,), operations, run_revision, definition,
        typed_handles=(*handles, *contract.FORM_HANDLES),
        profile_selection=selection,
        preconditions=('Existing flat source package and separately selected descriptive fields; identity and bibliography link fields are not generic corrections.',))
        for identifier, schema, definition, handles, selection in (
            ('historical-source-revision', source.REVISION_CONFIG, 'Correct one historical source record.',
             ('ToS/contracts/historical-record.schema.json',), 'HistoricalEvent, HistoricalProcess or HistoricalState under its exact source schema.'),
            ('public-profile-revision', source.PROFILE_REVISION_CONFIG, 'Correct one declared public metadata profile.',
             contract.RECORD_HANDLES, 'Explicit profile_type_id selects the existing source_record_profile and schema, not write authority.'),
            ('public-profile-scope-revision', source.PROFILE_SCOPE_REVISION_CONFIG,
             'Revise an explicitly selected research scope description while retaining its subject and history.',
             contract.RECORD_HANDLES,
             'Explicit profile_type_id and semantic_scope field delegation select a source-reviewed wording correction.'),
            ('native-corpus-flat-revision', source.CORPUS_REVISION_CONFIG, 'Correct standalone native public metadata in a flat source home.',
             ('ToS/contracts/corpus-record.schema.json',), 'Agent, Place, Organization or Work; nested selected-file correction is a separate v2 grant.')))
