"""Explicit source-owner commands for forms, subjects, claims and native text.

The independently selected protected configuration delegates local-account
source writing, not semantic admission. Source prose cannot choose a path,
principal, grant or executable. Access remains read-only.
"""
from __future__ import annotations

from contextlib import contextmanager, nullcontext
import ctypes
from datetime import datetime, timezone
from functools import lru_cache
import errno
import fcntl
import hashlib
import json
import os
import platform
import signal
import subprocess
from pathlib import Path
import re
import stat
import sys
import tempfile
import time
import unicodedata
from jsonschema import Draft202012Validator, ValidationError, FormatChecker

from assessment_journal import (
    JournalBusy, JournalConflict, JournalCorruption, _json_object, _keys,
    _owned_path, _sync_directory,
)
from knowledge_assessment import Record, _canonical, _instant
import source_command_contracts as contract

ROOT = Path(__file__).resolve().parents[5]
if str(ROOT / 'scripts') not in sys.path:
    sys.path.insert(0, str(ROOT / 'scripts'))
from source_witness_human_forms import (MAX_SET_BYTES, CANONICAL_NODE_SCHEMA, CANONICAL_NODE_SCHEMA_REF,
    NATIVE_ASSESSED_FORMS_REQUEST_SCHEMA, NATIVE_ASSESSED_FORMS_RESULT_SCHEMA,
    NATIVE_ASSESSED_FORMS_OPERATION, _validator, materialize_metadata_forms,
    metadata_field_catalog, canonical_field_catalog, materialize_canonical_forms,
    _read_canonical_source)
from source_witness_human_forms import claim_field_catalog, claim_forms_path, materialize_claim_forms
from source_witness_human_forms import metadata_subject, CLAIM_FORM_FIELDS

OPERATIONS = ('form.create', 'form.revise')
CREATION_OPERATION = 'historical.create'
CREATION_CONFIGS = {'tos_local_historical_create_owner_v1', 'tos_local_historical_create_owner_v2'}
PROFILE_CONFIG = 'tos_local_profile_create_owner_v1'
SIGN_CONFIG = 'tos_local_sign_promote_owner_v1'
PROFILE_CREATION_CONFIGS = {PROFILE_CONFIG, SIGN_CONFIG}
CORPUS_CONFIG = 'tos_local_corpus_create_owner_v1'
CORPUS_COLLECTION_CONFIG = 'tos_local_corpus_create_owner_v2'
CORPUS_CREATION_CONFIGS = {CORPUS_CONFIG, CORPUS_COLLECTION_CONFIG}
ARTIFACT_CREATION_CONFIG = 'tos_local_artifact_create_owner_v1'
CORPUS_REVISION_CONFIG = 'tos_local_corpus_revision_owner_v1'
CORPUS_SELECTED_REVISION_CONFIG = 'tos_local_corpus_revision_owner_v2'
CORPUS_COMPLETE_REVISION_CONFIG = 'tos_local_corpus_revision_owner_v3'
CORPUS_SELECTED_REVISION_CONFIGS = {CORPUS_SELECTED_REVISION_CONFIG, CORPUS_COMPLETE_REVISION_CONFIG}
NATIVE_METADATA_REVISION_CONFIG = 'tos_local_native_metadata_revision_owner_v1'
SELECTED_REVISION_CONFIGS = {*CORPUS_SELECTED_REVISION_CONFIGS, NATIVE_METADATA_REVISION_CONFIG}
REVISION_CONFIG = 'tos_local_source_revision_owner_v1'
PROFILE_REVISION_CONFIG = 'tos_local_profile_revision_owner_v1'
PROFILE_SCOPE_REVISION_CONFIG = 'tos_local_profile_revision_owner_v2'
PROFILE_REVISION_CONFIGS = {PROFILE_REVISION_CONFIG, PROFILE_SCOPE_REVISION_CONFIG}
CLAIM_REVISION_CONFIG = 'tos_local_claim_revision_owner_v1'
CLAIM_CONFIG = 'tos_local_claim_create_owner_v1'
CLAIM_VALUE_CONFIG = 'tos_local_claim_create_owner_v2'
CLAIM_VALUE_REVISION_CONFIG = 'tos_local_claim_revision_owner_v2'
CLAIM_STRUCTURED_CONFIG = 'tos_local_claim_create_owner_v3'
CLAIM_STRUCTURED_REVISION_CONFIG = 'tos_local_claim_revision_owner_v3'
CLAIM_REFERENCE_CONFIG = 'tos_local_claim_create_owner_v4'
CLAIM_REFERENCE_REVISION_CONFIG = 'tos_local_claim_revision_owner_v4'
CLAIM_LAYER_REVISION_CONFIG = 'tos_local_claim_layer_revision_owner_v1'
CLAIM_FORM_CONFIG = 'tos_local_claim_form_owner_v1'
CLAIM_DISPLAY_FORM_CONFIG = 'tos_local_claim_form_owner_v2'
HISTORICAL_CLAIM_FORM_CONFIG = 'tos_local_historical_claim_form_owner_v1'
CLAIM_FORM_CONFIGS = {CLAIM_FORM_CONFIG, CLAIM_DISPLAY_FORM_CONFIG, HISTORICAL_CLAIM_FORM_CONFIG}
CANONICAL_FORM_CONFIG = 'tos_local_canonical_form_owner_v1'
CANONICAL_FORM_CONFIGS = {CANONICAL_FORM_CONFIG}
TEXT_UNIT_CONFIG = 'tos_local_text_unit_create_owner_v1'
OWNER_PROFILE_CONFIG = 'tos_local_owner_profile_command_v1'
OWNER_CLAIM_CONFIG = 'tos_local_owner_claim_command_v1'
OWNER_CLAIM_REFERENCE_CONFIG = 'tos_local_owner_claim_command_v2'
REVISION_FIELDS = {'preferred_label', 'variant_labels', 'notes', 'field_languages', 'source_refs', 'extensions',
                   'semantic_content'}
PROFILE_SCOPE_REVISION_FIELDS = REVISION_FIELDS | {'semantic_scope'}
CORPUS_REVISION_FIELDS = {'preferred_label', 'notes', 'field_languages', 'source_refs'}
MAX_COMMAND_BYTES = 1_048_576
MAX_ASSESSED_OWNER_CONFIG_BYTES = 8 * MAX_COMMAND_BYTES
MAX_ASSESSED_FORMS_RESPONSE_BYTES = 16 * MAX_COMMAND_BYTES
PUBLIC_ASSESSMENT_OWNER_V2 = 'tos_local_assessment_owner_v2'
DISCOVERY_REQUEST = 'tos_source_command_discovery_request_v1'
DISCOVERY_RESULT = 'tos_source_command_discovery_v1'


def _digest(raw):
    return 'sha256:' + hashlib.sha256(raw).hexdigest()


def _read(path, limit):
    with os.fdopen(_owned_path(path), 'rb') as stream:
        before = os.fstat(stream.fileno())
        raw = stream.read(limit + 1)
        after = os.fstat(stream.fileno())
    if len(raw) > limit:
        raise ValueError('source-command input exceeds its declared byte budget')
    if (before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (after.st_size, after.st_mtime_ns, after.st_ctime_ns):
        raise JournalConflict('owner file changed during read')
    return raw


def _configuration(path):
    raw = _read(path, MAX_COMMAND_BYTES)
    config = _json_object(raw)
    handler = command_handler(config.get('schema_version'))
    if handler.configure is not None:
        return handler.configure(config, owner_config=path)
    return _builtin_configuration(config, path)


def _builtin_configuration(config, path, *, _creation_recorded_at=None):
    # Only the read-only committed-creation inspector supplies a historical
    # instant. All command dispatch retains the current delegation check.
    now = datetime.now(timezone.utc)
    evaluation_time = now
    if _creation_recorded_at is not None:
        if config.get('schema_version') not in {PROFILE_CONFIG, CORPUS_CONFIG, CORPUS_COLLECTION_CONFIG}:
            raise PermissionError('historical inspection is limited to standalone metadata creation')
        evaluation_time = _instant(_creation_recorded_at)
        if evaluation_time > now:
            raise PermissionError('creation receipt is dated in the future')
    creation = config.get('schema_version') in CREATION_CONFIGS
    profile_creation = config.get('schema_version') in PROFILE_CREATION_CONFIGS
    sign_promotion = config.get('schema_version') == SIGN_CONFIG
    corpus_creation = config.get('schema_version') in CORPUS_CREATION_CONFIGS
    corpus_revision = config.get('schema_version') in {CORPUS_REVISION_CONFIG, *CORPUS_SELECTED_REVISION_CONFIGS}
    profile_revision = config.get('schema_version') in PROFILE_REVISION_CONFIGS
    revision = config.get('schema_version') in {REVISION_CONFIG, *PROFILE_REVISION_CONFIGS, CORPUS_REVISION_CONFIG,
                                               *CORPUS_SELECTED_REVISION_CONFIGS}
    claim_forms = config.get('schema_version') in CLAIM_FORM_CONFIGS
    canonical_forms = config.get('schema_version') in CANONICAL_FORM_CONFIGS
    captures_provenance = profile_creation or corpus_creation or config.get('schema_version') == 'tos_local_historical_create_owner_v2'
    _keys(config, {'schema_version', 'uid', 'principal_id', 'source_root', 'source_path',
                   'authority_ref', 'allowed_form_ids', 'allowed_operations', 'expires_at'}
          | ({'record_id', 'allowed_claim_ids', 'maker_type'} if creation else set())
          | ({'record_id', 'profile_type_id', 'maker_type'} if profile_creation else set())
          | ({'promotion_assessment_owner_config', 'promotion_candidate_id'} if sign_promotion else set())
          | ({'record_id', 'record_type', 'maker_type'} if corpus_creation else set())
          | ({'record_type'} if corpus_revision else set())
          | ({'record_id', 'allowed_fields'} if revision else set())
          | ({'profile_type_id'} if profile_revision else set())
          | ({'claim_id'} if claim_forms else set())
          | ({'allowed_field_ids'} if config.get('schema_version') == CLAIM_DISPLAY_FORM_CONFIG else set())
          | ({'provenance_event_id'} if captures_provenance else set()))
    if (config['schema_version'] not in {'tos_local_source_command_owner_v1', REVISION_CONFIG, *PROFILE_REVISION_CONFIGS, CORPUS_REVISION_CONFIG, *CORPUS_SELECTED_REVISION_CONFIGS, *PROFILE_CREATION_CONFIGS, *CORPUS_CREATION_CONFIGS, *CLAIM_FORM_CONFIGS, *CANONICAL_FORM_CONFIGS, *CREATION_CONFIGS}
            or type(config['uid']) is not int or config['uid'] != os.getuid()
            or any(not isinstance(config[key], str) or not config[key].strip()
                   for key in ('principal_id', 'authority_ref'))
            or _instant(config['expires_at']) <= evaluation_time):
        raise PermissionError('source-command delegation is invalid or expired')
    operations = (('record.revise', 'record.recover') if config['schema_version'] in CORPUS_SELECTED_REVISION_CONFIGS
                  else ('sign.promote',) if sign_promotion else ('source.create',) if profile_creation or corpus_creation
                  else (CREATION_OPERATION,) if creation else ('record.revise',) if revision else OPERATIONS)
    for key, allowed in (('allowed_operations', operations), ('allowed_form_ids', None)):
        values = config[key]
        if (not isinstance(values, list) or len(values) > 32
                or any(not isinstance(value, str) for value in values)
                or len(set(values)) != len(values)
                or any(value not in allowed if allowed else not re.fullmatch(r'tos\.form\.[a-z0-9][a-z0-9._-]*', value)
                       for value in values)):
            raise ValueError('invalid source-command delegation scope')
    if revision:
        values = config['allowed_fields']
        allowed_fields = (CORPUS_REVISION_FIELDS if corpus_revision else
                          PROFILE_SCOPE_REVISION_FIELDS
                          if config['schema_version'] == PROFILE_SCOPE_REVISION_CONFIG else REVISION_FIELDS)
        if (not isinstance(values, list) or any(not isinstance(value, str) or value not in allowed_fields for value in values)
                or len(set(values)) != len(values)
                or not isinstance(config['record_id'], str)
                or not (profile_revision or corpus_revision) and not re.fullmatch(r'tos\.historical-(event|process|state)\.[a-z0-9]+(?:[.-][a-z0-9]+)*', config['record_id'])):
            raise ValueError('invalid source revision identity or field scope')
    if creation:
        if (not isinstance(config['record_id'], str)
                or not re.fullmatch(r'tos\.historical-(event|process|state)\.[a-z0-9]+(?:[.-][a-z0-9]+)*', config['record_id'])
                or config['maker_type'] not in {'human', 'software', 'model'}):
            raise ValueError('invalid historical creation identity or maker kind')
        values = config['allowed_claim_ids']
        if (not isinstance(values, list) or len(values) > 32
                or any(not isinstance(value, str) or not re.fullmatch(r'tos\.claim\.[a-z0-9]+(?:[.-][a-z0-9]+)*', value) for value in values)
                or len(set(values)) != len(values)):
            raise ValueError('invalid historical claim identity scope')
    if captures_provenance:
        if (not isinstance(config['provenance_event_id'], str)
                or not re.fullmatch(r'tos\.event\.[a-z0-9]+(?:[.-][a-z0-9]+)*', config['provenance_event_id'])):
            raise ValueError('invalid delegated provenance identity')
    root = Path(config['source_root'])
    os.close(_owned_path(root, directory=True))
    relative = Path(config['source_path'])
    if canonical_forms:
        if (relative.is_absolute() or relative.as_posix() != config['source_path']
                or '..' in relative.parts or relative.parts[:2] != ('ToS', 'canon')
                or relative.name != 'node.json' or len(relative.parts) < 4
                or relative.name.endswith('.human-forms.json')):
            raise PermissionError('canonical form target must be an exact ToS/canon/.../node.json source')
        source_path = root / relative
        _, _, _, contracts = _read_canonical_source(root, relative.as_posix())
        return config, _digest(_canonical({'configuration': config, 'source_contracts': contracts})), source_path
    if (relative.is_absolute() or relative.as_posix() != config['source_path']
            or '..' in relative.parts or relative.parts[:2] != ('ToS', 'source-witnesses')
            or relative.is_relative_to('ToS/source-witnesses/owner-local')
            or any(part in ('payload', 'local-content', 'catalog') for part in relative.parts)
            or (relative.name != 'source-claims.jsonl' if claim_forms else relative.suffix != '.json')
            or relative.name.endswith('.human-forms.json')):
        raise PermissionError('source-command target must be explicit source metadata')
    if claim_forms:
        _claim_form_field_ids(config)
        claim_forms_path(root / relative, config['claim_id'])
        _, _, contracts = _claim_form_source(root / relative, root, config['claim_id'])
        return config, _digest(_canonical({'configuration': config, 'source_contracts': contracts})), root / relative
    if not (creation or revision or profile_creation or corpus_creation) and relative.name in {
            'artifact-witness.json', 'composite-witness.json'}:
        _, _, contracts = _native_form_source(root / relative, root)
        return config, _digest(_canonical({'configuration': config, 'source_contracts': contracts})), root / relative
    if (creation or revision and not (profile_revision or corpus_revision)) and (relative.name != config['record_id'].split('.')[1] + '.json'
                     or len(relative.parts) < 5):
        raise PermissionError('historical creation requires its typed record in a new subject directory')
    if profile_creation or corpus_creation or profile_revision or corpus_revision:
        profile = _configured_corpus_profile(config) if corpus_creation or corpus_revision else _configured_profile(config)[1]
        if profile_creation:
            if (profile.get('creation_gate') == 'sign-promotion-v1') != sign_promotion:
                raise PermissionError('Sign identity requires its separately delegated promotion operation')
            if sign_promotion:
                if (config['profile_type_id'] != 'tos.entity.sign'
                        or not isinstance(config['promotion_candidate_id'], str)
                        or not re.fullmatch(r'tos\.claim\.[a-z0-9]+(?:[.-][a-z0-9]+)*', config['promotion_candidate_id'])
                        or not isinstance(config['promotion_assessment_owner_config'], str)):
                    raise PermissionError('Sign promotion requires its exact independently selected candidate and assessment owner')
                os.close(_owned_path(Path(config['promotion_assessment_owner_config'])))
        if (not isinstance(config['record_id'], str)
                or not re.fullmatch(re.escape(profile['id_prefix']) + r'[a-z0-9]+(?:[.-][a-z0-9]+)*', config['record_id'])
                or not revision and config['maker_type'] not in {'human', 'software', 'model'}
                or relative.name != profile['source_basename'] or len(relative.parts) < 5
                or 'catalog' in relative.parts):
            raise PermissionError('profile writing requires its delegated identity and typed source path')
        if not (corpus_creation or corpus_revision):
            profiles, _ = _configured_profile(config)
            profiles.validate_path(profile['record_type'], config['source_path'])
        if corpus_creation and config['record_type'] == 'collection' and (
                relative.parts[:3] != ('ToS', 'source-witnesses', 'collections')):
            raise PermissionError('Collection creation requires its canonical Collection owner home')
        if (corpus_creation and config['record_type'] == 'work'
                and relative.is_relative_to('ToS/source-witnesses/works/friedrich-nietzsche')):
            raise PermissionError('the Nietzsche Work source home requires its stronger authorship and chronology closure')
    if not (creation or revision or profile_creation or corpus_creation):
        inputs = _profile_form_inputs(root / relative, root)
        if inputs is not None:
            return config, _digest(_canonical({'configuration': config, **inputs})), root / relative
    return config, _digest(_canonical(config)), root / relative


def inspect_committed_creation_owner(owner_config, receipt):
    """Inspect exact historical standalone creation evidence, never a live grant.

    The caller binds the receipt bytes and verifies the complete committed
    package under its source lock. Natural expiry does not erase provenance;
    a changed configuration, receipt mismatch or creation after expiry fails.
    This function is not reachable through source command dispatch.
    """
    config = _json_object(_read(Path(owner_config), MAX_COMMAND_BYTES))
    claim = config.get('schema_version') == CLAIM_CONFIG
    schema = 'tos_local_claim_create_receipt_v1' if claim else 'tos_local_source_create_receipt_v1'
    if (not isinstance(receipt, dict)
            or receipt.get('schema_version') != schema
            or not isinstance(receipt.get('recorded_at'), str)):
        raise PermissionError('exact committed creation receipt required')
    if claim:
        import source_claim_commands
        config, digest, path = source_claim_commands.configuration(config,
            _creation_recorded_at=receipt['recorded_at'])
    else:
        config, digest, path = _builtin_configuration(config, Path(owner_config),
            _creation_recorded_at=receipt['recorded_at'])
    if (receipt.get('owner_configuration') != digest
            or receipt.get('principal_id') != config['principal_id']
            or receipt.get('authority_ref') != config['authority_ref']
            or receipt.get('source_path') != config['source_path']
            or receipt.get('grants_admission') is not False):
        raise PermissionError('committed creation authority evidence differs')
    return config, digest, path


def inspect_selected_creation_owner(owner_config, expected_receipt_sha256):
    """Read only one hash-selected committed receipt under protected owner paths."""
    config = _json_object(_read(Path(owner_config), MAX_COMMAND_BYTES))
    root = Path(config['source_root'])
    relative = Path(config['source_path'])
    if (not root.is_absolute() or '..' in root.parts or relative.is_absolute()
            or '..' in relative.parts or relative.parts[:2] != ('ToS', 'source-witnesses')
            or relative.suffix not in {'.json', '.jsonl'}):
        raise PermissionError('exact protected source metadata receipt required')
    raw = _read((root / relative).with_name('source-create-receipt.json'), MAX_COMMAND_BYTES)
    expected = expected_receipt_sha256.removeprefix('sha256:')
    if not re.fullmatch(r'[a-f0-9]{64}', expected) or hashlib.sha256(raw).hexdigest() != expected:
        raise JournalConflict('selected creation receipt bytes differ')
    return inspect_committed_creation_owner(owner_config, _json_object(raw))


def _configured_corpus_profile(config):
    """Existing standalone native identities, not role subclasses or a new ontology.

    A provisional Work can start with an explicitly empty expression-claim
    list. Realizations and mandatory related objects are not inferred or
    created by this metadata transaction.
    """
    kind = config.get('record_type')
    allowed = {'agent', 'place', 'organization', 'work'}
    if config.get('schema_version') == CORPUS_COLLECTION_CONFIG:
        allowed.add('collection')
    if config.get('schema_version') in CORPUS_SELECTED_REVISION_CONFIGS:
        allowed.add('expression')
    if config.get('schema_version') == CORPUS_COMPLETE_REVISION_CONFIG:
        allowed.update({'edition', 'collection', 'item'})
    if not isinstance(kind, str) or kind not in allowed:
        raise PermissionError('native record type is outside this metadata grant version')
    return {'record_type': kind, 'id_prefix': f'tos.{kind}.', 'source_basename': kind + '.json',
            'schema_ref': 'ToS/contracts/corpus-record.schema.json', 'schema_version': 'tos_corpus_record_v1',
            'source_scope': 'public_metadata_only'}


def _configured_profile(config, profiles=None):
    from source_record_profiles import SourceRecordProfiles
    profiles = profiles or SourceRecordProfiles(Path(config['source_root']))
    entry = next((entry for entry in profiles.registry['types']
                  if entry['type_id'] == config['profile_type_id']), None)
    if entry is None or 'source_record_profile' not in entry:
        raise PermissionError('writing requires an explicitly declared source metadata profile')
    return profiles, entry['source_record_profile']


def _form_ref(value):
    return Record.from_payload(value['form_id'], value['form_version'], value).ref


def _validate_history(payload, *, validator=None):
    """Retained versions must form one complete, nonbranching chain per form."""
    (validator if validator is not None else _validator()).validate(payload)
    indexed, current, commands = {}, set(), set()
    for form in [*payload['prior_forms'], *payload['forms']]:
        ref = _form_ref(form)
        key = (ref['id'], ref['version'])
        if key in indexed or form['subject']['id'] != payload['subject']['id']:
            raise JournalCorruption('duplicate form version or mixed subject history')
        indexed[key] = form
    for form in payload['forms']:
        if form['form_id'] in current:
            raise JournalCorruption('duplicate current form identity')
        current.add(form['form_id'])
    for (identifier, version), form in indexed.items():
        if version == 1:
            if form['revises'] is not None:
                raise JournalCorruption('initial form has a predecessor')
        else:
            previous = indexed.get((identifier, version - 1))
            if previous is None or form['revises'] != _form_ref(previous):
                raise JournalCorruption('broken retained form lineage')
        if identifier not in current:
            raise JournalCorruption('retained form has no current successor')
    for form in payload['forms']:
        if any(identifier == form['form_id'] and version > form['form_version'] for identifier, version in indexed):
            raise JournalCorruption('current form is not its latest retained version')
    for receipt in payload.get('growth_history', []):
        if receipt['command_id'] in commands or receipt['source']['id'] != payload['subject']['id']:
            raise JournalCorruption('duplicate command or mixed subject receipt')
        commands.add(receipt['command_id'])
        _instant(receipt['recorded_at'])
        for ref in receipt['results']:
            form = indexed.get((ref['id'], ref['version']))
            if form is None or _form_ref(form) != ref:
                raise JournalCorruption('receipt result is absent from retained forms')


def _claim_form_source(source_path, root, claim_id):
    """Select exactly one Claim from one bounded protected stream, not a corpus scan.

    Checks profile/schema/layer/visibility. Endpoint existence and semantic
    domain/range remain the source and graph validators' responsibility; a
    form write cannot change or admit the Claim.
    """
    from source_record_profiles import SourceClaimProfiles
    raw = _read(source_path, MAX_COMMAND_BYTES)
    claims = [_json_object(line) for line in raw.splitlines() if line.strip()]
    selected = [claim for claim in claims if claim.get('claim_id') == claim_id]
    if len(selected) != 1:
        raise ValueError('delegated Claim must resolve exactly once in the source stream')
    source = selected[0]
    from source_historical_claims import is_path as historical_claim_path, validate as validate_historical_claim
    if historical_claim_path(source_path):
        return raw, source, validate_historical_claim(root, source)
    profiles = SourceClaimProfiles(root)
    profiles.validate(source)
    total_bytes = len(raw)
    for ref, digest in profiles.input_digests.items():
        contract = _read(root / ref, MAX_COMMAND_BYTES)
        total_bytes += len(contract)
        if total_bytes > 8_388_608 or len(profiles.input_digests) > 128:
            raise ValueError('Claim form source and contracts exceed the bounded input snapshot')
        if hashlib.sha256(contract).hexdigest() != digest:
            raise JournalConflict('Claim form source contract changed while resolving')
    return raw, source, {ref: 'sha256:' + digest for ref, digest in profiles.input_digests.items()}


def _native_form_source(source_path, root):
    from build_source_witness_catalog import native_witness_contract
    raw = _read(source_path, MAX_COMMAND_BYTES)
    source = _json_object(raw)
    relative = source_path.relative_to(root)
    if source_path.name == 'link.json':
        if (not relative.is_relative_to('ToS/source-witnesses/links')
                or source.get('schema_version') != 'tos_source_link_v1'):
            raise PermissionError('Link forms require their exact native public owner contract')
        schema_ref = 'ToS/contracts/source-link.schema.json'
    else:
        schema_ref, _, _ = native_witness_contract(source, relative.as_posix())
    schema_raw = _read(root / schema_ref, MAX_COMMAND_BYTES)
    if not Draft202012Validator(_json_object(schema_raw), format_checker=FormatChecker()).is_valid(source):
        raise ValueError('native form source violates its exact public metadata schema')
    return raw, source, {schema_ref: _digest(schema_raw)}


def _profile_input_snapshot(profiles):
    """Protected profile closure with an opaque, separately held native hash."""
    native_snapshot = profiles.native_identity_snapshot(read_bytes=_read, only_if_used=True)
    native_text_snapshot = profiles.native_text_snapshot(read_bytes=_read)
    total = 0
    for ref, digest in profiles.input_digests.items():
        raw = _read(profiles.root / ref, MAX_COMMAND_BYTES)
        total += len(raw)
        if total > 8_388_608 or len(profiles.input_digests) > 128:
            raise ValueError('source profile contracts exceed the bounded input snapshot')
        if hashlib.sha256(raw).hexdigest() != digest:
            raise JournalConflict('source profile contract changed during resolution')
    return {'source_contracts': {ref: 'sha256:' + digest for ref, digest in profiles.input_digests.items()},
            **({'native_binding_implementation': {
                ref: _digest(_read(ROOT / ref, MAX_COMMAND_BYTES)) for ref in
                ('scripts/native_text_binding.py', 'scripts/source_owner_context.py')}}
               if native_text_snapshot is not None else {}),
            **({'native_text_binding_snapshot': native_text_snapshot} if native_text_snapshot is not None else {}),
            **({'native_semantic_identity_snapshot': native_snapshot} if native_snapshot is not None else {})}


def _profile_form_inputs(source_path, root, source=None):
    source = _json_object(_read(source_path, MAX_COMMAND_BYTES)) if source is None else source
    if (source.get('schema_version') in {'tos_corpus_record_v1', 'tos_historical_record_v1'}
            and source_path.name != 'composite.json'):
        return None  # Existing native metadata adapters retain their own contracts.
    from source_record_profiles import SourceRecordProfiles
    profiles = SourceRecordProfiles(root)
    kind = source.get('record_type')
    if kind not in profiles.profiles or source_path.name != profiles.profiles[kind]['source_basename']:
        raise ValueError('source-command adapter does not understand this source family')
    profiles.validate_path(kind, source_path.relative_to(root).as_posix())
    profiles.validate(kind, source)
    return _profile_input_snapshot(profiles)


def _canonical_form_source(source_path, root):
    """Resolve one exact versioned native canon node and its schema digest."""
    path, raw, source, contracts = _read_canonical_source(root, source_path.relative_to(root).as_posix())
    if path != source_path:
        raise JournalConflict('canonical source path changed while resolving its owner')
    return raw, source, contracts


def _snapshot(source_path, root=None, claim_id=None, *, canonical=False):
    if claim_id is not None:
        source_raw, source, _ = _claim_form_source(source_path, root, claim_id)
        subject = Record.from_payload(source['claim_id'], source['claim_version'], source)
        target = claim_forms_path(source_path, claim_id)
    elif canonical:
        if root is None:
            raise ValueError('canonical node forms require the explicit source owner')
        source_raw, source, _ = _canonical_form_source(source_path, root)
        subject = metadata_subject(source)
        target = source_path.with_name('node.human-forms.json')
    elif source_path.name in {'artifact-witness.json', 'composite-witness.json', 'link.json'}:
        if root is None:
            raise ValueError('native witness forms require the explicit source owner')
        source_raw, source, _ = _native_form_source(source_path, root)
        target = source_path.with_name(source_path.stem + '.human-forms.json')
    else:
        source_raw = _read(source_path, MAX_COMMAND_BYTES)
        source = _json_object(source_raw)
        target = source_path.with_name(source_path.stem + '.human-forms.json')
    if claim_id is None and not canonical and source_path.name not in {'artifact-witness.json', 'composite-witness.json', 'link.json'} and (source.get('schema_version') not in {'tos_corpus_record_v1', 'tos_historical_record_v1'}
                             or source_path.name == 'composite.json'):
        if root is None:
            raise ValueError('source-command adapter does not understand this source family')
        _profile_form_inputs(source_path, root, source)
    if (source.get('schema_version') == 'tos_historical_record_v1'
            and source.get('visibility') not in {'public', 'public_metadata_only'}):
        raise PermissionError('historical source visibility is outside the public-metadata adapter')
    if claim_id is None and not canonical:
        subject = metadata_subject(source)
    try:
        raw = _read(target, MAX_SET_BYTES)
    except FileNotFoundError:
        raw = None
    payload = _json_object(raw) if raw is not None else None
    if payload is not None:
        _validate_history(payload)
        if payload['subject']['id'] != subject.id:
            raise JournalCorruption('source and form set have different subjects')
    if _read(source_path, MAX_COMMAND_BYTES) != source_raw:
        raise JournalConflict('source changed while reading adjacent forms')
    return source_raw, source, subject, target, raw, payload


@contextmanager
def _locked(target, timeout=5.0, *, allow_pending=False):
    # Stable sibling lock survives atomic replacement of the actual source set.
    os.close(_owned_path(target.parent, directory=True))
    lock_path = target.with_name('.' + target.name + '.writer.lock')
    descriptor = os.open(lock_path, os.O_WRONLY | os.O_CREAT | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600)
    with os.fdopen(descriptor, 'wb') as lock:
        if not stat.S_ISREG(os.fstat(lock.fileno()).st_mode):
            raise PermissionError('source-command lock is not a regular file')
        os.close(_owned_path(lock_path))
        deadline = time.monotonic() + timeout
        while True:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise JournalBusy('source-command writer is busy') from None
                time.sleep(0.01)
        try:
            if (not allow_pending and target.name == 'historical-create'
                    and target.parent.name == 'source-witnesses' and target.parent.parent.name == 'ToS'):
                # Check after acquiring the shared writer lock, not before
                # waiting for a possibly interrupted selected-file writer.
                from source_metadata_snapshot import PublicationSnapshot
                PublicationSnapshot(target.parents[2])
            yield
        finally:
            fcntl.flock(lock, fcntl.LOCK_UN)


def _publish(target, raw):
    descriptor, name = tempfile.mkstemp(prefix='.' + target.name + '.', suffix='.pending', dir=target.parent)
    try:
        with os.fdopen(descriptor, 'wb') as stream:
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(name, target)
        _sync_directory(target.parent)
    finally:
        # Only our unpublished staging file; never source or retained history.
        if os.path.exists(name):
            os.unlink(name)


def _changes(request, config):
    changes = request['changes']
    if not isinstance(changes, list) or not 1 <= len(changes) <= 32:
        raise ValueError('one to thirty-two source changes are required')
    identifiers = set()
    for change in changes:
        _keys(change, {'operation', 'expected_form', 'form'})
        form = change['form']
        if not isinstance(form, dict):
            raise ValueError('form must be an object')
        identifier = form.get('form_id')
        if (change['operation'] not in config['allowed_operations']
                or identifier not in config['allowed_form_ids']
                or form.get('creator_id') != config['principal_id']):
            raise PermissionError('change is outside delegated operation, identity or creator scope')
        if identifier in identifiers:
            raise ValueError('a batch must change each form identity once')
        identifiers.add(identifier)
    if config.get('schema_version') in {*CLAIM_FORM_CONFIGS, OWNER_CLAIM_CONFIG, OWNER_CLAIM_REFERENCE_CONFIG}:
        _check_claim_form_changes(config, changes)
    if config.get('schema_version') in CANONICAL_FORM_CONFIGS:
        _check_canonical_form_changes(changes)
    return changes


def _claim_form_field_ids(config):
    """An older grant never acquires new display-field selectors implicitly."""
    values = (config['allowed_field_ids'] if config.get('schema_version') == CLAIM_DISPLAY_FORM_CONFIG
              else config.get('allowed_form_field_ids', ['claim.statement']))
    if (not isinstance(values, list) or not 1 <= len(values) <= len(CLAIM_FORM_FIELDS)
            or any(not isinstance(value, str) or value not in CLAIM_FORM_FIELDS for value in values)
            or len(set(values)) != len(values)):
        raise ValueError('Claim forms require a bounded explicit known field scope')
    return values


def _check_claim_form_changes(config, changes, current_forms=(), *, historical_forms=()):
    """Check actual bindings, also on raw apply, predecessor changes and replay.

    Exact source/version/language/context validation remains with application
    and materialization. This gate checks authority without requiring a retry
    to bind the newest source or resurrect an earlier ready materialization.
    """
    allowed = _claim_form_field_ids(config)
    for change in changes:
        form = change['form']
        predecessor = change.get('expected_form')
        if predecessor != form.get('revises'):
            raise JournalConflict('Claim form request differs from its bound predecessor')
        if 'operation' in change and ((change['operation'] == 'form.create') != (predecessor is None)
                or (predecessor is None and form.get('form_version') != 1)):
            raise JournalConflict('Claim form operation differs from its retained lineage')
    selected_ids = {change['form']['form_id'] for change in changes}
    forms = [change['form'] for change in changes]
    forms.extend(form for form in current_forms if form['form_id'] in selected_ids)
    predecessors = [change.get('expected_form') for change in changes if change.get('expected_form') is not None]
    forms.extend(form for form in historical_forms if _form_ref(form) in predecessors)
    for form in forms:
        content = form.get('content', {})
        if content.get('kind') != 'source-copy':
            if config.get('schema_version') in {CLAIM_DISPLAY_FORM_CONFIG, HISTORICAL_CLAIM_FORM_CONFIG}:
                raise PermissionError('display-field delegation permits only exact source copies')
            continue  # Historical v1 non-copy proposals remain unassessed.
        binding = form.get('bindings', {}).get(content.get('slot'), {})
        if not any((form.get('role'), binding.get('pointer')) == CLAIM_FORM_FIELDS[field]
                   for field in allowed):
            raise PermissionError('Claim source-copy field is outside delegated scope')


def _check_canonical_form_changes(changes, current_forms=(), *, historical_forms=()):
    """Keep the canonical owner lane source-copy-only on create and replay."""
    selected_ids = {change['form']['form_id'] for change in changes}
    forms = [change['form'] for change in changes]
    forms.extend(form for form in current_forms if form['form_id'] in selected_ids)
    predecessors = [change.get('expected_form') for change in changes if change.get('expected_form') is not None]
    forms.extend(form for form in historical_forms if _form_ref(form) in predecessors)
    for form in forms:
        if form.get('content', {}).get('kind') != 'source-copy':
            raise PermissionError('canonical form delegation permits only exact source copies')


def _check_claim_form_receipt_scope(config, payload, refs):
    """A historical correction retry retains both result and predecessor scope."""
    retained = [*payload['forms'], *payload.get('prior_forms', ())]
    selected = []
    for ref in refs:
        matches = [form for form in retained if _form_ref(form) == ref]
        if len(matches) != 1:
            raise JournalCorruption('Claim correction receipt form is not exactly retained')
        selected.append({'form': matches[0], 'expected_form': matches[0].get('revises')})
    # A later independent successor is not part of this historical operation.
    _check_claim_form_changes(config, selected, historical_forms=retained)


def _apply(payload, subject, changes, *, validator=None):
    value = json.loads(_canonical(payload)) if payload else {
        'schema_version': 'tos_human_form_set_v1', 'subject': subject.ref, 'forms': [], 'prior_forms': []}
    current = {form['form_id']: index for index, form in enumerate(value['forms'])}
    for change in changes:
        form = change['form']
        if form.get('subject') != subject.ref:
            raise JournalConflict('new form must bind the exact current subject')
        index = current.get(form['form_id'])
        if change['operation'] == 'form.create':
            if index is not None or change['expected_form'] is not None or form.get('form_version') != 1 or form.get('revises') is not None:
                raise JournalConflict('create requires a new identity and initial version')
            value['forms'].append(form)
        else:
            if index is None:
                raise JournalConflict('revise requires an existing current form')
            old = value['forms'][index]
            previous = _form_ref(old)
            if (change['expected_form'] != previous or form.get('revises') != previous
                    or form.get('form_version') != old['form_version'] + 1):
                raise JournalConflict('revision must extend the exact current form')
            value['prior_forms'].append(old)
            value['forms'][index] = form
    # Do not mark old forms current against a new subject by rewriting their refs.
    # Each old form retains its exact subject and becomes stale in the reader.
    value['subject'] = subject.ref
    _validate_history(value, validator=validator)
    return value


def prepare_metadata_change(source, payload, principal_id, form_id, field_id):
    """Construct a proposal from the reader's finite field catalog; grant nothing."""
    subject = metadata_subject(source)
    return _prepare_form_change(subject, metadata_field_catalog(source), payload, principal_id, form_id, field_id)


def prepare_canonical_change(source, payload, principal_id, form_id, field_id):
    """Prepare one source-copy form through the versioned canonical field catalog."""
    subject = metadata_subject(source)
    return _prepare_form_change(subject, canonical_field_catalog(source), payload, principal_id, form_id, field_id)


def prepare_claim_change(source, payload, principal_id, form_id, field_id, *, allowed_field_ids=('claim.statement',)):
    if field_id not in allowed_field_ids:
        raise PermissionError('Claim form field is not explicitly delegated')
    subject = Record.from_payload(source['claim_id'], source['claim_version'], source)
    return _prepare_form_change(subject, claim_field_catalog(source), payload, principal_id, form_id, field_id)


def _prepare_form_change(subject, fields, payload, principal_id, form_id, field_id):
    field = next((field for field in fields if field['field_id'] == field_id), None)
    if field is None:
        raise ValueError('unknown metadata field selector')
    old = next((form for form in payload['forms'] if form['form_id'] == form_id), None) if payload else None
    selected_operation = 'form.revise' if old else 'form.create'
    prior = _form_ref(old) if old else None
    form = {'schema_version': 'tos_human_form_v1', 'form_id': form_id,
            'form_version': old['form_version'] + 1 if old else 1, 'subject': subject.ref,
            'role': field['role'], 'language': field['language'], 'script': field['script'],
            'creator_id': principal_id, 'revises': prior,
            'bindings': {'wording': {'record': subject.ref, 'pointer': field['pointer']},
                         **{f'context-{index}': {'record': subject.ref, 'pointer': pointer}
                            for index, pointer in enumerate(field['context'])}},
            'content': {'kind': 'source-copy', 'slot': 'wording'}}
    return {'operation': selected_operation, 'expected_form': prior, 'form': form}


def _creation_scope(config, request):
    """Current delegated IDs and maker apply even to an exact old retry."""
    source, claims, selections = request['record'], request.get('claims', []), request['forms']
    artifact = config['schema_version'] == ARTIFACT_CREATION_CONFIG
    identity_field = 'artifact_id' if artifact else 'record_id'
    if not isinstance(source, dict) or source.get(identity_field) != config['record_id']:
        raise PermissionError('source subject identity is not delegated')
    if artifact:
        from source_artifact_commands import initial_record
        initial_record(config, source)
        if request.get('source_bindings') != config['source_bindings']:
            raise PermissionError('Artifact request differs from its separately delegated exact source inputs')
    if not isinstance(claims, list) or len(claims) > 32:
        raise ValueError('at most thirty-two initial claims are supported')
    if not isinstance(selections, list) or not 1 <= len(selections) <= 32:
        raise ValueError('one to thirty-two source-copy selections are required')
    for claim in claims:
        if (not isinstance(claim, dict) or claim.get('claim_id') not in config['allowed_claim_ids']
                or not isinstance(claim.get('maker'), dict)
                or claim['maker'].get('agent_ref') != config['principal_id']
                or claim['maker'].get('maker_type') != config['maker_type']
                or (config.get('provenance_event_id')
                    and claim.get('provenance_event_ref') != config['provenance_event_id'])):
            raise PermissionError('historical claim identity or maker is not delegated')
    for selection in selections:
        _keys(selection, {'form_id', 'field_id'})
        if selection['form_id'] not in config['allowed_form_ids']:
            raise PermissionError('form identity is not delegated')


def _initial_historical_record(config, source):
    from source_witness_bibliographic_graph_common import historical_schema_validator
    historical_schema_validator(Path(config['source_root'])).validate(source)
    if (source['record_id'] != config['record_id'] or source['record_version'] != 1
            or source.get('supersedes_ref') is not None or source['identity_status'] != 'provisional'
            or source['same_as_posture'] != 'no_equivalence_claim'
            or source['visibility'] not in {'public', 'public_metadata_only'}):
        raise PermissionError('creation requires a delegated provisional public-metadata identity')
    return Record.from_payload(source['record_id'], 1, source)


def _sign_promotion(config, *, require_ready=True):
    """Read a current source-bound judgment; never trust a submitted verdict.

    Issuance is separately delegated by SIGN_CONFIG. This public metadata
    operation cannot consume inline targets or confidential assessment roots.
    Its small returned basis records the past check, not continuing admission.
    """
    from assessment_journal import run_local_command as assessment_command, _source_records
    owner = Path(config['promotion_assessment_owner_config'])
    encoded = _read(owner, 8 * MAX_COMMAND_BYTES)
    assessment_config = _json_object(encoded)
    root = Path(config['source_root'])
    if (assessment_config.get('schema_version') not in {'tos_local_assessment_owner_v2', 'tos_local_assessment_owner_v3'}
            or assessment_config.get('source_root') != str(root)):
        raise PermissionError('Sign promotion needs the same public source root and a source-bound assessment owner')
    candidate_id = config['promotion_candidate_id']
    selected = [row for row in assessment_config.get('source_records', [])
                if isinstance(row, dict) and row.get('record_id') == candidate_id]
    if len(selected) != 1:
        raise PermissionError('Sign promotion candidate must be one selected authored Claim, not an inline record')
    # The Claim's typed endpoints and all motif members belong to the same
    # configured closure. Selecting only its row would discard the grounds
    # before the shared adapter can validate domain/range and completeness.
    records, _ = _source_records(root, assessment_config['source_records'])
    candidate = next((row for row in records if row['id'] == candidate_id), None)
    body = candidate['payload'] if candidate else {}
    if (body.get('schema_version') != 'tos_source_occurrence_motif_claim_v1'
            or body.get('predicate') != 'occurrence_motif_proposal'
            or body.get('assertion_layer') != 'semantic_interpretation'
            or body.get('visibility') not in {'public', 'public_metadata_only'}):
        raise PermissionError('this Sign transition requires an exact qualified public motif Claim')
    view = assessment_command(owner, {'schema_version': 'tos_local_assessment_command_v1',
        'operation': 'describe', 'subject_id': candidate_id}, contract_root=root,
        accepted_owner_versions=frozenset({'tos_local_assessment_owner_v2', 'tos_local_assessment_owner_v3'}))
    result = view['result']
    context, admission = result['command_context'], result['current_admission']
    expected = Record.from_payload(**candidate).ref
    if (_read(owner, 8 * MAX_COMMAND_BYTES) != encoded or context['subject'] != expected
            or admission['subject'] != expected):
        raise JournalConflict('Sign candidate or assessment owner changed during resolution')
    if (context['scope']['requested_use'] != 'sign-promotion'
            or context['scope']['risk'] not in {'moderate', 'high'}
            or context['scope']['assertion_layer'] != 'semantic_interpretation'):
        raise PermissionError('research admission or a lowered risk does not delegate Sign promotion')
    ready = (admission['use'] == 'sign-promotion' and admission['can_use'] is True
             and admission['status'] in {'admitted', 'admitted-with-limits'}
             and bool(admission['assessment_refs']) and result['revision'] is not None
             and bool(context.get('required_sources'))
             and context.get('source_read', {}).get('ready') is True)
    basis = None
    if ready:
        basis = {'schema_version': 'tos_sign_promotion_basis_v1', 'candidate': expected,
            'policy': admission['policy'], 'required_sources': context['required_sources'],
            'assessment_refs': admission['assessment_refs'], 'owner_snapshot': view['owner_snapshot'],
            'journal_revision': result['revision'], 'status': admission['status'],
            'use': 'sign-promotion', 'limits': admission['limits'], 'grants_current_use': False}
    elif require_ready:
        raise PermissionError('Sign promotion lacks current qualified assessment and exact source reading')
    return {'eligible': ready, 'basis': basis, 'current_admission': admission,
            'grants_issuance_authority': False}


@contextmanager
def _sign_promotion_lock(config):
    """Serialize final current judgment -> issuance with normal journal writes.

    Lock order is corpus creation then the selected assessment subject. The
    assessment journal does not acquire the corpus lock. A later withdrawal
    remains valid history, but cannot precede issuance after its final check.
    External configuration/source publishers retain their ordinary obligation
    to keep owner inputs stable during the operation (same-UID trust boundary).
    """
    from assessment_journal import AssessmentJournal
    owner = Path(config['promotion_assessment_owner_config'])
    encoded = _read(owner, 8 * MAX_COMMAND_BYTES)
    selected = _json_object(encoded)
    if (selected.get('schema_version') not in {'tos_local_assessment_owner_v2', 'tos_local_assessment_owner_v3'}
            or selected.get('source_root') != config['source_root']):
        raise PermissionError('Sign publication requires the same public assessment owner')
    directory = Path(selected['journal_directory'])
    os.close(_owned_path(directory, directory=True))
    journal = AssessmentJournal(directory, contract_root=Path(config['source_root']), protected_storage=True)
    with journal._locked(journal._home(config['promotion_candidate_id'])):
        if _read(owner, 8 * MAX_COMMAND_BYTES) != encoded:
            raise JournalConflict('Sign assessment owner changed while waiting for its journal')
        yield


def _initial_source_record(config, source, profiles=None):
    if config['schema_version'] == ARTIFACT_CREATION_CONFIG:
        from source_artifact_commands import initial_record
        return initial_record(config, source)
    if config['schema_version'] in CORPUS_CREATION_CONFIGS:
        profile = _configured_corpus_profile(config)
        from source_record_profiles import METADATA_LINK_FIELDS
        schema = _json_object(_read(Path(config['source_root']) / profile['schema_ref'], MAX_COMMAND_BYTES))
        Draft202012Validator.check_schema(schema)
        Draft202012Validator(schema).validate(source)
        # Corpus requires this field for Work. An empty initial list records
        # no supplied expression assertions; it does not mean none exist.
        link_fields = set(METADATA_LINK_FIELDS)
        if profile['record_type'] == 'work':
            work_fields = {'schema_version', 'record_type', 'record_id', 'record_version', 'preferred_label',
                'variant_labels', 'field_languages', 'identity_status', 'source_refs', 'external_identifiers',
                'same_as_posture', 'notes', 'supersedes_ref', 'expression_claim_refs'}
            if set(source) - work_fields:
                raise PermissionError('initial Work creation owns identity metadata, not realization or publication fields')
            if source['expression_claim_refs'] != []:
                raise PermissionError('initial standalone Work cannot assert expression closure')
            link_fields.remove('expression_claim_refs')
        if profile['record_type'] == 'collection':
            collection_fields = {'schema_version', 'record_type', 'record_id', 'record_version',
                'preferred_label', 'variant_labels', 'field_languages', 'identity_status', 'source_refs',
                'external_identifiers', 'same_as_posture', 'notes', 'supersedes_ref', 'membership_claim_refs'}
            if set(source) - collection_fields or source.get('membership_claim_refs') != []:
                raise PermissionError('initial Collection creation cannot assert membership or publication')
            link_fields.remove('membership_claim_refs')
        if (source['record_type'] != profile['record_type'] or source['record_id'] != config['record_id']
                or source['record_version'] != 1 or source.get('supersedes_ref') is not None
                or source['identity_status'] != 'provisional' or source['same_as_posture'] != 'no_equivalence_claim'
                or any(key in source for key in link_fields)
                or any(value['status'] != 'unverified' for key in ('variant_labels', 'external_identifiers')
                       for value in source.get(key, []))):
            raise PermissionError('native creation requires a provisional standalone identity without accepted attributions')
        return Record.from_payload(source['record_id'], 1, source)
    if config['schema_version'] not in PROFILE_CREATION_CONFIGS:
        return _initial_historical_record(config, source)
    profiles, profile = _configured_profile(config, profiles)
    if profile.get('creation_gate'):
        if config['schema_version'] != SIGN_CONFIG or profile['creation_gate'] != 'sign-promotion-v1':
            raise PermissionError('this source profile requires its explicit creation gate')
        if _canonical(source.get('promotion_basis')) != _canonical(_sign_promotion(config)['basis']):
            raise JournalConflict('Sign description must retain the exact current promotion basis')
    profiles.validate(profile['record_type'], source)
    if (source['record_id'] != config['record_id'] or source['record_version'] != 1
            or source.get('supersedes_ref') is not None or source['identity_status'] != 'provisional'
            or source['same_as_posture'] != 'no_equivalence_claim'):
        raise PermissionError('creation requires a delegated provisional initial identity')
    profiles.validate_native_binding(profile['record_type'], source, verify_content=True)
    return Record.from_payload(source['record_id'], 1, source)


def _form_identity_inputs(root, allocated, *, records=None, claims=None, own=None):
    """Reserve current and prior IDs through finite public source locators.

    This is identity inspection, not historical schema admission or a write
    grant. Callers retain their own source grammar and transaction readset.
    """
    from build_source_witness_catalog import collect_records, collect_claims
    from source_record_profiles import SOURCE_CLAIM_BASENAME
    from source_historical_claims import is_path as historical_claim_path
    root = Path(root)
    if records is None:
        records = [row for rows in collect_records(root).values() for row in rows]
    if claims is None:
        claims = collect_claims(root)
    paths = {Path(row['source_record_ref']).with_name(Path(row['source_record_ref']).stem + '.human-forms.json')
             for row in records}
    paths.update(claim_forms_path(Path(row['source_claim_file_ref']), row['claim_id'])
                 for row in claims if Path(row['source_claim_file_ref']).name == SOURCE_CLAIM_BASENAME
                 or historical_claim_path(Path(row['source_claim_file_ref'])))
    allocated, inputs = set(allocated), {}
    for relative in sorted(paths - ({Path(own)} if own is not None else set())):
        try:
            raw = _read(root / relative, MAX_SET_BYTES)
        except FileNotFoundError:
            continue
        forms = _json_object(raw)
        _validate_history(forms)
        if allocated & {form['form_id'] for form in [*forms['forms'], *forms['prior_forms']]}:
            raise JournalConflict('form identity already exists on another subject')
        inputs[relative.as_posix()] = _digest(raw)
    return inputs


def _prepare_creation(config, request):
    """Shared initial metadata serialization; historical claims stay optional.

    The historical route alone admits initial claims under its own contract.
    A profile declaration neither selects a writer nor authorizes claims.
    """
    if config['schema_version'] == ARTIFACT_CREATION_CONFIG:
        from source_artifact_commands import prepare_creation
        return prepare_creation(config, request)
    from build_source_witness_catalog import collect_records, collect_claims
    from source_record_profiles import SourceRecordProfiles
    from source_witness_bibliographic_graph_common import (
        _historical_claim_contract, _validate_historical_claim,
        _scan_index, _evidence_node, BibliographicGraphBuildError,
    )
    root = Path(config['source_root'])
    source, claims, selections = request['record'], request.get('claims', []), request['forms']
    profiles = SourceRecordProfiles(root)
    subject = _initial_source_record(config, source, profiles)
    profiles.assert_identity_not_native(source['record_id'])
    records = collect_records(root, profiles=profiles)
    claim_profile_inputs = {}
    existing_claims = collect_claims(root, input_digests=claim_profile_inputs)
    objects = {row['record_id']: row for rows in records.values() for row in rows}
    if source['record_id'] in objects:
        raise JournalConflict('subject identity already exists in authored sources')
    if config['schema_version'] == SIGN_CONFIG:
        for row in records.get('sign', []):
            prior = profiles.load('sign', row['source_record_ref'])
            if prior['promotion_basis']['candidate']['id'] == config['promotion_candidate_id']:
                raise JournalConflict('candidate already has a Sign identity; revision or explicit lineage is required')
    new_form_ids = {selection['form_id'] for selection in selections}
    form_inputs = _form_identity_inputs(root, new_form_ids, records=objects.values(), claims=existing_claims)
    objects[source['record_id']] = {'record_type': source['record_type'],
        'source_record_ref': config['source_path'], 'record_sha256': _digest(_canonical(source))[7:]}
    claim_ids = {claim['claim_id'] for claim in existing_claims}
    events = _scan_index(root, filename_pattern='*provenance*.jsonl', id_field='event_id')
    new_event = config.get('provenance_event_id')
    if new_event in events:
        raise JournalConflict('provenance identity already exists')
    anchors = _scan_index(root, filename_pattern='*anchor*.jsonl', id_field='anchor_id')
    historical_contract = _historical_claim_contract(root) if claims else None
    evidence = []
    for claim in claims:
        historical_contract[0].validate(claim)
        if (claim['claim_id'] not in config['allowed_claim_ids']
                or claim['subject_ref'] != source['record_id']
                or claim['maker']['agent_ref'] != config['principal_id']
                or claim['maker']['maker_type'] != config['maker_type']
                or claim['visibility'] not in {'public', 'public_metadata_only'}
                or claim['claim_version'] != 1 or claim.get('assessment_refs')
                or claim.get('supersedes_claim_ref') is not None):
            raise PermissionError('claim exceeds initial identity, maker, visibility or assessment scope')
        if claim['claim_id'] in claim_ids:
            raise JournalConflict('claim identity already exists or repeats in the batch')
        claim_ids.add(claim['claim_id'])
        try:
            _validate_historical_claim(claim, objects, historical_contract)
            if new_event and claim['provenance_event_ref'] != new_event:
                raise PermissionError('new claims must bind the delegated creation provenance')
            if claim['provenance_event_ref'] not in events and claim['provenance_event_ref'] != new_event:
                raise ValueError('claim must refer to an existing provenance event')
            for ref in [*claim['evidence_refs'], *claim.get('counterevidence_refs', [])]:
                if ref.startswith('ToS/'):
                    relative = Path(ref)
                    if relative.is_absolute() or '..' in relative.parts or any(part in {'payload', 'local-content'} for part in relative.parts):
                        raise PermissionError('evidence must address owned metadata, not payload paths')
                    os.close(_owned_path(root / relative))
                evidence.append(_evidence_node(ref, repo_root=root, anchors=anchors, objects=objects, events=events))
        except BibliographicGraphBuildError as error:
            raise ValueError('historical claim does not satisfy the existing graph reader') from error
    for claim in claims:
        if any(ref not in claim_ids for ref in claim.get('alternative_claim_refs', [])):
            raise ValueError('alternative claim must resolve in authored sources or this batch')
    changes, seen_forms = [], set()
    for selection in selections:
        _keys(selection, {'form_id', 'field_id'})
        if selection['form_id'] not in config['allowed_form_ids']:
            raise PermissionError('form identity is not delegated')
        if selection['form_id'] in seen_forms:
            raise ValueError('duplicate form identity')
        seen_forms.add(selection['form_id'])
        changes.append(prepare_metadata_change(source, None, config['principal_id'], **selection))
    forms = _apply(None, subject, changes)
    views = materialize_metadata_forms(source, forms, access_allowed=True)
    if not all(view['state'] == 'ready' for view in views):
        raise ValueError('initial forms must satisfy the current source-copy reader')
    if not any(view['role'] == 'name' for view in views):
        raise ValueError('a new subject requires a source-bound name form')
    encode = lambda value: (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + '\n').encode()
    filename = Path(config['source_path']).name
    files = {filename: encode(source), filename[:-5] + '.human-forms.json': encode(forms)}
    if config['schema_version'] in CREATION_CONFIGS:
        files['historical-claims.jsonl'] = b''.join(_canonical(claim) + b'\n' for claim in claims)
    if any(len(raw) > MAX_SET_BYTES for raw in files.values()):
        raise ValueError('initial source file exceeds its byte budget')
    provenance_contract = ({'ToS/contracts/provenance-event-v2.schema.json':
        _digest(_read(root / 'ToS/contracts/provenance-event-v2.schema.json', MAX_SET_BYTES))} if new_event else {})
    dependencies = _digest(_canonical({'records': records, 'claims': existing_claims,
        'source_profiles': profiles.input_digests,
        'native_semantic_identity_snapshot': profiles.native_identity_snapshot(read_bytes=_read),
        'native_text_binding_snapshot': profiles.native_text_snapshot(read_bytes=_read),
        'source_claim_profiles': claim_profile_inputs,
        **({'promotion_implementation': _digest(_read(ROOT /
            'mechanics/growth-cycle/parts/branch-growth-cycle/scripts/assessment_journal.py', MAX_SET_BYTES))}
           if config['schema_version'] == SIGN_CONFIG else {}),
        'provenance_contract': provenance_contract,
        'events': events, 'anchors': anchors, 'evidence': evidence, 'forms': form_inputs,
        'contracts': {ref: _digest(_read(root / ref, MAX_SET_BYTES)) for ref in (
            'ToS/contracts/historical-record.schema.json', 'ToS/contracts/corpus-record.schema.json',
            'ToS/contracts/historical-claim.schema.json', 'ToS/contracts/claim-packet.schema.json',
            'ToS/contracts/knowledge-assessment.schema.json',
            'ToS/doctrine/semantic-interchange/entity-types.v1.json',
            'ToS/doctrine/semantic-interchange/relation-types.v1.json')},
        'implementation': {ref: _digest(_read(ROOT / ref, MAX_SET_BYTES)) for ref in (
            'mechanics/growth-cycle/parts/branch-growth-cycle/scripts/source_commands.py', contract.MODULE_REF,
            'mechanics/growth-cycle/parts/branch-growth-cycle/scripts/source_historical_claims.py',
            'mechanics/growth-cycle/parts/branch-growth-cycle/scripts/human_forms.py',
            'mechanics/growth-cycle/parts/branch-growth-cycle/scripts/knowledge_assessment.py',
            'scripts/source_witness_human_forms.py', 'scripts/build_source_witness_catalog.py',
            'scripts/source_record_profiles.py',
            'scripts/native_text_binding.py',
            'scripts/source_owner_context.py',
            'scripts/source_witness_bibliographic_graph_common.py',
            'ToS/contracts/human-form.schema.json', 'ToS/contracts/human-form-set.schema.json',
            'ToS/contracts/human-form-template.schema.json')}}))
    return subject, files, dependencies


def _validator_for_provenance(root):
    return Draft202012Validator(_json_object(_read(
        root / 'ToS/contracts/provenance-event-v2.schema.json', MAX_SET_BYTES)))


def _capture_creation_provenance(config, request, files, started_at, started_ns,
                                 *, procedure_name=None, additional_software_refs=(),
                                 native_inputs=None, owner_local_metadata=False,
                                 public_native_inputs=None):
    """Capture the exact buffer serialization event.

    The event and its hash-bearing receipt travel with the atomic directory.
    Output digests describe serialized buffers; disk verification follows its
    own readback route.
    """
    base = Path(config['source_path']).parent
    script_ref = Path(__file__).resolve().relative_to(ROOT).as_posix()
    script_hash = _digest(_read(ROOT / script_ref, MAX_SET_BYTES))[7:]
    runtime = Path(sys.executable).resolve()
    with runtime.open('rb') as stream:
        runtime_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
    environment = {'runtime': platform.python_implementation(),
        'runtime_version': platform.python_version(), 'runtime_artifact_sha256': runtime_hash,
        'backend': 'python-standard-library-and-jsonschema', 'hardware_target': 'cpu',
        'unicode_version': unicodedata.unidata_version}
    original_outputs = dict(files)
    files['source-create-request.json'] = _canonical(request) + b'\n'
    files['source-create-environment.json'] = _canonical(environment) + b'\n'
    binding = lambda name: {'ref': (base / name).as_posix(), 'sha256': _digest(files[name])[7:]}
    ended_at = datetime.now(timezone.utc).isoformat()
    def entity(name, raw, role):
        return {'entity_ref': (base / name).as_posix(), 'role': role,
            'sha256': _digest(raw)[7:], 'size_bytes': len(raw),
            'media_type': 'application/x-ndjson' if name.endswith('.jsonl') else 'application/json',
            'availability': 'owner_local', 'content_disclosure': 'public_metadata_only',
            'fixity_verified': False, 'fixity_verified_at': None}
    event = {
        '$schema': 'https://tree-of-sophia.local/ToS/contracts/provenance-event-v2.schema.json',
        'schema_version': 'tos_provenance_event_v2', 'event_id': config['provenance_event_id'],
        'event_version': 1, 'supersedes_event_ref': None,
        'record_binding': {'manifest_ref': (base / 'source-create-receipt.json').as_posix(),
            'digest_algorithm': 'sha256', 'digest_scope': 'exact_event_record_bytes'},
        'activity': {'event_type': 'annotation', 'started_at': started_at, 'ended_at': ended_at,
            'status': 'completed_with_warnings', 'terminal_reason': None, 'exit_code': 0,
            'warnings': ['Completed serialization only; atomic publication occurs afterward.',
                         'Buffer hashes are captured; independent stored-byte fixity is not attested.']},
        'entities': {'inputs': [entity('source-create-request.json', files['source-create-request.json'],
                                      'caller-supplied-metadata-request')],
            'outputs': [entity(name, raw, 'serialized-source-metadata') for name, raw in original_outputs.items()],
            'byproducts': [entity('source-create-environment.json', files['source-create-environment.json'],
                                 'runtime-description')]},
        'derivations': [{'derivation_id': config['provenance_event_id'].replace('tos.event.', 'tos.derivation.', 1) + f'.output-{index}',
            'input_entity_ref': (base / 'source-create-request.json').as_posix(),
            'output_entity_ref': (base / name).as_posix(), 'relation': 'was_derived_from',
            'influence_asserted': True,
            'description': 'Technical metadata selection and serialization from the supplied request, not historical influence.'}
            for index, name in enumerate(original_outputs)],
        'responsibility': [{'agent_ref': 'software:tos-source-commands', 'agent_kind': 'software',
            'role': 'executor', 'responsibility_posture': 'performed',
            'evidence_binding': {'ref': script_ref, 'sha256': script_hash},
            'human_evidence_status': 'not_applicable'}],
        'method': {'procedure': {'name': (procedure_name or ('source-profile-metadata-serialization' if config['schema_version'] == PROFILE_CONFIG
                                        else 'historical-source-metadata-serialization')), 'version': '2',
            'purpose': 'Serialize supplied source records without judging their content.' if procedure_name else
                       'Serialize supplied source metadata and source-copy forms without judging their content.'},
            'command_capture': {'disclosure': 'withheld_digest_only', 'argv': None,
                'argv_sha256': _digest(_canonical(sys.argv))[7:],
                'withholding_reason': 'Process argv can contain private owner configuration paths; request is bound separately.'},
            'configuration_binding': binding('source-create-request.json'),
            'software_components': [{'name': 'ToS source commands', 'version': '2', 'role': 'serialization-runner',
                'artifact_ref': script_ref, 'artifact_sha256': script_hash, 'verification_status': 'verified'},
                {'name': environment['runtime'], 'version': environment['runtime_version'], 'role': 'language-runtime',
                 'artifact_ref': 'runtime:python-executable', 'artifact_sha256': runtime_hash, 'verification_status': 'verified'}],
            'model_invocations': [],
            'environment': {**environment, 'environment_profile_binding': binding('source-create-environment.json')}},
        'manual_changes': {'status': 'none_declared', 'change_receipts': [],
            'statement': 'No manual editing inside this serialization operation; caller authorship is outside its scope.'},
        'measurements': [{'metric': 'wall_duration_ms', 'status': 'measured',
            'value': (time.perf_counter_ns() - started_ns) / 1_000_000, 'unit': 'ms',
            'method': 'perf_counter_ns from pre-serialization validation through capture; excludes staging and commit.',
            'evidence_binding': None}],
        'evidence_authentication': {'capture_posture': 'tool_captured', 'signature_status': 'unsigned',
            'signature_bindings': [], 'verification_status': 'unverified',
            'producer_control_boundary': 'The same unsigned process serializes and records; hashes do not authenticate execution truth.'},
        'rights_and_visibility': {'rights_record_bindings': [], 'intended_uses': ['local_research', 'public_metadata'],
            'content_visibility': 'tracked_public_metadata', 'publication_authorized': False, 'publication_authority_bindings': []},
        'review_and_authority': {'mechanical_validation': 'not_run', 'human_review_status': 'not_performed',
            'review_bindings': [], 'accepted_uses': [], 'promotion_authorized': False, 'competence_evidence_bindings': []},
        'reproducibility': {'classification': 'partially_specified',
            'known_gaps': ['Upstream research, source reading and model invocations are not captured by this operation.',
                           'Dependencies are bound by the creation receipt; no complete runtime environment is archived.',
                           'Runtime timestamps and durations are not deterministic.'],
            'replay_scope': 'Supplied JSON and source-copy serialization only; not historical or semantic correctness.'},
        'authority_boundary': {'validator_role': 'mechanics_and_closure_only_not_truth',
            'claims_not_established': ['execution_truth', 'content_truth', 'source_fidelity', 'translation_quality',
                'semantic_correctness', 'rights_clearance', 'human_review', 'publication_authority', 'canon_authority']}}
    # Internal source-module refs, never request/config-selected executables.
    for ref in additional_software_refs:
        event['method']['software_components'].append({'name': ref, 'version': '1',
            'role': 'source-command-adapter', 'artifact_ref': ref,
            'artifact_sha256': _digest(_read(ROOT / ref, MAX_SET_BYTES))[7:],
            'verification_status': 'verified'})
    if native_inputs is not None:
        # Internal native adapter only. Source reading/anchor construction is
        # not metadata-only serialization; its whole receipt stays private.
        event['activity']['event_type'] = native_inputs.get('event_type', 'segmentation')
        event['activity']['warnings'][0] = (
            'Exact representation and native metadata verified; proposed anchors computed; '
            'atomic publication occurs afterward and no linguistic assessment is performed.')
        event['entities']['inputs'].extend(native_inputs['entities'])
        for group in event['entities'].values():
            for item in group:
                item['content_disclosure'] = 'private_content'
        event['method']['procedure']['purpose'] = (
            'Validate a delegated interval partition against exact source bytes and construct '
            'a new method-proposed native packet without accepting its linguistic analysis.')
        event['method']['configuration_binding'] = binding('source-create-owner-configuration.json')
        event['rights_and_visibility'].update(
            rights_record_bindings=native_inputs['rights'], intended_uses=['local_research'],
            content_visibility='local_only')
        for index, item in enumerate(native_inputs['entities']):
            event['derivations'].append({
                'derivation_id': config['provenance_event_id'].replace('tos.event.', 'tos.derivation.', 1) + f'.native-{index}',
                'input_entity_ref': item['entity_ref'],
                'output_entity_ref': config['source_path'], 'relation': 'selection_from',
                'influence_asserted': True,
                'description': 'Technical exact-source dependency for proposed native anchors, not historical influence.'})
        event['reproducibility']['known_gaps'][0] = (
            'Upstream transcription and caller linguistic analysis are not executed or authenticated here; '
            'the exact native source closure is bound by the command dependency snapshot.')
        event['reproducibility']['replay_scope'] = (
            'Exact source-byte verification and deterministic packet construction from the retained '
            'delegation/request, not linguistic correctness or deterministic provenance timestamps.')
        if native_inputs.get('event_type') == 'native_extraction':
            event['activity']['warnings'][0] = (
                'Exact acquired File and member verified; declared bounded structural extraction completed; '
                'atomic publication occurs afterward and no textual assessment is performed.')
            event['method']['procedure']['purpose'] = (
                'Extract a separately granted exact member/selector into an immutable unreviewed private '
                'TextLayer; no OCR, silent whitespace/Unicode rewrite or first segmentation.')
            event['reproducibility']['known_gaps'][0] = (
                'Source selection and rights decisions belong to the independent owner; this command '
                'captures bounded extraction mechanics without assessing source fidelity or content truth.')
            event['reproducibility']['replay_scope'] = (
                'Exact retained source/configuration/implementation and bounded extraction output; '
                'not textual correctness or deterministic provenance timestamps.')
            for group in event['entities'].values():
                for item in group:
                    if item['entity_ref'].endswith('/content.txt'):
                        item['media_type'] = 'text/plain; charset=utf-8'
        if native_inputs.get('native_alignment') is True:
            event['activity']['event_type'] = 'annotation'
            event['activity']['warnings'][0] = (
                'Both exact native text closures verified and a supplied mapping recorded; '
                'no aligner, translation or source-visible assessment executed; atomic publication follows.')
            event['method']['procedure']['purpose'] = (
                'Capture a supplied stand-off translation-alignment proposal against two exact native '
                'TextLayer/segmentation/anchor closures, with explicit record and Claim succession.')
            event['reproducibility']['known_gaps'][0] = (
                'Mapping, techniques, epistemic qualification and maker attribution are supplied proposals; '
                'no aligner execution, translation quality, semantic equivalence or review is established.')
            event['reproducibility']['replay_scope'] = (
                'Exact native source, retained request/configuration/implementation and immutable proposal '
                'construction; not execution of an upstream aligner or deterministic provenance timestamps.')
            for relation in event['derivations']:
                if relation['relation'] == 'selection_from':
                    relation['description'] = 'Exact source dependency for a supplied alignment proposal, not an executed aligner or translation equivalence.'
        if native_inputs.get('native_derivation') is not None:
            # Internal fixed TextLayer adapter only. In particular annotation
            # of supplied OCR bytes must never fabricate an OCR execution.
            native_operation = native_inputs['native_derivation']
            supplied = native_operation in {'text-layer.record-ocr', 'text-layer.record-transcription'}
            if native_operation not in {'text-layer.correct', 'text-layer.normalize',
                                        'text-layer.record-ocr', 'text-layer.record-transcription'}:
                raise ValueError('unsupported internal native derivation capture')
            event['activity']['warnings'][0] = (
                'Exact source File and supplied result fixity verified; result recorded without executing '
                'or authenticating the reported provider or transcription; atomic publication follows.' if supplied else
                'Exact predecessor verified; explicit proposed edits or the declared Unicode transform applied '
                'to a new layer; atomic publication follows and no source-fidelity assessment is performed.')
            event['method']['procedure']['purpose'] = (
                'Record a supplied source-bound result as a new unreviewed layer; no OCR engine, model, '
                'human transcription or source-selector execution is performed here.' if supplied else
                'Construct an immutable correction or Unicode-normalized successor from exact predecessor '
                'bytes and explicit method/configuration, without transferring predecessor quality or review.')
            event['reproducibility']['known_gaps'][0] = (
                'Reported upstream producer/method is supplied, not authenticated execution evidence; source '
                'fidelity, human competence and quality are unassessed.' if supplied else
                'Caller-supplied corrections remain proposals; deterministic Unicode mechanics do not prove '
                'source fidelity or transfer any predecessor accepted use.')
            event['reproducibility']['replay_scope'] = (
                'Exact retained source/result/configuration/implementation and immutable layer construction; '
                'no replay or attestation of an upstream provider, and no inherited quality or deterministic timestamps.')
            for relation in event['derivations']:
                if relation['relation'] == 'selection_from':
                    relation['description'] = 'Exact source/result dependency for additive layer construction, not provider execution or textual fidelity.'
            for group in event['entities'].values():
                for item in group:
                    if item['entity_ref'].endswith('/content.txt'):
                        item['media_type'] = 'text/plain; charset=utf-8'
    if owner_local_metadata:
        # Explicit internal private metadata adapter, never a caller flag.
        # This records serialization; it does not pretend to segment text.
        for group in event['entities'].values():
            for item in group:
                item['content_disclosure'] = 'private_content'
        event['method']['configuration_binding'] = binding('source-create-owner-configuration.json')
        event['rights_and_visibility'].update(intended_uses=['local_research'], content_visibility='local_only')
    if public_native_inputs is not None:
        if native_inputs is not None or owner_local_metadata:
            raise ValueError('public and confidential native capture are distinct internal adapters')
        event['activity']['event_type'] = 'native_extraction'
        event['activity']['warnings'][0] = (
            'Exact project-authored UTF-8 range and explicit partition captured; atomic source publication follows. '
            'No textual, linguistic, semantic or rights assessment was performed.')
        event['entities']['inputs'].extend(public_native_inputs['entities'])
        for group in event['entities'].values():
            for item in group:
                item['availability'] = 'tracked'
                item['content_disclosure'] = 'public_content'
                if item['entity_ref'].endswith('/content.txt'):
                    item['media_type'] = 'text/plain; charset=utf-8'
        event['method']['configuration_binding'] = binding('construction-plan.json')
        event['method']['procedure']['purpose'] = (
            'Capture a literal UTF-8 source range and proposed segmentation under independently supplied '
            'project-text public authority; preserve original source bytes and separate native identities.')
        event['rights_and_visibility'].update(rights_record_bindings=public_native_inputs['rights'],
            intended_uses=['public_metadata', 'publication'], content_visibility='public_content',
            publication_authorized=True, publication_authority_bindings=public_native_inputs['authority'])
        event['reproducibility']['known_gaps'][0] = (
            'Project authorship, licensing and delegated publication scope are supplied owner evidence, '
            'not granted or authenticated by this unsigned process; no model or human assessment is executed.')
        event['reproducibility']['replay_scope'] = (
            'Exact source range and proposed partition with bound inputs, implementation and public plan; '
            'not content correctness or deterministic timestamps. Protected grant paths are not published.')
        for index, item in enumerate(public_native_inputs['entities']):
            event['derivations'].append({
                'derivation_id': config['provenance_event_id'].replace('tos.event.', 'tos.derivation.', 1) + f'.public-native-{index}',
                'input_entity_ref': item['entity_ref'], 'output_entity_ref': config['source_path'],
                'relation': 'selection_from', 'influence_asserted': True,
                'description': 'Exact project-text construction dependency, not historical influence or assessment.'})
    _validator_for_provenance(Path(config['source_root'])).validate(event)
    files['source-create-provenance.jsonl'] = _canonical(event) + b'\n'


def _publish_new_directory(staging, target):
    """Linux no-replace rename: even an empty competing directory must survive."""
    libc = ctypes.CDLL(None, use_errno=True)
    try:
        rename = libc.renameat2
    except AttributeError:
        raise OSError(errno.ENOSYS, 'atomic no-replace directory creation is unavailable') from None
    rename.argtypes = [ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint]
    rename.restype = ctypes.c_int
    if rename(-100, os.fsencode(staging), -100, os.fsencode(target), 1) != 0:
        code = ctypes.get_errno()
        if code == errno.EEXIST:
            raise JournalConflict('subject directory was concurrently created')
        raise OSError(code, os.strerror(code))
    _sync_directory(target.parent)
    _sync_directory(staging.parent)


def _creation_replay(config, source_path, request, receipt):
    """Verify the original creation while permitting separately retained revisions.

    This is historical byte/lineage evidence, not current admission. The
    existing revision owner reads archives; no new history format is invented.
    """
    from source_revisions import _package, _selected_package, _selected_names, _history, _read_archive, HISTORY, _encode
    fields = {'schema_version', 'command_id', 'request_digest', 'principal_id', 'authority_ref',
              'owner_configuration', 'recorded_at', 'source_path', 'source', 'dependencies', 'files', 'grants_admission'}
    schema = ('tos_local_historical_create_receipt_v1' if config['schema_version'] in CREATION_CONFIGS
              else 'tos_local_source_create_receipt_v1')
    original = metadata_subject(request['record'])
    if (set(receipt) != fields or receipt['schema_version'] != schema
            or receipt['principal_id'] != config['principal_id']
            or receipt['authority_ref'] != config['authority_ref']
            or receipt['owner_configuration'] != request['expected_configuration']
            or receipt['dependencies'] != request['expected_dependencies']
            or receipt['source'] != original.ref or receipt['grants_admission'] is not False):
        raise JournalCorruption('creation receipt no longer binds its original request')
    _instant(receipt['recorded_at'])
    formname = source_path.stem + '.human-forms.json'
    expected_files = {source_path.name, formname}
    if config['schema_version'] in CREATION_CONFIGS:
        expected_files.add('historical-claims.jsonl')
    if config.get('provenance_event_id'):
        expected_files.update({'source-create-request.json', 'source-create-environment.json', 'source-create-provenance.jsonl'})
    if not isinstance(receipt['files'], dict) or set(receipt['files']) != expected_files:
        raise JournalCorruption('creation receipt file closure changed')
    history_path = source_path.parent / HISTORY
    selected_history = (os.path.lexists(history_path)
        and _json_object(_read(history_path, MAX_SET_BYTES)).get('schema_version') == 'tos_source_revision_history_v2')
    if selected_history or config['schema_version'] == ARTIFACT_CREATION_CONFIG:
        # Later explicitly selected corrections may coexist with descendants.
        # Rechecking a historical creation reads only its exact original files;
        # it does not retrospectively widen the old creation write grant.
        files = _selected_package(source_path)
        for name in sorted(expected_files | {'source-create-receipt.json'}):
            if name not in files:
                files[name] = _read(source_path.parent / name, MAX_SET_BYTES)
    else:
        files = _package(source_path.parent)
    extras = set(files) - expected_files - {'source-create-receipt.json'}
    lockname = '.' + formname + '.writer.lock'
    legacy_initial_claims, legacy_additions = None, set()
    if config['schema_version'] in CREATION_CONFIGS and extras - {HISTORY, lockname}:
        from source_historical_claims import creation_lineage
        legacy_initial_claims, legacy_additions = creation_lineage(Path(config['source_root']), source_path, files, request)
    if extras - {HISTORY, lockname} - legacy_additions or files.get(lockname, b''):
        raise JournalCorruption('creation package contains unbound files')
    if not expected_files <= files.keys():
        raise JournalCorruption('creation package is incomplete')
    record = _json_object(files[source_path.name])
    history = _history(files, record)
    original_files = files
    for index, revision in enumerate(history['receipts']):
        archived, _ = _read_archive(Path(config['source_root']), config, revision)
        selected_revision = 'publication' in revision
        if selected_revision and (
                revision['publication']['selected_files'] != sorted(_selected_names(source_path))
                or not set(archived) <= set(_selected_names(source_path))):
            raise JournalCorruption('retained correction exceeds its selected metadata scope')
        if not selected_revision and archived.get('source-create-receipt.json') != files['source-create-receipt.json']:
            raise JournalCorruption('creation receipt changed across source history')
        if index == 0:
            if revision['previous_source'] != original.ref:
                raise JournalCorruption('source history does not start at the created record')
            original_files = archived
    if not history['receipts'] and metadata_subject(record).ref != original.ref:
        raise JournalCorruption('created source changed without retained revision history')
    forms = _json_object(files[formname])
    _validate_history(forms)
    if forms['subject']['id'] != original.id:
        raise JournalCorruption('created form set belongs to another subject')
    initial_forms = {(form['form_id'], form['form_version']): form for form in [*forms['forms'], *forms['prior_forms']]}
    selected = [initial_forms.get((selection['form_id'], 1)) for selection in request['forms']]
    if any(form is None or form['subject'] != original.ref for form in selected):
        raise JournalCorruption('initial forms are not retained against the created source')
    # The initial serializer's ordering is part of its exact byte contract;
    # later form revisions canonicalize dictionaries while retaining values.
    initial_changes = [prepare_metadata_change(request['record'], None, receipt['principal_id'], **selection)
                       for selection in request['forms']]
    retained_set = _apply(None, original, initial_changes)
    if selected != retained_set['forms']:
        raise JournalCorruption('retained initial forms no longer match the source-copy request')
    for name, binding in receipt['files'].items():
        raw = original_files[name] if name == source_path.name else files[name]
        if name == 'historical-claims.jsonl' and legacy_initial_claims is not None:
            raw = legacy_initial_claims
        if name == formname and (forms['prior_forms'] or forms.get('growth_history')):
            raw = _encode(retained_set)
        if binding != {'sha256': _digest(raw), 'bytes': len(raw)}:
            raise JournalCorruption('creation output bytes no longer match their retained binding')
    if config.get('provenance_event_id') and _json_object(files['source-create-request.json']) != request:
        raise JournalCorruption('captured creation request changed')
    _snapshot(source_path, Path(config['source_root']))  # Fresh source visibility/profile checks, not admission.


def _create_source(owner_config, config, configuration, source_path, request):
    artifact_creation = config['schema_version'] == ARTIFACT_CREATION_CONFIG
    profile_creation = config['schema_version'] in {*PROFILE_CREATION_CONFIGS, *CORPUS_CREATION_CONFIGS, ARTIFACT_CREATION_CONFIG}
    corpus_creation = config['schema_version'] in CORPUS_CREATION_CONFIGS
    creation_operation = 'sign.promote' if config['schema_version'] == SIGN_CONFIG else 'source.create' if profile_creation else CREATION_OPERATION
    command_handler(config['schema_version']).validate_request(request)
    root, target = Path(config['source_root']), source_path.parent
    os.close(_owned_path(target.parent, directory=True))
    if artifact_creation:
        from source_artifact_commands import record_profile
        profile = record_profile(config)
    else:
        profile = (_configured_corpus_profile(config) if corpus_creation else _configured_profile(config)[1]) if profile_creation else None
    def result(receipt=None, replayed=False):
        return {'schema_version': ('tos_local_source_create_result_v1' if profile_creation else 'tos_local_historical_create_result_v1'),
            'authentication': 'local-unix-account', 'owner_configuration': configuration,
            'source_path': config['source_path'], 'record_id': config['record_id'],
            'target_exists': target.exists(), 'supported_operations': [creation_operation],
            'command_operations': ['describe', 'prepare', 'prepare-create', creation_operation],
            'allowed_operations': config['allowed_operations'],
            **({'source_profile': profile, **({'record_type': 'artifact'} if artifact_creation else {'record_type': config['record_type']} if corpus_creation else
                                             {'profile_type_id': config['profile_type_id']})} if profile_creation else {
                'allowed_claim_ids': config['allowed_claim_ids'],
                'record_schema_ref': 'ToS/contracts/historical-record.schema.json',
                'claim_schema_ref': 'ToS/contracts/historical-claim.schema.json'}),
            'allowed_form_ids': config['allowed_form_ids'], 'expected_source': None, 'expected_revision': None,
            'creation_provenance_event_id': config.get('provenance_event_id'),
            'receipt': receipt, 'replayed': replayed, 'grants_admission': False}
    if request['operation'] == 'describe':
        response = result()
        if config['schema_version'] == SIGN_CONFIG:
            response['promotion'] = _sign_promotion(config, require_ready=False)
        return response
    if creation_operation not in config['allowed_operations']:
        raise PermissionError('source creation is not delegated')
    if request['operation'] == 'prepare':
        subject = _initial_source_record(config, request['record'])
        response = result()
        response['prepared_source'] = subject.ref
        response['source_fields'] = [{key: value for key, value in field.items() if key not in ('pointer', 'context')}
                                    for field in metadata_field_catalog(request['record'])]
        return response
    _creation_scope(config, request)
    if request['operation'] == 'prepare-create':
        subject, files, dependencies = _prepare_creation(config, request)
        response = result()
        response.update(prepared_source=subject.ref, expected_dependencies=dependencies,
                        prepared_files={name: {'sha256': _digest(raw), 'bytes': len(raw)} for name, raw in files.items()})
        response['capture_at_apply'] = (['source-create-request.json', 'source-create-environment.json',
            'source-create-provenance.jsonl'] if config.get('provenance_event_id') else [])
        return response
    if not isinstance(request['command_id'], str) or not 1 <= len(request['command_id']) <= 256:
        raise ValueError('command identity must contain one to 256 characters')
    request_digest = _digest(_canonical(request))
    # Stable corpus lock coordinates creation, form writers and source revisions.
    with _locked(root / 'ToS/source-witnesses/historical-create'):
        _, current_digest, current_path = _configuration(owner_config)
        if current_path != source_path or current_digest != configuration:
            raise JournalConflict('creation delegation changed before transaction')
        receipt_path = target / 'source-create-receipt.json'
        if target.exists() or target.is_symlink():
            os.close(_owned_path(target, directory=True))
            try:
                receipt = _json_object(_read(receipt_path, MAX_COMMAND_BYTES))
            except FileNotFoundError:
                raise JournalConflict('existing subject directory is not this creation') from None
            if (receipt.get('command_id') != request['command_id'] or receipt.get('request_digest') != request_digest
                    or receipt.get('source_path') != config['source_path']):
                raise JournalConflict('creation target or command identity is already occupied')
            _creation_replay(config, source_path, request, receipt)
            return result(receipt, True)
        if (request['expected_configuration'] != configuration or request['expected_source'] is not None
                or request['expected_revision'] is not None):
            raise JournalConflict('creation requires exact delegation and absent source/revision')
        started_at, started_ns = datetime.now(timezone.utc).isoformat(), time.perf_counter_ns()
        subject, files, dependencies = _prepare_creation(config, request)
        if request['expected_dependencies'] != dependencies:
            raise JournalConflict('prepared creation dependencies are stale')
        if config.get('provenance_event_id'):
            _capture_creation_provenance(config, request, files, started_at, started_ns,
                procedure_name='sign-promoted-identity-serialization' if config['schema_version'] == SIGN_CONFIG
                else 'native-artifact-metadata-serialization' if artifact_creation
                else 'source-corpus-metadata-serialization' if corpus_creation else None,
                additional_software_refs=('mechanics/growth-cycle/parts/branch-growth-cycle/scripts/source_artifact_commands.py',)
                    if artifact_creation else ())
        receipt = {'schema_version': ('tos_local_source_create_receipt_v1' if profile_creation else 'tos_local_historical_create_receipt_v1'),
            'command_id': request['command_id'], 'request_digest': request_digest,
            'principal_id': config['principal_id'], 'authority_ref': config['authority_ref'],
            'owner_configuration': configuration, 'recorded_at': datetime.now(timezone.utc).isoformat(),
            'source_path': config['source_path'], 'source': subject.ref, 'dependencies': dependencies,
            'files': {name: {'sha256': _digest(raw), 'bytes': len(raw)} for name, raw in files.items()},
            'grants_admission': False}
        files['source-create-receipt.json'] = _canonical(receipt) + b'\n'
        # Outside source-witnesses, so every existing scanner sees either the
        # complete published directory or nothing, including after process loss.
        staging = Path(tempfile.mkdtemp(prefix='.source-create-', suffix='.pending', dir=root / 'ToS'))
        try:
            for name, raw in files.items():
                _publish(staging / name, raw)
            with _sign_promotion_lock(config) if config['schema_version'] == SIGN_CONFIG else nullcontext():
                current_dependencies = _prepare_creation(config, request)[2]
                if (_configuration(owner_config)[1] != configuration or current_dependencies != dependencies):
                    raise JournalConflict('creation configuration or source dependencies changed')
                _publish_new_directory(staging, target)
        finally:
            if staging.exists():
                # Exact private staging directory and only this call's files.
                for name in files:
                    (staging / name).unlink(missing_ok=True)
                staging.rmdir()
        return result(receipt)


def run_legacy_oracle_command(owner_config: Path | None, request: dict):
    """Retained Python oracle for behavior not yet replaced by a whole native consumer."""
    if not isinstance(request, dict) or len(_canonical(request)) > MAX_COMMAND_BYTES:
        raise ValueError('source command exceeds the 1 MiB input budget')
    request = _json_object(_canonical(request))  # Freeze caller-owned mutable input.
    if request.get('schema_version') == DISCOVERY_REQUEST:
        if owner_config is not None:
            raise ValueError('discovery takes no owner configuration or target')
        return discover_commands(request)
    if owner_config is None:
        raise PermissionError('source commands require an independently selected owner configuration')
    config, configuration, source_path = _configuration(owner_config)
    handler = command_handler(config['schema_version'])
    handler.validate_request(request)
    if handler.manages_publication:
        return handler.run(owner_config, config, configuration, source_path, request)
    from source_metadata_snapshot import PublicationSnapshot
    snapshot = PublicationSnapshot(Path(config['source_root'])) if 'source_root' in config else None
    result = handler.run(owner_config, config, configuration, source_path, request)
    if snapshot is not None:
        snapshot.verify_current()
    return result


def run_local_command(owner_config: Path | None, request: dict, *, native_invocation: Path | None = None):
    """Default owned execution uses an explicitly selected protected native invocation."""
    if request.get('schema_version') == DISCOVERY_REQUEST:
        if owner_config is not None or native_invocation is not None:
            raise ValueError('discovery takes no owner selection')
        return discover_commands(request)
    if native_invocation is None:
        raise PermissionError('select --owner-config and --native-invocation using docs/RELEASING.md; retained Python oracle requires --legacy-oracle')
    return _run_selected_native_owner(owner_config, native_invocation, request)


def _run_selected_native_owner(owner_config: Path, invocation_path: Path, request: dict):
    """Default local native route. The selected invocation is evidence, not a grant."""
    deadline = time.monotonic() + 60
    if owner_config is None:
        raise PermissionError('native owner requires an owner configuration')
    assessed_forms_request = (
        request.get('schema_version') == NATIVE_ASSESSED_FORMS_REQUEST_SCHEMA
        and request.get('operation') == NATIVE_ASSESSED_FORMS_OPERATION)
    if ((request.get('schema_version') == NATIVE_ASSESSED_FORMS_REQUEST_SCHEMA
         or request.get('operation') == NATIVE_ASSESSED_FORMS_OPERATION)
            and not assessed_forms_request):
        raise PermissionError('native assessed-form operation requires its exact request profile')
    owner_config_limit = (MAX_ASSESSED_OWNER_CONFIG_BYTES
                          if assessed_forms_request else MAX_COMMAND_BYTES)
    # This route alone retains the bounded assessment owner's larger snapshot.
    with os.fdopen(_owned_path(owner_config), 'rb') as selected:
        info = os.fstat(selected.fileno())
        if info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) != 0o600:
            raise PermissionError('native owner configuration must be private owner bytes')
        config_raw = selected.read(owner_config_limit + 1)
    if len(config_raw) > owner_config_limit:
        raise ValueError('native owner configuration exceeds the input budget')
    config = _json_object(config_raw)
    schema = config.get('schema_version')
    if not isinstance(schema, str):
        raise ValueError('native owner configuration has no schema discriminator')
    if assessed_forms_request and schema != PUBLIC_ASSESSMENT_OWNER_V2:
        raise PermissionError('assessed-form materialization accepts only public assessment owner v2')
    claim = schema.startswith(('tos_local_claim_create_owner_v', 'tos_local_claim_revision_owner_v',
                               'tos_local_document_catalogue_date_', 'tos_local_identity_proposal_')) or schema == 'tos_local_claim_layer_revision_owner_v1'
    item = schema == 'tos_local_item_adoption_owner_v1'
    collection = config['schema_version'] == 'tos_local_collection_membership_owner_v1'
    alignment = config['schema_version'] == 'tos_local_native_alignment_owner_v1'
    source = not item and not claim and not alignment and not collection
    if len(_canonical(request)) > MAX_COMMAND_BYTES:
        raise ValueError('source command exceeds the 1 MiB input budget')
    operations = (('describe', 'prepare-attach', 'collection.work.attach', 'collection.work.recover') if collection else
                  ('describe', 'prepare-create', 'claims.create', 'prepare-revise', 'claim.revise', 'inspect-version') if claim else
                  ('describe', 'prepare-create', 'item.adopt', 'item.adoption.recover') if item else
                  ('describe', 'prepare-create', 'prepare-revise', 'alignment.create', 'alignment.revise',
                   'inspect', 'inspect-version', 'inspect-recovery'))
    if not source and request['operation'] not in operations:
        raise PermissionError('native invocation operation is not implemented')
    with os.fdopen(_owned_path(invocation_path), 'rb') as selected:
        info = os.fstat(selected.fileno())
        if info.st_uid != os.getuid() or stat.S_IMODE(info.st_mode) != 0o600:
            raise PermissionError('native invocation must be private owner bytes')
    raw = _read(invocation_path, MAX_COMMAND_BYTES)
    invocation = _json_object(raw)
    publication_profile = invocation.get('schema_version')
    assessment_read_invocation = assessed_forms_request
    publication = source and publication_profile in (
        'tos_local_native_agent_publication_invocation_v1',
        'tos_local_native_metadata_publication_invocation_v1')
    keys = {'schema_version', 'owner_config', 'native_executable', 'native_executable_sha256',
            'corpus_store', 'source_revision', 'software_capture', 'software_restored_root',
            'software_selection', 'software_components', 'schema_worker', 'budgets'}
    keys.add('original_source_revision' if item or claim or collection or assessment_read_invocation else 'owner_context')
    if source and not assessment_read_invocation:
        keys.update(('original_source_revision', 'assessment_schema_worker'))
    elif assessment_read_invocation:
        keys.add('assessment_schema_worker')
    if publication:
        keys.update(('prepared_database', 'expected_binding_path', 'source_inputs_path',
                     'source_inputs_sha256', 'catalog_path', 'catalog_sha256',
                     'descriptor_path', 'descriptor_sha256', 'publication_limits',
                     'reviewed_execution_transition'))
        if publication_profile == 'tos_local_native_metadata_publication_invocation_v1':
            keys.update(('reviewed_metadata_transition', 'expected_creation_receipt_sha256',
                         'expected_creation_request_digest'))
    profile = (publication_profile if publication else
               'tos_local_native_collection_invocation_v1' if collection else
               'tos_local_native_claim_invocation_v1' if claim else
               'tos_local_native_item_invocation_v1' if item else
               'tos_local_native_assessment_read_invocation_v1' if assessment_read_invocation else
               'tos_local_native_source_invocation_v1' if source else 'tos_local_native_owner_invocation_v1')
    if (invocation.get('schema_version') != profile or invocation.get('owner_config') != str(owner_config)
            or set(invocation) != keys):
        raise PermissionError('native invocation does not select this owner')
    output_limit = (MAX_ASSESSED_FORMS_RESPONSE_BYTES
                    if assessed_forms_request and schema == PUBLIC_ASSESSMENT_OWNER_V2
                    else MAX_COMMAND_BYTES)
    executable = Path(invocation['native_executable'])
    descriptor = _owned_path(executable)
    try:
        info = os.fstat(descriptor)
        if (not info.st_mode & stat.S_IXUSR or info.st_mode & 0o022
                or info.st_mode & (stat.S_ISUID | stat.S_ISGID | stat.S_ISVTX)):
            raise PermissionError('native executable owner/mode')
        with tempfile.TemporaryFile() as source_input, tempfile.TemporaryFile() as output, tempfile.TemporaryFile() as errors:
            source_input.write(_canonical(request))
            source_input.seek(0)
            child = subprocess.Popen([f'/proc/self/fd/{descriptor}', '--invocation', str(invocation_path)],
                                     pass_fds=(descriptor,), stdin=source_input,
                                     stdout=output, stderr=errors, start_new_session=True)
            try:
                while child.poll() is None:
                    if (time.monotonic() >= deadline or output.tell() > output_limit
                            or errors.tell() > MAX_COMMAND_BYTES):
                        os.killpg(child.pid, signal.SIGKILL)
                        child.wait()
                        raise ValueError('bounded native owner command refused')
                    time.sleep(0.01)
            finally:
                if child.poll() is None:
                    os.killpg(child.pid, signal.SIGKILL)
                    child.wait()
            if (time.monotonic() >= deadline or output.tell() > output_limit
                    or errors.tell() > MAX_COMMAND_BYTES):
                raise ValueError('native owner command refused')
            if child.returncode != 0:
                errors.seek(0)
                reason = errors.read(4096).decode('utf-8', errors='replace').strip()
                raise ValueError('native owner command refused' + (': ' + reason if reason else ''))
            output.seek(0)
            response = _json_object(output.read(output_limit + 1))
            expected_result = ('tos_local_native_source_result_v1' if assessed_forms_request else
                               'tos_collection_membership_result_v1' if collection else
                               'tos_local_native_claim_result_v1' if claim else
                               'tos_edition_item_result_v1' if item else
                               'tos_expression_edition_result_v1' if schema == 'tos_local_expression_edition_owner_v1' else
                               'tos_expression_responsibility_result_v1' if schema == 'tos_local_expression_responsibility_owner_v1' else
                               'tos_local_assessment_result_v1' if schema in (
                                   'tos_local_assessment_owner_v1', 'tos_local_assessment_owner_v2',
                                   'tos_local_assessment_owner_v3', 'tos_local_assessment_owner_v4', 'tos_local_assessment_owner_v5',
                                   'tos_local_assessment_owner_v6') else
                               'tos_local_native_source_result_v1' if source else
                               'tos_local_native_alignment_result_v1')
            if publication and publication_profile == 'tos_local_native_metadata_publication_invocation_v1':
                expected_result = {
                    'describe-metadata-execution': 'tos_local_native_metadata_execution_v1',
                    'reviewed-metadata-execution-bootstrap': 'tos_local_native_metadata_publication_result_v1',
                    'publish-initial-metadata': 'tos_local_native_metadata_publication_result_v1',
                }.get(request.get('action'))
                if (expected_result is None or response.get('grants_admission') is not False
                        or not isinstance(response.get('result'), dict)):
                    raise ValueError('native Metadata result profile')
            if response.get('schema_version') != expected_result:
                raise ValueError('native owner result profile')
            if assessed_forms_request and (
                    response.get('grants_admission') is not False
                    or not isinstance(response.get('result'), dict)
                    or response['result'].get('schema_version') != NATIVE_ASSESSED_FORMS_RESULT_SCHEMA):
                raise ValueError('native assessed-form materialization result profile')
            return response
    finally:
        os.close(descriptor)


def _run_configured_command(owner_config, config, configuration, source_path, request):
    return command_handler(config['schema_version']).run(owner_config, config, configuration, source_path, request)


def _run_form_command(owner_config, config, configuration, source_path, request):
    canonical = config['schema_version'] in CANONICAL_FORM_CONFIGS
    claim_id = config['claim_id'] if config['schema_version'] in CLAIM_FORM_CONFIGS else None
    field_catalog = (canonical_field_catalog if canonical else
                     claim_field_catalog if claim_id is not None else metadata_field_catalog)
    materialize = (materialize_canonical_forms if canonical else
                   materialize_claim_forms if claim_id is not None else materialize_metadata_forms)
    prepare_change = (prepare_canonical_change if canonical else
                      prepare_claim_change if claim_id is not None else prepare_metadata_change)
    operation = request.get('operation')
    command_handler(config['schema_version']).validate_request(request)
    source_root = Path(config['source_root'])
    snapshot = _snapshot(source_path, source_root, claim_id, canonical=canonical)
    source_contracts = (_claim_form_source(source_path, source_root, claim_id)[2]
                        if claim_id is not None else
                        _canonical_form_source(source_path, source_root)[2]
                        if canonical else
                        _native_form_source(source_path, source_root)[2]
                        if source_path.name in {'artifact-witness.json', 'composite-witness.json'} else None)
    if source_contracts is not None and configuration != _digest(_canonical({
            'configuration': config, 'source_contracts': source_contracts})):
        raise JournalConflict('canonical node schema contract changed before command preparation'
                              if canonical else 'Claim form source contracts changed before command preparation')

    def result(snapshot, receipt=None, replayed=False):
        _, source, subject, target, raw, payload = snapshot
        return {'schema_version': 'tos_local_source_command_result_v1',
                'authentication': 'local-unix-account', 'owner_configuration': configuration,
                'source': subject.ref, 'source_path': config['source_path'],
                'target_path': target.relative_to(Path(config['source_root'])).as_posix(),
                'revision': _digest(raw) if raw is not None else None,
                'supported_operations': list(OPERATIONS), 'allowed_operations': config['allowed_operations'],
                'command_operations': ['describe', 'prepare', 'apply'],
                'source_fields': [{key: value for key, value in field.items() if key not in ('pointer', 'context')}
                                  for field in field_catalog(source)],
                'allowed_form_ids': config['allowed_form_ids'],
                **({'allowed_field_ids': _claim_form_field_ids(config)} if claim_id is not None else {}),
                **({'source_contracts': source_contracts} if source_contracts is not None else {}),
                'forms': [_form_ref(form) for form in payload['forms']] if payload else [],
                'materializations': materialize(source, payload, access_allowed=True) if payload else [],
                'receipt': receipt, 'replayed': replayed, 'grants_admission': False}

    if operation == 'describe':
        return result(snapshot)
    if operation == 'prepare':
        source_raw, source, subject, target, raw, payload = snapshot
        if request['form_id'] not in config['allowed_form_ids']:
            raise PermissionError('prepared form is outside the delegated identity scope')
        change = prepare_change(source, payload, config['principal_id'], request['form_id'], request['field_id'],
                                **({'allowed_field_ids': _claim_form_field_ids(config)} if claim_id is not None else {}))
        if claim_id is not None:
            _check_claim_form_changes(config, [change], payload['forms'] if payload else (),
                                      historical_forms=payload.get('prior_forms', ()) if payload else ())
        if canonical:
            _check_canonical_form_changes([change], payload['forms'] if payload else (),
                                          historical_forms=payload.get('prior_forms', ()) if payload else ())
        if change['operation'] not in config['allowed_operations']:
            raise PermissionError('prepared operation is not delegated')
        response = result(snapshot)
        response['prepared_change'] = change
        # Preview the proposed exact source copy through the same owner reader
        # used after apply. The in-memory successor is not a source write or
        # assessment; old materializations must not stand in for this preview.
        proposed = _apply(payload, subject, [change])
        preview = next(view for view in materialize(source, proposed, access_allowed=True)
                       if view['form']['id'] == change['form']['form_id'])
        if preview['state'] != 'ready':
            raise ValueError('prepared source-copy does not satisfy the source metadata reader')
        response['prepared_materialization'] = preview
        return response
    changes = _changes(request, config)
    if not isinstance(request['command_id'], str) or not 1 <= len(request['command_id']) <= 256:
        raise ValueError('command identity must contain one to 256 characters')
    request_digest = _digest(_canonical(request))
    owner_lock = (source_root / 'ToS/canon/.canonical-human-forms-lock'
                  if canonical else source_root / 'ToS/source-witnesses/historical-create')
    with _locked(owner_lock), _locked(snapshot[3]):
        config, configuration, current_source_path = _configuration(owner_config)
        if current_source_path != source_path or config.get('claim_id') != claim_id:
            raise JournalConflict('owner source route changed before the transaction')
        if source_contracts is not None and configuration != _digest(_canonical({
                'configuration': config, 'source_contracts': source_contracts})):
            raise JournalConflict('canonical node schema contract changed before transaction'
                                  if canonical else 'Claim form source contracts changed before transaction')
        changes = _changes(request, config)  # Current revocation also applies to replay.
        snapshot = _snapshot(source_path, Path(config['source_root']), claim_id, canonical=canonical)
        source_raw, source, subject, target, raw, payload = snapshot
        if claim_id is not None:
            _check_claim_form_changes(config, changes, historical_forms=(
                [*payload['forms'], *payload.get('prior_forms', ())] if payload else ()))
        if canonical:
            _check_canonical_form_changes(changes, historical_forms=(
                [*payload['forms'], *payload.get('prior_forms', ())] if payload else ()))
        for receipt in payload.get('growth_history', []) if payload else []:
            if receipt['command_id'] == request['command_id']:
                if receipt['request_digest'] != request_digest:
                    raise JournalConflict('command identity was reused for different input')
                if claim_id is not None and receipt['results'] != [_form_ref(change['form']) for change in changes]:
                    raise JournalCorruption('Claim form receipt differs from its exact request results')
                return result(snapshot, receipt, True)
        if claim_id is not None:
            _check_claim_form_changes(config, changes, payload['forms'] if payload else ())
        if canonical:
            _check_canonical_form_changes(changes, payload['forms'] if payload else ())
        if (request['expected_source'] != subject.ref or request['expected_configuration'] != configuration
                or request['expected_revision'] != (_digest(raw) if raw is not None else None)):
            raise JournalConflict('expected source, configuration or form-set revision is stale')
        value = _apply(payload, subject, changes)
        # Source-copy must satisfy the real existing reader, including its
        # independently selected mandatory context. Other modes are stored as
        # unassessed source proposals, never rendered by this metadata adapter.
        views = {view['form']['id']: view for view in materialize(source, value, access_allowed=True)}
        for change in changes:
            if change['form']['content']['kind'] == 'source-copy' and views[change['form']['form_id']]['state'] != 'ready':
                raise ValueError('source-copy does not satisfy the source metadata reader')
        receipt = {'command_id': request['command_id'], 'request_digest': request_digest,
                   'principal_id': config['principal_id'], 'authority_ref': config['authority_ref'],
                   'owner_configuration': configuration, 'recorded_at': datetime.now(timezone.utc).isoformat(),
                   **({'source_contracts': source_contracts} if source_contracts is not None else {}),
                   'source': subject.ref, 'previous_revision': request['expected_revision'],
                   'results': [_form_ref(change['form']) for change in changes]}
        value.setdefault('growth_history', []).append(receipt)
        _validate_history(value)
        encoded = (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + '\n').encode()
        if len(encoded) > MAX_SET_BYTES:
            raise ValueError('source-command history exceeds the 2 MiB form-set budget')
        # Cooperating command writers hold the same lock. Editors/configuration
        # publishers must keep their files stable for the command duration.
        if _configuration(owner_config)[1] != configuration or _read(source_path, MAX_COMMAND_BYTES) != source_raw:
            raise JournalConflict('owner configuration or source changed before publication')
        try:
            latest = _read(target, MAX_SET_BYTES)
        except FileNotFoundError:
            latest = None
        if latest != raw:
            raise JournalConflict('form set changed outside the command lock')
        _publish(target, encoded)
        return result((source_raw, source, subject, target, encoded, value), receipt)


def _builtin_handlers():
    form_ops = (contract.describe(),
        contract.operation('prepare', {'field_id', 'form_id'}, definition='Prepare one source-copy form for an explicit field.', grants=OPERATIONS),
        contract.operation('apply', {'command_id', 'expected_source', 'expected_revision', 'expected_configuration', 'changes'},
            definition='Create or revise explicitly selected forms while retaining predecessors.', mutation='human_forms', grants=OPERATIONS))
    forms = contract.Handler('public-source-forms', ('tos_local_source_command_owner_v1', CLAIM_FORM_CONFIG, CLAIM_DISPLAY_FORM_CONFIG),
        form_ops, _run_form_command, 'Human forms of existing public native/profile metadata or one declared Claim.',
        typed_handles=(*contract.FORM_HANDLES, *contract.RECORD_HANDLES, *contract.CLAIM_HANDLES,
                       'ToS/contracts/claim-display-fields.schema.json'),
        preconditions=('Form writes cannot change the source record or Claim, and require exact delegated form identities.',
            'Claim v1 copies only the statement; v2 separately scopes exact known display fields and requires whole-Claim context.',))
    canonical_forms = contract.Handler('canonical-node-forms', (CANONICAL_FORM_CONFIG,), form_ops,
        _run_form_command, 'Human forms of existing versioned canonical ToS nodes.',
        typed_handles=(*contract.FORM_HANDLES, CANONICAL_NODE_SCHEMA_REF),
        profile_selection='Requires the exact native tos_canonical_node_v1 source at ToS/canon/.../node.json; legacy nodes are refused.',
        preconditions=('Canonical form writes cannot create or revise node records, and copy only the complete native node as context.',
                       'The canonical owner configuration is separate from legacy source-form grants.',))
    def creator(identifier, schemas, name, definition, handles, *, historical=False, selection=None, preconditions=()):
        proposal = {'record', 'forms'} | ({'claims'} if historical else set())
        return contract.Handler(identifier, tuple(schemas), (contract.describe(),
            contract.operation('prepare', {'record'}, definition='Inspect candidate source-copy field selectors.', grants=(name,)),
            contract.operation('prepare-create', proposal, definition='Prepare the exact initial source package without publishing it.', grants=(name,)),
            contract.operation(name, proposal | contract.COMMIT_KEYS, definition=definition, mutation='new_source_package', grants=(name,))),
            _create_source, definition, typed_handles=(*handles, *contract.FORM_HANDLES),
            profile_selection=selection or 'Exact source schema and typed identity are checked by the creation handler.',
            preconditions=('Requires an absent source home, initial identity/version and explicitly selected source-copy forms.', *preconditions))
    return (forms, canonical_forms,
        creator('historical-source-create', sorted(CREATION_CONFIGS), CREATION_OPERATION,
            'Create one HistoricalEvent, HistoricalProcess or HistoricalState with its bounded initial Claims.',
            ('ToS/contracts/historical-record.schema.json', 'ToS/contracts/historical-claim.schema.json'), historical=True),
        creator('public-profile-create', (PROFILE_CONFIG,), 'source.create',
            'Create one public source metadata record supported by an existing declared profile.', contract.RECORD_HANDLES,
            selection='Select profile_type_id in entity-types.v1.json; source_record_profile supplies the exact schema, not a write grant.',
            preconditions=('Sign requires the separate sign.promote handler and cannot use this generic route.',)),
        creator('native-corpus-create', sorted(CORPUS_CREATION_CONFIGS), 'source.create',
            'Create one provisional standalone native identity; version 2 adds an empty Collection.',
            ('ToS/contracts/corpus-record.schema.json',),
            selection='Version 1: agent, place, organization, work. Version 2 additionally allows collection with no membership assertions; no Expression/Edition or role-subclass creation.',
            preconditions=('The Nietzsche Work home retains its stronger authorship and chronology route.',)),
        creator('sign-promotion', (SIGN_CONFIG,), 'sign.promote',
            'Issue a Sign source identity from an independently assessed eligible exact candidate.',
            ('ToS/contracts/sign-description-record.schema.json', *contract.RECORD_HANDLES,
             'ToS/doctrine/KNOWLEDGE_ASSESSMENT.md'),
            selection='Only tos.entity.sign and its declared sign-promotion-v1 gate.',
            preconditions=("Requires separate public source-bound assessment-owner selection and current sign-promotion admission from that owner.",)))


@lru_cache(maxsize=1)
def command_handlers():
    """Fixed implementation imports, never a request/registry-selected executable."""
    import source_claim_commands
    import claim_revisions
    import source_revisions
    import source_selected_revisions
    import source_native_metadata_commands
    import source_text_unit_commands
    import source_text_layer_commands
    import source_alignment_commands
    import source_owner_profile_commands
    import source_owner_claim_commands
    import source_expression_commands
    import source_responsibility_commands
    import source_edition_commands
    import source_item_commands
    import source_collection_commands
    import source_artifact_commands
    import source_link_commands
    import source_public_native_commands
    import source_historical_claims
    handlers = (*_builtin_handlers(), *(handler for module in (
        source_claim_commands, claim_revisions, source_revisions, source_selected_revisions, source_native_metadata_commands,
        source_text_unit_commands, source_text_layer_commands, source_alignment_commands, source_owner_profile_commands, source_owner_claim_commands,
        source_expression_commands, source_responsibility_commands, source_edition_commands, source_item_commands,
        source_collection_commands, source_artifact_commands, source_link_commands, source_public_native_commands,
        source_historical_claims)
        for handler in module.command_handlers()))
    schemas = [schema for handler in handlers for schema in handler.owner_schemas]
    if len(set(schemas)) != len(schemas) or len({handler.handler_id for handler in handlers}) != len(handlers):
        raise ValueError('source command handlers have ambiguous configuration dispatch')
    return handlers


def command_handler(owner_schema):
    if not isinstance(owner_schema, str):
        raise ValueError('source command owner schema must be an implemented string tag')
    selected = next((handler for handler in command_handlers() if owner_schema in handler.owner_schemas), None)
    if selected is None:
        raise ValueError('unknown source command owner schema')
    return selected


def discover_commands(request=None):
    """Implementation-only discovery: no configuration, target, source or clock IO."""
    if request is None:
        request = {'schema_version': DISCOVERY_REQUEST, 'operation': 'discover'}
    _keys(request, {'schema_version', 'operation'} | ({'handler_id'} if 'handler_id' in request else set()))
    if request['schema_version'] != DISCOVERY_REQUEST or request['operation'] != 'discover':
        raise ValueError('unknown source command discovery request')
    handlers = command_handlers()
    if 'handler_id' in request:
        if not isinstance(request['handler_id'], str):
            raise ValueError('discovery handler selector must be an exact implemented identity')
        handlers = tuple(handler for handler in handlers if handler.handler_id == request['handler_id'])
        if not handlers:
            raise ValueError('unknown source command discovery handler')
    return {'schema_version': DISCOVERY_RESULT, 'entrypoint':
        'mechanics/growth-cycle/parts/branch-growth-cycle/scripts/source_commands.py',
        'discovery_request': {'schema_version': DISCOVERY_REQUEST, 'operation': 'discover'},
        'posture': 'implemented_capabilities_not_authorized_now', 'authorization_status': 'not_evaluated',
        'grants_admission': False, 'reads_owner_configuration': False, 'reads_source_targets': False,
        'handler_count': len(handlers), 'handlers': [handler.public() for handler in handlers],
        'owner_handoffs': [
            {'capability': 'knowledge assessment', 'dispatched_here': False,
             'owner_route': 'mechanics/growth-cycle/parts/branch-growth-cycle/scripts/assessment_journal.py'},
            {'capability': 'semantic registry evolution', 'dispatched_here': False,
             'owner_route': 'ToS/doctrine/semantic-interchange/README.md',
             'validation_route': 'scripts/validate_semantic_registry_transition.py'},
            {'capability': 'read-only CLI HTTP WebMCP and native MCP access', 'dispatched_here': False,
             'owner_route': 'access/AGENTS.md'}]}


def main():
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    selection = parser.add_mutually_exclusive_group()
    selection.add_argument('--owner-config', type=Path)
    selection.add_argument('--discover', action='store_true', help='Emit handler-owned JSON capability grammar without reading stdin, owner configuration or source targets.')
    parser.add_argument('--native-invocation', type=Path, help='Explicit protected local native owner selection; see docs/RELEASING.md; never authority discovery.')
    parser.add_argument('--legacy-oracle', action='store_true', help='Explicit retained Python oracle for behavior not yet replaced; removed after its whole native consumer is accepted.')
    parser.add_argument('--handler', help='With --discover, select one exact handler_id from the implementation catalogue.')
    args = parser.parse_args()
    if args.handler is not None and not args.discover:
        parser.error('--handler requires --discover')
    if args.legacy_oracle and (args.discover or args.native_invocation is not None):
        parser.error('--legacy-oracle excludes discovery and native invocation')
    if args.native_invocation is not None and (args.discover or args.owner_config is None):
        parser.error('--native-invocation requires --owner-config and excludes --discover')
    try:
        if args.discover:
            response = discover_commands({'schema_version': DISCOVERY_REQUEST, 'operation': 'discover',
                                         **({'handler_id': args.handler} if args.handler is not None else {})})
        else:
            raw = sys.stdin.buffer.read(MAX_COMMAND_BYTES + 1)
            if len(raw) > MAX_COMMAND_BYTES:
                raise ValueError('source command exceeds the stdin budget')
            request = _json_object(raw)
            response = (run_legacy_oracle_command(args.owner_config, request) if args.legacy_oracle else
                        run_local_command(args.owner_config, request, native_invocation=args.native_invocation))
    except (ValueError, KeyError, TypeError, OSError, ValidationError, RuntimeError) as error:
        if args.native_invocation is not None:
            # This explicit local owner's stderr is diagnostic; the public
            # response keeps its existing error envelope and withholds content.
            print('selected native owner refused: ' + str(error), file=sys.stderr)
        print(json.dumps({'schema_version': 'tos_local_source_command_error_v1', 'error': type(error).__name__}))
        return 2
    print(json.dumps(response, ensure_ascii=False, allow_nan=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
