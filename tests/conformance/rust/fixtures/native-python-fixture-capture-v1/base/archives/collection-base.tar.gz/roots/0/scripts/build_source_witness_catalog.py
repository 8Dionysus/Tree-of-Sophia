#!/usr/bin/env python3
"""Build the tracked source-witness catalog from authored objects and claims."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any

from source_owner_context import OWNER_LOCAL_HOME
from source_metadata_snapshot import PublicationSnapshot, PublicationChanged, PublicationStateError

from jsonschema import Draft202012Validator, FormatChecker
from source_record_profiles import (SourceRecordProfiles, SourceClaimProfiles, SourceProfileError,
                                    SOURCE_CLAIM_BASENAME, METADATA_LINK_FIELDS, _read_json as _read_profile_json)


REPO_ROOT = Path(__file__).resolve().parents[1]
SOURCE_ROOT = Path("ToS/source-witnesses")
CATALOG_ROOT = SOURCE_ROOT / "catalog"
MANIFEST_PATH = CATALOG_ROOT / "catalog.manifest.json"
CLAIM_CATALOG_PATH = CATALOG_ROOT / "claims.jsonl"

RECORD_FILES = {
    "agent": "agents.jsonl",
    "place": "places.jsonl",
    "organization": "organizations.jsonl",
    "work": "works.jsonl",
    "expression": "expressions.jsonl",
    "edition": "editions.jsonl",
    "collection": "collections.jsonl",
    "item": "items.jsonl",
    "link": "links.jsonl",
}
OPTIONAL_RECORD_FILES = {
    "historical-event": "historical-events.jsonl",
    "historical-process": "historical-processes.jsonl",
    "historical-state": "historical-states.jsonl",
}
ADAPTED_RECORD_FILES = {"artifact": "artifacts.jsonl", "composite": "composites.jsonl"}
COMPOSITE_SCHEMA = 'ToS/contracts/scholarly-composite-witness.schema.json'
ARTIFACT_SCHEMAS = {
    'tos_artifact_source_witness_v1': 'ToS/contracts/artifact-source-witness.schema.json',
    'tos_artifact_source_witness_v2': 'ToS/contracts/artifact-source-witness-v2.schema.json',
}
SOURCE_BASENAMES = {
    record_type: f"{record_type}.json"
    for record_type in (*RECORD_FILES, *OPTIONAL_RECORD_FILES)
}
CLAIM_SOURCE_BASENAMES = (
    "membership-claims.jsonl",
    "responsibility-claims.jsonl",
    "publication-claims.jsonl",
    "provision-activity-claims.jsonl",
    "work-chronology-claims.jsonl",
    "work-expression-claims.jsonl",
    "expression-edition-claims.jsonl",
    "edition-item-claims.jsonl",
    "expression-derivation-claims.jsonl",
    "object-link-claims.jsonl",
    "historical-claims.jsonl",
)
TRACKED_CLAIM_VISIBILITIES = {"public_metadata_only", "public"}
LINK_FIELDS = METADATA_LINK_FIELDS


class CatalogBuildError(RuntimeError):
    pass


def verify_catalog_publication(manifest, publication_token, file_digests):
    """Check only the selected catalog bytes against their publication binding.

    This token covers participating selected-metadata transactions, not every
    editor or legacy writer. Source/schema and selected-record checks remain
    independently required. Missing new objects cannot hide behind old rows.
    """
    binding = manifest.get('selected_metadata_publication')
    if binding is None and publication_token is None:
        return
    if (not isinstance(binding, dict) or set(binding) != {'protocol', 'token', 'files'}
            or binding['protocol'] != 'tos_selected_source_metadata_v1'
            or binding['token'] != publication_token or not isinstance(binding['files'], dict)):
        raise PublicationChanged('catalog does not bind the current selected-metadata publication')
    expected_files = set(manifest.get('record_files', {}).values()) | {manifest.get('claim_file')}
    if set(binding['files']) != expected_files:
        raise CatalogBuildError('catalog publication file closure differs from its manifest')
    for ref, digest in file_digests.items():
        if binding['files'].get(str(ref)) != digest:
            raise PublicationChanged('selected catalog file differs from its committed manifest')


def native_witness_contract(payload: dict, relative: str) -> tuple[str, str, str]:
    """Resolve a native subject's exact owner path, schema and identity field.

    Callers retain their own protected byte-read, schema validation and digest
    checks. This descriptor supplies source-location metadata for those checks.
    """
    ref = Path(relative)
    composite = payload.get('schema_version') == 'tos_scholarly_composite_witness_v1'
    schema_ref = COMPOSITE_SCHEMA if composite else ARTIFACT_SCHEMAS.get(payload.get('schema_version'))
    subtree, basename, identity, kind = (
        ('scholarly-composites', 'composite-witness.json', 'composite_id', 'composite') if composite else
        ('artifacts', 'artifact-witness.json', 'artifact_id', 'artifact'))
    if (schema_ref is None or ref.is_absolute() or '..' in ref.parts or ref.as_posix() != relative
            or ref.name != basename or not ref.is_relative_to(SOURCE_ROOT / subtree)):
        raise ValueError('native witness schema and owner path do not agree')
    return schema_ref, identity, kind


def canonical_json(payload: object) -> str:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def render_native_catalog_entry(payload: dict, relative: str) -> dict:
    """Pure native Corpus/Link projection; callers own schema/source checks.

    This preserves the exact legacy full collector rendering. Profile adaptation
    and source admission remain caller responsibilities. Nested source values remain borrowed.
    """
    return {
        "schema_version": "tos_source_witness_catalog_entry_v1",
        "record_id": payload["record_id"],
        "record_type": payload["record_type"],
        "preferred_label": payload.get("preferred_label", ""),
        "identity_status": payload.get("identity_status", ""),
        "source_record_ref": relative,
        "record_sha256": hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest(),
        "links": {field: payload[field] for field in LINK_FIELDS if field in payload},
    }


def render_claim_catalog_entry(payload: dict, relative: str, line_number: int, *, source_schema_ref=None) -> dict:
    """Pure exact legacy Claim catalog row; validation and source reads stay outside."""
    entry = {
        'schema_version': 'tos_source_witness_claim_catalog_entry_v1',
        **({'source_schema_ref': 'ToS/contracts/historical-claim.schema.json'}
           if payload.get('schema_version') == 'tos_historical_claim_v1' else {}),
        **({'source_schema_ref': source_schema_ref} if source_schema_ref is not None else {}),
        **{field: payload.get(field) for field in (
            'claim_id', 'claim_type', 'assertion_layer', 'subject_ref', 'predicate', 'object',
            'evidence_refs', 'maker', 'provenance_event_ref', 'epistemic_status', 'review_status',
            'visibility', 'claim_version')},
        'review_refs': [review.get('review_id') for review in payload.get('reviews', [])
                        if isinstance(review, dict) and isinstance(review.get('review_id'), str)],
        'source_claim_file_ref': relative, 'source_claim_line': line_number,
        'claim_sha256': hashlib.sha256(canonical_json(payload).encode('utf-8')).hexdigest(),
    }
    for field in ('supersedes_claim_ref', 'qualifiers'):
        if field in payload:
            entry[field] = payload[field]
    return entry


def artifact_catalog_entry(repo_root: Path, payload: dict, relative: str,
                           validators: dict | None = None) -> dict:
    """Project native physical identity; never manufacture a Corpus record.

    Inventory wording supplies an attributed navigation label; title assessment
    retains its own source evidence.
    A missing identity assessment remains null rather than inferred from the
    legacy metadata review state. All native fields stay in the source record.
    """
    schema_ref = ARTIFACT_SCHEMAS.get(payload.get('schema_version'))
    if schema_ref is None:
        raise CatalogBuildError(f'{relative}: unsupported physical artifact source schema')
    validators = {} if validators is None else validators
    if schema_ref not in validators:
        schema = json.loads((repo_root / schema_ref).read_text(encoding='utf-8'))
        validators[schema_ref] = Draft202012Validator(schema, format_checker=FormatChecker())
    if not validators[schema_ref].is_valid(payload):
        raise CatalogBuildError(f'{relative}: invalid or nonpublic physical artifact metadata')
    return {
        'schema_version': 'tos_source_witness_catalog_entry_v1',
        'source_schema_ref': schema_ref,
        'record_id': payload['artifact_id'],
        'record_type': 'artifact',
        'preferred_label': payload['custody']['inventory_numbers'][0],
        'label_source_pointer': '/custody/inventory_numbers/0',
        'identity_status': None,
        'source_record_ref': relative,
        'record_sha256': hashlib.sha256(canonical_json(payload).encode('utf-8')).hexdigest(),
        'links': {},
    }


def load_artifact_record(repo_root: Path, relative: str) -> dict:
    """Bound a public metadata read to the physical-artifact owner subtree."""
    ref = Path(relative)
    if (ref.is_absolute() or '..' in ref.parts or ref.name != 'artifact-witness.json'
            or not ref.is_relative_to(SOURCE_ROOT / 'artifacts')):
        raise CatalogBuildError('physical artifact source path is outside its owner subtree')
    path = repo_root / ref
    if path.is_symlink() or not path.is_file() or path.resolve() != path.absolute():
        raise CatalogBuildError(f'{relative}: artifact source must be a regular non-symlink path')
    with path.open('rb') as handle:
        raw = handle.read(1_048_577)
    if len(raw) > 1_048_576:
        raise CatalogBuildError(f'{relative}: artifact metadata exceeds 1 MiB budget')
    try:
        payload = json.loads(raw)
    except (ValueError, UnicodeError) as exc:
        raise CatalogBuildError(f'{relative}: invalid physical artifact JSON') from exc
    if not isinstance(payload, dict):
        raise CatalogBuildError(f'{relative}: physical artifact record must be an object')
    return payload


def load_link_record(repo_root: Path, relative: str) -> dict:
    """Read only the exact public native Link shape, never a Corpus fallback."""
    ref = Path(relative)
    if (ref.is_absolute() or ref.as_posix() != relative or '..' in ref.parts or ref.name != 'link.json'
            or not ref.is_relative_to(SOURCE_ROOT / 'links')):
        raise CatalogBuildError('Link source path is outside its exact native owner')
    try:
        payload = _read_profile_json(repo_root, relative)
        schema_ref = 'ToS/contracts/source-link.schema.json'
        schema = _read_profile_json(repo_root, schema_ref)
        if schema.get('$id') != 'https://tree-of-sophia.local/' + schema_ref:
            raise CatalogBuildError('native Link schema has another owner identity')
        Draft202012Validator.check_schema(schema)
        if not Draft202012Validator(schema, format_checker=FormatChecker()).is_valid(payload):
            raise CatalogBuildError('Link source does not satisfy its exact native contract')
    except SourceProfileError as error:
        raise CatalogBuildError(str(error)) from error
    return payload


def artifact_display_fields(payload: dict) -> dict:
    """Exact field copies shared by the two readers of a validated artifact."""
    return {
        'description': payload['path_identity']['note'],
        'review_status': payload['authority']['review_status'],
        'visibility': payload['authority']['visibility'],
        'label_source_pointer': '/custody/inventory_numbers/0',
        'metadata_field_sources': {
            'preferred_label': '/custody/inventory_numbers/0',
            'description': '/path_identity/note',
            'review_status': '/authority/review_status',
            'visibility': '/authority/visibility',
        },
    }


def composite_catalog_entry(repo_root: Path, payload: dict, relative: str,
                            validators: dict | None = None) -> dict:
    """Return native scholarly identity without recasting it as an original.

    Member/coverage observations retain their exact source status. Relation
    acceptance and textual authority follow their corresponding review routes.
    """
    if payload.get('schema_version') != 'tos_scholarly_composite_witness_v1':
        raise CatalogBuildError(f'{relative}: unsupported scholarly composite source schema')
    validators = {} if validators is None else validators
    if COMPOSITE_SCHEMA not in validators:
        schema = json.loads((repo_root / COMPOSITE_SCHEMA).read_text(encoding='utf-8'))
        validators[COMPOSITE_SCHEMA] = Draft202012Validator(schema, format_checker=FormatChecker())
    if not validators[COMPOSITE_SCHEMA].is_valid(payload):
        raise CatalogBuildError(f'{relative}: invalid or nonpublic scholarly composite metadata')
    return {
        'schema_version': 'tos_source_witness_catalog_entry_v1',
        'source_schema_ref': COMPOSITE_SCHEMA,
        'record_id': payload['composite_id'],
        'record_type': 'composite',
        'preferred_label': payload['preferred_label'],
        'identity_status': payload['identity_status'],
        'source_record_ref': relative,
        'record_sha256': hashlib.sha256(canonical_json(payload).encode('utf-8')).hexdigest(),
        'links': {},
    }


def load_composite_record(repo_root: Path, relative: str) -> dict:
    """Bound a native metadata read to the scholarly-composite owner subtree."""
    ref = Path(relative)
    if (ref.is_absolute() or '..' in ref.parts or ref.as_posix() != relative
            or ref.name != 'composite-witness.json'
            or not ref.is_relative_to(SOURCE_ROOT / 'scholarly-composites')):
        raise CatalogBuildError('scholarly composite source path is outside its owner subtree')
    path = repo_root / ref
    if path.is_symlink() or not path.is_file() or path.resolve() != path.absolute():
        raise CatalogBuildError(f'{relative}: composite source must be a regular non-symlink path')
    with path.open('rb') as handle:
        raw = handle.read(1_048_577)
    if len(raw) > 1_048_576:
        raise CatalogBuildError(f'{relative}: composite metadata exceeds 1 MiB budget')
    def unique_object(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError('duplicate JSON field')
            result[key] = value
        return result
    def reject_nonfinite(value):
        raise ValueError('nonfinite JSON number')
    try:
        payload = json.loads(raw, object_pairs_hook=unique_object, parse_constant=reject_nonfinite)
        # Overflowing exponents can yield infinity without parse_constant.
        json.dumps(payload, allow_nan=False)
    except (ValueError, UnicodeError) as exc:
        raise CatalogBuildError(f'{relative}: invalid scholarly composite JSON') from exc
    if not isinstance(payload, dict):
        raise CatalogBuildError(f'{relative}: scholarly composite record must be an object')
    return payload


def composite_display_fields(payload: dict) -> dict:
    """Exact source fields, without guessed language or assessed human forms."""
    return {
        'description': payload['editorial_object']['description'],
        'review_status': payload['authority']['review_status'],
        'visibility': payload['authority']['visibility'],
        'metadata_field_sources': {
            'preferred_label': '/preferred_label',
            'description': '/editorial_object/description',
            'identity_status': '/identity_status',
            'review_status': '/authority/review_status',
            'visibility': '/authority/visibility',
        },
    }


def collect_records(repo_root: Path = REPO_ROOT, *, profiles: SourceRecordProfiles | None = None) -> dict[str, list[dict[str, Any]]]:
    try:
        publication = PublicationSnapshot(repo_root)
        result = _collect_records(repo_root, profiles=profiles)
        publication.verify_current()
        return result
    except SourceProfileError as exc:
        raise CatalogBuildError(str(exc)) from exc


def _collect_records(repo_root: Path, *, profiles: SourceRecordProfiles | None) -> dict[str, list[dict[str, Any]]]:
    source_root = repo_root / SOURCE_ROOT
    if profiles is not None and (type(profiles) is not SourceRecordProfiles or profiles.root.absolute() != repo_root.absolute()):
        raise CatalogBuildError('public catalog requires its exact public source-profile reader and owner root')
    profiles = profiles or SourceRecordProfiles(repo_root)
    basenames = {**{kind: kind + '.json' for kind in RECORD_FILES}, **profiles.source_basenames}
    records: dict[str, list[dict[str, Any]]] = {record_type: [] for record_type in basenames}
    seen_ids: dict[str, str] = {identity: 'native semantic packet'
                               for identity in profiles.native_semantic_identities()}

    for record_type, basename in basenames.items():
        for path in sorted(source_root.rglob(basename)):
            if CATALOG_ROOT in path.relative_to(repo_root).parents:
                continue
            relative = path.relative_to(repo_root).as_posix()
            try:
                payload = (profiles.load(record_type, relative) if record_type in profiles.profiles
                           else json.loads(path.read_text(encoding="utf-8")))
            except (OSError, json.JSONDecodeError) as exc:
                raise CatalogBuildError(f"{relative}: cannot read corpus record: {exc}") from exc
            if not isinstance(payload, dict):
                raise CatalogBuildError(f"{relative}: corpus record root must be an object")
            if payload.get("record_type") != record_type:
                raise CatalogBuildError(
                    f"{relative}: record_type must be {record_type!r} for {basename}"
                )
            record_id = payload.get("record_id")
            if not isinstance(record_id, str) or not record_id:
                raise CatalogBuildError(f"{relative}: missing record_id")
            if record_id in seen_ids:
                raise CatalogBuildError(
                    f"{relative}: duplicate record_id {record_id!r}; first seen at {seen_ids[record_id]}"
                )
            seen_ids[record_id] = relative

            records[record_type].append(
                profiles.catalog_entry(record_type, payload, relative) if record_type in profiles.profiles else
                render_native_catalog_entry(payload, relative)
            )

    artifacts, validators = [], {}
    for path in sorted((source_root / 'artifacts').rglob('artifact-witness.json')):
        relative = path.relative_to(repo_root).as_posix()
        payload = load_artifact_record(repo_root, relative)
        entry = artifact_catalog_entry(repo_root, payload, relative, validators)
        if entry['record_id'] in seen_ids:
            raise CatalogBuildError(f"{relative}: duplicate record_id {entry['record_id']!r}")
        seen_ids[entry['record_id']] = relative
        artifacts.append(entry)
    if artifacts:
        records['artifact'] = artifacts
    composites = []
    for path in sorted((source_root / 'scholarly-composites').rglob('composite-witness.json')):
        relative = path.relative_to(repo_root).as_posix()
        payload = load_composite_record(repo_root, relative)
        entry = composite_catalog_entry(repo_root, payload, relative, validators)
        if entry['record_id'] in seen_ids:
            raise CatalogBuildError(f"{relative}: duplicate record_id {entry['record_id']!r}")
        seen_ids[entry['record_id']] = relative
        composites.append(entry)
    if composites:
        records.setdefault('composite', []).extend(composites)
    for entries in records.values():
        entries.sort(key=lambda entry: entry["record_id"])
    return {kind: entries for kind, entries in records.items()
            if kind in RECORD_FILES or entries}


def collect_claims(repo_root: Path = REPO_ROOT, *, input_digests=None) -> list[dict[str, Any]]:
    try:
        publication = PublicationSnapshot(repo_root)
        result = _collect_claims(repo_root, input_digests=input_digests)
        publication.verify_current()
        return result
    except SourceProfileError as error:
        raise CatalogBuildError(str(error)) from error


def _collect_claims(repo_root: Path, *, input_digests=None) -> list[dict[str, Any]]:
    # Reject the reserved home before globbing or opening even a legacy Claim.
    # A broken directory alias is still a forbidden public/private ambiguity.
    if os.path.lexists(repo_root / OWNER_LOCAL_HOME):
        raise CatalogBuildError('reserved owner-local namespace cannot enter the public claim catalog')
    source_root = repo_root / SOURCE_ROOT
    claims: list[dict[str, Any]] = []
    seen_ids: dict[str, str] = {}
    profiles = None

    for basename in (*CLAIM_SOURCE_BASENAMES, SOURCE_CLAIM_BASENAME):
        for path in sorted(source_root.rglob(basename)):
            relative = path.relative_to(repo_root).as_posix()
            profiled = basename == SOURCE_CLAIM_BASENAME
            try:
                if profiled:
                    profiles = profiles or SourceClaimProfiles(repo_root)
                    rows = profiles.read_rows(relative)
                else:
                    rows = enumerate(path.read_text(encoding="utf-8").splitlines(), start=1)
            except OSError as exc:
                raise CatalogBuildError(
                    f"{relative}: cannot read claim packets: {exc}"
                ) from exc
            for line_number, raw_line in rows:
                if not profiled and not raw_line.strip():
                    continue
                location = f"{relative}:{line_number}"
                try:
                    payload = raw_line if profiled else json.loads(raw_line)
                except json.JSONDecodeError as exc:
                    raise CatalogBuildError(
                        f"{location}: cannot parse claim packet: {exc}"
                    ) from exc
                if not isinstance(payload, dict):
                    raise CatalogBuildError(
                        f"{location}: claim packet root must be an object"
                    )
                claim_id = payload.get("claim_id")
                if not isinstance(claim_id, str) or not claim_id:
                    raise CatalogBuildError(f"{location}: missing claim_id")
                if claim_id in seen_ids:
                    raise CatalogBuildError(
                        f"{location}: duplicate claim_id {claim_id!r}; "
                        f"first seen at {seen_ids[claim_id]}"
                    )
                seen_ids[claim_id] = location
                visibility = payload.get("visibility")
                if visibility not in TRACKED_CLAIM_VISIBILITIES:
                    raise CatalogBuildError(
                        f"{location}: visibility {visibility!r} is not safe "
                        "for the tracked claim catalog"
                    )

                entry = render_claim_catalog_entry(payload, relative, line_number,
                    source_schema_ref=(profiles.schema_routes[payload['predicate'], payload['schema_version']]['schema_ref']
                                       if profiled else None))
                claims.append(entry)

    if input_digests is not None and profiles is not None:
        input_digests.update(profiles.input_digests)
    claims.sort(key=lambda entry: entry["claim_id"])
    return claims


def render_outputs(repo_root: Path = REPO_ROOT) -> dict[Path, str]:
    publication = PublicationSnapshot(repo_root)
    profiles = SourceRecordProfiles(repo_root)
    records = collect_records(repo_root, profiles=profiles)
    claims = collect_claims(repo_root)
    outputs = render_catalog_rows(records, claims, profile_files=profiles.catalog_files,
                                  publication_token=publication.token)
    publication.verify_current()
    return outputs


def render_catalog_rows(records, claims, *, profile_files, publication_token) -> dict[Path, str]:
    """Pure legacy file rendering shared by full build and explicit bootstrap."""
    outputs: dict[Path, str] = {}
    digest_parts: list[str] = []

    record_files = {**RECORD_FILES, **{kind: filename for kind, filename in
                                    {**profile_files, **ADAPTED_RECORD_FILES}.items()
                                    if kind in records}}
    for record_type, filename in record_files.items():
        lines = [canonical_json(entry) for entry in records[record_type]]
        text = "\n".join(lines) + ("\n" if lines else "")
        relative = CATALOG_ROOT / filename
        outputs[relative] = text
        digest_parts.append(f"{record_type}\0{text}")

    claim_text = "\n".join(canonical_json(entry) for entry in claims)
    claim_text += "\n" if claim_text else ""
    outputs[CLAIM_CATALOG_PATH] = claim_text
    digest_parts.append(f"claim\0{claim_text}")

    counts = {record_type: len(entries) for record_type, entries in records.items()}
    counts["object_total"] = sum(counts.values())
    counts["claim"] = len(claims)
    counts["total"] = counts["object_total"] + counts["claim"]
    manifest = {
        "schema_version": "tos_source_witness_catalog_v3",
        "owner_repo": "Tree-of-Sophia",
        "source_root": SOURCE_ROOT.as_posix(),
        "generated_by": "scripts/build_source_witness_catalog.py",
        "record_schema_ref": "ToS/contracts/corpus-record.schema.json",
        "claim_schema_ref": "ToS/contracts/claim-packet.schema.json",
        **({'extension_schema_refs': sorted({entry['source_schema_ref']
                                            for entries in [*records.values(), claims] for entry in entries
                                            if 'source_schema_ref' in entry})}
           if any(kind in records for kind in (*profile_files, *ADAPTED_RECORD_FILES))
           or any('source_schema_ref' in entry for entry in claims) else {}),
        "record_files": {
            record_type: (CATALOG_ROOT / filename).as_posix()
            for record_type, filename in record_files.items()
        },
        "claim_file": CLAIM_CATALOG_PATH.as_posix(),
        "counts": counts,
        "catalog_sha256": hashlib.sha256("".join(digest_parts).encode("utf-8")).hexdigest(),
        **({'selected_metadata_publication': {
            'protocol': 'tos_selected_source_metadata_v1', 'token': publication_token,
            'files': {str(ref): hashlib.sha256(text.encode('utf-8')).hexdigest()
                      for ref, text in outputs.items()}}} if publication_token is not None else {}),
        "authority_boundary": (
            "This generated catalog provides navigation to the tracked object and claim records that own its contents."
        ),
    }
    outputs[MANIFEST_PATH] = json.dumps(manifest, ensure_ascii=False, indent=2) + "\n"
    return outputs


def write_outputs(repo_root: Path, outputs: dict[Path, str]) -> None:
    publication = PublicationSnapshot(repo_root)
    manifest = json.loads(outputs[MANIFEST_PATH])
    verify_catalog_publication(manifest, publication.token,
        {str(ref): hashlib.sha256(text.encode('utf-8')).hexdigest()
         for ref, text in outputs.items() if ref != MANIFEST_PATH})
    # Exact files become durable individually; the digest-bearing manifest is
    # the generated commit marker and is always replaced last. A concurrent
    # source transaction leaves an observably stale catalog, never new truth.
    for relative in sorted(outputs, key=lambda ref: (ref == MANIFEST_PATH, str(ref))):
        expected = outputs[relative]
        path = repo_root / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        if relative == MANIFEST_PATH:
            publication.verify_current()
        descriptor, staging = tempfile.mkstemp(prefix='.' + path.name + '.', suffix='.pending', dir=path.parent)
        try:
            with os.fdopen(descriptor, 'w', encoding='utf-8') as stream:
                stream.write(expected)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(staging, path)
            parent = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
            try:
                os.fsync(parent)
            finally:
                os.close(parent)
        finally:
            if os.path.exists(staging):
                os.unlink(staging)
    publication.verify_current()


def check_outputs(repo_root: Path, outputs: dict[Path, str]) -> list[str]:
    issues: list[str] = []
    for relative, expected in outputs.items():
        path = repo_root / relative
        try:
            actual = path.read_text(encoding="utf-8")
        except FileNotFoundError:
            issues.append(f"{relative.as_posix()}: generated catalog file is missing")
            continue
        if actual != expected:
            issues.append(f"{relative.as_posix()}: generated catalog is stale")
    return issues


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="check generated parity without writing")
    args = parser.parse_args()

    try:
        publication = PublicationSnapshot(REPO_ROOT)
        outputs = render_outputs(REPO_ROOT)
    except (CatalogBuildError, SourceProfileError, PublicationStateError) as exc:
        print(f"Source-witness catalog build failed: {exc}", file=sys.stderr)
        return 1

    if args.check:
        issues = check_outputs(REPO_ROOT, outputs)
        if issues:
            print("Source-witness catalog parity failed.", file=sys.stderr)
            for issue in issues:
                print(f"- {issue}", file=sys.stderr)
            return 1
        publication.verify_current()
        print("[ok] source-witness catalog matches authored object and claim records")
        return 0

    write_outputs(REPO_ROOT, outputs)
    publication.verify_current()
    print("[ok] generated source-witness object and claim catalog")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
