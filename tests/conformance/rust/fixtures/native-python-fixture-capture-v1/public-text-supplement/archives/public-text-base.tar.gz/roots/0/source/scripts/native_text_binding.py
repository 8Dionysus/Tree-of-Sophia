"""Bounded return from a description to native TextUnit/Anchor evidence.

The default read is metadata-only and works without local source text. Exact
resolution is explicit, reads one frozen UTF-8 representation without newline
or Unicode rewriting, and never returns its text. A caller must separately
hold authority to read private content. No mode admits a source, accepts a
segmentation, authenticates a producer, grants publication, or executes a
selector, model, command, URL or supplied code.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import stat
import unicodedata

from jsonschema import Draft202012Validator, FormatChecker
from jsonschema.exceptions import SchemaError
from referencing import Registry, Resource
from referencing.exceptions import Unresolvable


SOURCE_HOME = Path('ToS/source-witnesses')
CONTRACT_HOME = Path('ToS/contracts')
BINDING_SCHEMA = 'native-text-unit-binding.schema.json'
LAYER_BINDING_SCHEMA = 'native-text-layer-binding.schema.json'
ASSESSMENT_SCHEMA = 'native-text-unit-assessment-subject.schema.json'
MAX_METADATA_FILE_BYTES = 1_048_576
MAX_INPUT_FILES = 128


class NativeTextBindingError(ValueError):
    """A binding cannot resolve without widening or inventing its evidence."""


def check_local_research_rights(resolver, layer):
    """Recorded exact-layer use posture, not a fresh legal assessment.

    A narrower explicitly identified text layer can have a different posture
    from the aggregate scanned Item. A Work-wide positive statement alone
    cannot override that Item gate. Conditional use requires its own owner
    decision; this constructor does not guess that free-text terms were met.
    """
    rep = layer['representation']
    exact = {layer['layer_id'], rep['content_file_id']}
    records = [resolver._record(row['ref'], expected=row['sha256']) for row in rep['rights_record_refs']]
    decisions = []
    for row in records:
        if (row['review_status'] in {'superseded', 'legal_review_requested'}
                or row['assessment_status'] in {'permission_denied', 'conflicting_evidence'}):
            raise PermissionError('native derivation cannot reuse an inactive or denied rights record')
        exact_layers = [part for part in row.get('layer_assessments', []) if exact.intersection(part['scope_refs'])]
        if exact_layers:
            decisions.extend(exact_layers)
        elif exact.intersection(row['scope_refs']):
            decisions.append(row)
    decisions = decisions or records
    for decision in decisions:
        if (decision['derivative_posture'] not in {'local_research_only', 'allowed'}
                or decision['assessment_status'] in {'permission_denied', 'conflicting_evidence'}
                or decision['review_status'] in {'superseded', 'legal_review_requested'}):
            raise PermissionError('native derivation lacks a current unconditional local-research rights route')


def _hash(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _json(raw: bytes) -> dict:
    def pairs(items):
        value = {}
        for key, item in items:
            if key in value:
                raise NativeTextBindingError('native binding input has duplicate JSON fields')
            value[key] = item
        return value

    try:
        value = json.loads(raw.decode('utf-8'), object_pairs_hook=pairs)
        if not isinstance(value, dict):
            raise NativeTextBindingError('native binding input must be a JSON object')
        json.dumps(value, allow_nan=False)
        return value
    except (UnicodeError, ValueError, RecursionError) as error:
        raise NativeTextBindingError('native binding input is not bounded, finite UTF-8 JSON') from error


def _regular_bytes(path: Path, limit: int) -> bytes:
    """No-follow every ancestor, reject special files, detect in-place change.

    Source commands can instead supply their stricter local-account reader;
    this library does not infer write or account authority from readability.
    """
    descriptor = None
    try:
        descriptor = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
        for index, part in enumerate(path.parts[1:]):
            flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
            if index < len(path.parts) - 2:
                flags |= os.O_DIRECTORY
            child = os.open(part, flags, dir_fd=descriptor)
            os.close(descriptor)
            descriptor = child
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode):
            raise NativeTextBindingError('native binding input is not a regular file')
        with os.fdopen(descriptor, 'rb') as stream:
            descriptor = None
            raw = stream.read(limit + 1)
            after = os.fstat(stream.fileno())
        if (before.st_size, before.st_mtime_ns, before.st_ctime_ns) != (
                after.st_size, after.st_mtime_ns, after.st_ctime_ns):
            raise NativeTextBindingError('native binding input changed during read')
        return raw
    except OSError as error:
        # Paths, selectors and short-span hashes can be private source content.
        raise NativeTextBindingError('native binding input is missing, unsafe or unreadable') from error
    finally:
        if descriptor is not None:
            os.close(descriptor)


class NativeTextBindingResolver:
    """One explicit dependency snapshot, without scanning the corpus.

    Only schema digests are public. Native packet/anchor bodies, short-span
    hashes, content locators and rights inputs stay in the opaque snapshot.
    Observed dependencies are never refreshed midway through a command.
    """

    def __init__(self, root: Path, *, read_bytes=None, owner_context=None,
                 max_metadata_bytes=8_388_608, max_content_bytes=8_388_608):
        self.root = Path(root)
        if (not self.root.is_absolute() or '..' in self.root.parts
                or self.root == Path('/')):
            raise NativeTextBindingError('native binding needs an absolute dedicated source root')
        if (type(max_metadata_bytes) is not int or max_metadata_bytes < 1
                or type(max_content_bytes) is not int or max_content_bytes < 1):
            raise NativeTextBindingError('native binding budgets must be positive integers')
        self._reader = read_bytes or _regular_bytes
        self._budgets = {'metadata': max_metadata_bytes, 'content': max_content_bytes}
        self._remaining = dict(self._budgets)
        self._inputs = {}
        self._cache = {}
        self._validators = {}
        self.schema_digests = {}
        self._support_refs = set()
        self._owner_context = owner_context
        self._private_transport_used = False
        if owner_context is not None:
            from source_owner_context import OwnerLocalSourceContext, CONTEXT_SCHEMA_REF
            if not isinstance(owner_context, OwnerLocalSourceContext) or owner_context.public_root != self.root:
                raise NativeTextBindingError('native owner context belongs to another source/contract root')
            self._context_snapshot()
            self._read(CONTEXT_SCHEMA_REF, schema=True, expected=owner_context.contract_digest)

    def _context_snapshot(self):
        if self._owner_context is None:
            return None
        from source_owner_context import SourceOwnerContextError
        try:
            return self._owner_context.snapshot()
        except SourceOwnerContextError as error:
            raise NativeTextBindingError('native owner transport changed or became unsafe') from error

    def _path(self, ref: str, *, content=False, schema=False, support=False) -> Path:
        if not isinstance(ref, str) or not ref or '\x00' in ref or '\\' in ref:
            raise NativeTextBindingError('native binding reference is not a local owner path')
        path = Path(ref)
        if (path.is_absolute() or '..' in path.parts or path.as_posix() != ref
                or not path.is_relative_to(CONTRACT_HOME if schema else Path('ToS') if support else SOURCE_HOME)
                or 'catalog' in path.parts
                or (not content and any(part in {'payload', 'local-content'} for part in path.parts))):
            raise NativeTextBindingError('native binding reference escapes its declared owner home')
        from source_owner_context import OWNER_LOCAL_HOME, SourceOwnerContextError
        if self._owner_context is None:
            if path.is_relative_to(OWNER_LOCAL_HOME):
                raise NativeTextBindingError('native owner-local reference requires an explicit transport context')
            return self.root / path
        try:
            return self._owner_context.path(ref)
        except SourceOwnerContextError as error:
            raise NativeTextBindingError('native reference is outside the selected owner transport') from error

    def _transport_read(self, path, limit, reader):
        if self._owner_context is None:
            return reader(path, limit)
        from source_owner_context import SourceOwnerContextError
        try:
            return self._owner_context.read_bytes(path, limit, read_bytes=reader)
        except SourceOwnerContextError as error:
            raise NativeTextBindingError('native owner transport input is unsafe or changed') from error

    def _read(self, ref: str, *, expected=None, content=False, schema=False, support=False) -> bytes:
        path = self._path(ref, content=content, schema=schema, support=support)
        if support:
            self._support_refs.add(ref)
        category = 'content' if content else 'metadata'
        key = ref, category
        if key not in self._cache:
            if len(self._inputs) >= MAX_INPUT_FILES:
                raise NativeTextBindingError('native binding exceeds its dependency-count budget')
            limit = self._remaining[category]
            if not content:
                limit = min(limit, MAX_METADATA_FILE_BYTES)
            if limit < 0:
                raise NativeTextBindingError('native binding exceeds its input-byte budget')
            try:
                raw = self._transport_read(path, limit, self._reader)
            except (OSError, ValueError) as error:
                raise NativeTextBindingError('native binding input is missing, unsafe or changed') from error
            if not isinstance(raw, bytes) or len(raw) > limit:
                raise NativeTextBindingError('native binding exceeds its input-byte budget')
            self._remaining[category] -= len(raw)
            digest = _hash(raw)
            self._inputs[key] = digest
            self._cache[key] = raw
            if self._owner_context is not None and self._owner_context.role(ref) == 'owner-local-root':
                self._private_transport_used = True
        raw = self._cache[key]
        # One dependency can first be encountered as a fixed support record
        # and later as an actual grammar. Its roles do not depend on cache order.
        if schema:
            self.schema_digests[ref] = _hash(raw)
        if expected is not None and _hash(raw) != expected:
            raise NativeTextBindingError('native binding exact input digest differs')
        return raw

    def _record(self, ref, *, expected=None):
        return _json(self._read(ref, expected=expected))

    def _validate(self, value, schema_name):
        if schema_name not in self._validators:
            ref = (CONTRACT_HOME / schema_name).as_posix()
            schema = _json(self._read(ref, schema=True))
            if schema.get('$id') != 'https://tree-of-sophia.local/' + ref:
                raise NativeTextBindingError('native binding schema identity differs from its owner path')
            try:
                Draft202012Validator.check_schema(schema)
                # Most native contracts are self-contained. The assessment
                # view composes exactly two existing contracts, never a URL
                # selected by source material or by a changed schema.
                def reject_external(_uri):
                    raise NativeTextBindingError('native binding schema selects an undeclared resource')
                registry = Registry(retrieve=reject_external)
                if schema_name == ASSESSMENT_SCHEMA:
                    for name in (BINDING_SCHEMA, 'source-text-unit-packet-v1.schema.json'):
                        self._validate_schema_resource(name)
                        dependency = _json(self._read((CONTRACT_HOME / name).as_posix(), schema=True))
                        registry = registry.with_resource(dependency['$id'], Resource.from_contents(dependency))
                elif schema_name == 'native-page-ocr-comparison.schema.json':
                    name = 'native-text-layer-comparison.schema.json'
                    self._validate_schema_resource(name)
                    dependency = _json(self._read((CONTRACT_HOME / name).as_posix(), schema=True))
                    registry = registry.with_resource(dependency['$id'], Resource.from_contents(dependency))
                self._validators[schema_name] = Draft202012Validator(
                    schema, format_checker=FormatChecker(), registry=registry)
            except (ValueError, SchemaError) as error:
                raise NativeTextBindingError('native binding schema is invalid') from error
        try:
            if not self._validators[schema_name].is_valid(value):
                raise NativeTextBindingError('native binding violates its exact schema')
        except Unresolvable as error:
            raise NativeTextBindingError('native binding schema selects an undeclared resource') from error
        except RecursionError as error:
            raise NativeTextBindingError('native binding exceeds schema nesting limits') from error

    def _validate_schema_resource(self, name):
        ref = (CONTRACT_HOME / name).as_posix()
        value = _json(self._read(ref, schema=True))
        if value.get('$id') != 'https://tree-of-sophia.local/' + ref:
            raise NativeTextBindingError('native schema resource identity differs')
        Draft202012Validator.check_schema(value)

    def assessment_records(self, binding: dict, *, origin_id: str,
                           verify_content=False, allow_private_content=False) -> dict:
        """Adapt one native unit and its distinct layer for local assessment.

        The subject digest identifies this versioned view, NOT the raw unit
        or packet. Native IDs/versions stay intact. All native packet fields
        survive in the view; the layer is a separate evidence Record with the
        same origin, not an independent corroborating source. Nothing here is
        a public projection or permission to publish these private metadata.
        """
        if not isinstance(origin_id, str) or not origin_id.strip():
            raise NativeTextBindingError('native assessment needs an explicit evidence origin')
        summary = self.resolve(binding, verify_content=verify_content,
                               allow_private_content=allow_private_content)
        packet = self._record(binding['packet_ref'])
        layer = self._record(binding['text_layer']['record_ref'])
        canonical = lambda value: json.dumps(value, sort_keys=True, separators=(',', ':'),
                                             ensure_ascii=False, allow_nan=False).encode('utf-8')
        layer_ref = {'id': layer['layer_id'], 'version': layer['layer_version'],
                     'digest': 'sha256:' + _hash(canonical(layer))}
        # Load the view's public grammar before fixing its dependency closure.
        self._validate_schema_resource(ASSESSMENT_SCHEMA)
        payload = {'schema_version': 'tos_native_text_unit_assessment_subject_v1',
                   'native_binding': binding, 'packet': packet, 'text_layer': layer_ref,
                   'content_verified': summary['content_verified'], 'input_snapshot': self.snapshot()}
        self._validate(payload, ASSESSMENT_SCHEMA)
        if self.snapshot() != payload['input_snapshot']:
            raise NativeTextBindingError('native assessment view changed while being assembled')
        records = [{'id': binding['unit_id'], 'version': binding['unit_version'],
                    'payload': payload, 'origin_id': origin_id},
                   {'id': layer_ref['id'], 'version': layer_ref['version'],
                    'payload': layer, 'origin_id': origin_id}]
        if any(len(canonical(row['payload'])) > MAX_METADATA_FILE_BYTES for row in records):
            raise NativeTextBindingError('native assessment view exceeds the one-record byte budget')
        return {'records': records, 'summary': summary}

    def _source_scope(self, binding, scope, layer):
        """Validate current metadata topology, not historical or textual truth."""
        layer_scope = layer['source_binding']
        records = {}
        for kind, ref in binding['source_record_refs'].items():
            if Path(ref).name != kind + '.json':
                raise NativeTextBindingError('native source-scope locator has another metadata kind')
            record = self._record(ref)
            self._validate(record, 'corpus-record.schema.json')
            if (record.get('record_type') != kind or record.get('record_id') != scope[kind + '_ref']
                    or layer_scope[kind + '_ref'] != scope[kind + '_ref']):
                raise NativeTextBindingError('native source-scope identity differs')
            records[kind] = record
        if (records['expression'].get('work_ref') != scope['work_ref']
                or scope['expression_ref'] not in records['edition'].get('embodies_expression_refs', [])):
            raise NativeTextBindingError('native source-scope bibliographic topology differs')
        item = records['item']
        manifest_ref = item.get('item_manifest_ref')
        if (not isinstance(manifest_ref, str)
                or Path(manifest_ref).parent != Path(binding['source_record_refs']['item']).parent
                or Path(manifest_ref).name != 'item.manifest.json'):
            raise NativeTextBindingError('native source-scope manifest leaves its exact item')
        manifest = self._record(manifest_ref)
        self._validate(manifest, 'source-item-manifest.schema.json')
        if (manifest['item_id'] != scope['item_ref']
                or manifest['embodiment_ref'] != scope['edition_ref']
                or layer_scope['source_file_ref'] != scope['file_ref']
                or layer_scope['source_file_sha256'] != scope['file_sha256']):
            raise NativeTextBindingError('native source-scope item/file binding differs')
        matches = [entry for entry in manifest['payload_files'] if entry['file_id'] == scope['file_ref']]
        if len(matches) != 1 or matches[0]['sha256'] != scope['file_sha256']:
            raise NativeTextBindingError('native source file is not uniquely present in its item manifest')
        return manifest

    def resolve_layer(self, binding: dict, *, verify_content=False, allow_private_content=False):
        """Resolve a real layer without inventing a predecessor TextUnit.

        This private construction input is not an assessment target or a
        public-content route. Rights are checked before representation I/O.
        """
        if type(verify_content) is not bool or type(allow_private_content) is not bool:
            raise NativeTextBindingError('native content-read controls must be explicit booleans')
        self._validate(binding, LAYER_BINDING_SCHEMA)
        target = binding['text_layer']
        layer = self._record(target['record_ref'], expected=target['record_sha256'])
        self._validate(layer, 'source-text-layer.schema.json')
        if layer['layer_id'] != target['layer_id'] or layer['layer_version'] != target['layer_version']:
            raise NativeTextBindingError('native text-layer identity/version differs')
        self._layer_dependencies(layer, record_ref=target['record_ref'])
        source = layer['source_binding']
        scope = {key: source[key] for key in ('work_ref', 'expression_ref', 'edition_ref', 'item_ref')}
        scope.update(file_ref=source['source_file_ref'], file_sha256=source['source_file_sha256'])
        manifest = self._source_scope(binding, scope, layer)
        rep = layer['representation']
        if (rep['media_type'] not in {'text/plain', 'text/plain; charset=utf-8'}
                or rep['content_file_id'] != 'tos.file.sha256.' + rep['content_sha256']):
            raise NativeTextBindingError('native construction needs an exact UTF-8 representation File')
        from validate_source_witness_foundation import _anchor_v2_semantic_issues
        for entry in source['anchors']:
            anchor = self._record(entry['anchor_record_ref'], expected=entry['anchor_record_sha256'])
            self._validate(anchor, 'source-anchor-v2.schema.json')
            if (anchor['anchor_id'] != entry['anchor_id']
                    or anchor['target']['item_id'] != scope['item_ref']
                    or anchor['target']['file_id'] != scope['file_ref']
                    or anchor['target']['file_sha256'] != scope['file_sha256']
                    or _anchor_v2_semantic_issues(anchor)):
                raise NativeTextBindingError('native layer source-anchor closure differs')
        rights = {entry['ref'] for entry in rep['rights_record_refs']}
        if not rights or manifest['rights_ref'] not in rights:
            raise NativeTextBindingError('native layer omits its exact Item rights')
        relevant = {layer['layer_id'], rep['content_file_id'], *(v for k, v in scope.items() if k.endswith('_ref'))}
        for entry in rep['rights_record_refs']:
            record = self._record(entry['ref'], expected=entry['sha256'])
            self._validate(record, 'rights-record.schema.json')
            if (not relevant.intersection(record['scope_refs'])
                    or entry['ref'] == manifest['rights_ref']
                    and not {scope['item_ref'], scope['file_ref']}.issubset(record['scope_refs'])):
                raise NativeTextBindingError('native layer rights address a different source')
        check_local_research_rights(self, layer)
        for entry in rep['publication_authority_refs']:
            self._read(entry['ref'], expected=entry['sha256'], support=True)
        self._path(rep['content_ref'], content=True)
        if verify_content:
            if allow_private_content is not True:
                raise NativeTextBindingError('layer construction requires explicit exact private reading')
            raw = self._read(rep['content_ref'], expected=rep['content_sha256'], content=True)
            try:
                text = raw.decode('utf-8')
            except UnicodeError as error:
                raise NativeTextBindingError('native layer is not exact UTF-8') from error
            span = rep['text_scope']
            if not 0 <= span['start'] < span['end'] <= len(text):
                raise NativeTextBindingError('native layer scope leaves its exact representation')
            form = rep['character_normalization']
            if form != 'none' and unicodedata.normalize(form, text[span['start']:span['end']]) != text[span['start']:span['end']]:
                raise NativeTextBindingError('native layer contradicts its declared Unicode form')
            self._derived_content(layer, text)
        self.snapshot()
        return {'metadata_verified': True, 'content_verified': verify_content,
                'public_content_declared': False, 'assessment_applied': False,
                'input_mode': 'exact_layer_first_segmentation'}

    def _layer_dependencies(self, layer, *, visiting=frozenset(), record_ref=None):
        """Retain fixed predecessor and policy bytes, without replaying OCR.

        Returning to immutable input records is not proof that the recorded
        transformation occurred or that its output is a faithful transcription.
        """
        from validate_source_witness_foundation import _source_text_layer_semantic_issues
        if layer['layer_id'] in visiting or len(visiting) >= 16:
            raise NativeTextBindingError('native text-layer lineage is cyclic or exceeds its depth budget')
        if _source_text_layer_semantic_issues(layer):
            raise NativeTextBindingError('native predecessor layer violates its evidence contract')
        policy = layer['editorial_policy']
        self._read(policy['policy_ref'], expected=policy['policy_sha256'], support=True)
        maker = layer['derivation']['maker']
        configuration = None
        if maker.get('configuration_ref') is not None:
            raw = self._read(maker['configuration_ref'], expected=maker['configuration_digest'], support=True)
            # Configuration bytes may be non-JSON for older source methods.
            # Only the explicitly versioned native command has this adapter.
            if raw.lstrip().startswith(b'{'):
                try:
                    configuration = _json(raw)
                except NativeTextBindingError:
                    pass  # Older methods may bind opaque, non-JSON bytes.
        previous_layers = []
        for target in layer['derivation']['input_layers']:
            previous = self._record(target['record_ref'], expected=target['record_sha256'])
            self._validate(previous, 'source-text-layer.schema.json')
            if (previous['layer_id'] != target['layer_id']
                    or previous['representation']['content_sha256'] != target['content_sha256']):
                raise NativeTextBindingError('native predecessor identity or content binding differs')
            previous_layers.append(previous)
            self._layer_dependencies(previous, visiting=visiting | {layer['layer_id']}, record_ref=target['record_ref'])
        if configuration is not None and configuration.get('schema_version') in {
                'tos_local_text_layer_record_owner_ocr_v1', 'tos_local_text_layer_record_owner_page_ocr_v1'}:
            raise NativeTextBindingError('owner OCR metadata requires the maintained native Rust consumer')
        if configuration is not None and configuration.get('schema_version') == 'tos_local_text_layer_derive_owner_v1':
            self._derived_metadata(layer, configuration, previous_layers, record_ref=record_ref)

    def _derived_metadata(self, layer, config, previous_layers, *, record_ref=None):
        """Native exact lineage, without requiring a still-active write grant.

        Historical policy/configuration remains readable across implementation
        upgrades. This does not replay a reported OCR provider or adopt quality.
        """
        from source_text_layer_proposal import DERIVE_OPERATIONS
        try:
            operation = config['allowed_operations'][0]
            observed = False
            operations = DERIVE_OPERATIONS
            rep, derivation, maker = layer['representation'], layer['derivation'], layer['derivation']['maker']
            base = Path(config['source_path']).parent
            policy = self._record(layer['editorial_policy']['policy_ref'], expected=layer['editorial_policy']['policy_sha256'])
            scope = layer['source_binding']
            exact_scope = {key: scope[key] for key in ('work_ref', 'expression_ref', 'edition_ref', 'item_ref')}
            exact_scope.update(file_ref=scope['source_file_ref'], file_sha256=scope['source_file_sha256'])
            role = ('normalized_text' if operation == 'text-layer.normalize' else 'raw_ocr' if operation == 'text-layer.record-ocr'
                    else 'machine_transcription' if derivation['method'] == 'model_transcription' else 'diplomatic_transcription')
            if (config['allowed_operations'] != [operation] or operation not in operations
                    or config['schema_version'] != 'tos_local_text_layer_derive_owner_v1'
                    or record_ref is not None and config['source_path'] != record_ref
                    or config['source_scope'] != exact_scope or config['identities']['layer_id'] != layer['layer_id']
                    or config['identities']['provenance_event_id'] != layer['provenance_event_ref']
                    or derivation['method'] not in ({'manual_transcription', 'model_transcription'} if operation == 'text-layer.record-transcription' else {operations[operation]})
                    or config['policy'] != policy
                    or policy['schema_version'] != 'tos_native_text_layer_derivation_policy_v1'
                    or policy['operation'] != operation or policy['method'] != derivation['method']
                    or policy['provider_execution_verified'] is not observed or policy['inherited_quality'] != 'not-transferred'
                    or layer['layer_role'] != role
                    or config['language'] != rep['language'] or rep['content_ref'] != (base / 'content.txt').as_posix()
                    or rep['character_normalization'] != policy['unicode_normalization']
                    or maker['configuration_ref'] != (base / 'source-create-owner-configuration.json').as_posix()
                    or {key: maker[key] for key in ('maker_type', 'agent_ref', 'method', 'version')} != config['maker']
                    or rep['rights_record_refs'] != config['derivation_access']['rights_record_refs']):
                raise NativeTextBindingError('native derived layer differs from its retained exact configuration')
            if operation in {'text-layer.correct', 'text-layer.normalize'}:
                target = config['input']['binding']['text_layer']
                if len(previous_layers) != 1:
                    raise NativeTextBindingError('native derived layer requires one exact predecessor')
                previous = previous_layers[0]
                expected = {key: target[key] for key in ('layer_id', 'record_ref', 'record_sha256')}
                expected['content_sha256'] = previous['representation']['content_sha256']
                if (derivation['input_layers'] != [expected] or previous['layer_version'] != target['layer_version']
                        or previous['source_binding'] != scope or previous['representation']['language'] != rep['language']
                        or layer['supersedes_layer_ref'] != previous['layer_id']
                        or layer['layer_version'] != previous['layer_version'] + 1
                        or config['input']['binding']['source_record_refs'] != config['source_record_refs']):
                    raise NativeTextBindingError('native derived predecessor version, lineage or source scope differs')
                if operation == 'text-layer.correct' and (previous['layer_role'] == 'normalized_text'
                        or previous['representation']['character_normalization'] != 'none'):
                    raise NativeTextBindingError('native source-near correction cannot erase predecessor normalization')
            else:
                target = config['input']['anchor']
                if (previous_layers or layer['layer_version'] != 1 or layer['supersedes_layer_ref'] is not None
                        or scope['anchors'] != [{'anchor_id': target['anchor_id'], 'anchor_record_ref': target['record_ref'],
                                                 'anchor_record_sha256': target['record_sha256']}]
                        or not observed and config['material']['provider_execution'] != 'not_observed'
                        or rep['content_sha256'] != config['material']['content_sha256']):
                    raise NativeTextBindingError('native supplied result differs from its exact source/byte declaration')
        except (KeyError, TypeError, IndexError) as error:
            raise NativeTextBindingError('native derived layer has malformed retained configuration') from error

    def _derived_content(self, layer, text):
        """Independently replay explicit deltas, not a historical provider/runtime."""
        maker = layer['derivation']['maker']
        if maker.get('configuration_ref') is None:
            return
        raw = self._read(maker['configuration_ref'], expected=maker['configuration_digest'], support=True)
        if not raw.lstrip().startswith(b'{'):
            return
        try:
            config = _json(raw)
        except NativeTextBindingError:
            return  # Opaque legacy method configuration, not this adapter.
        if config.get('schema_version') != 'tos_local_text_layer_derive_owner_v1':
            return
        from source_text_layer_proposal import MAX_DERIVED_TEXT_BYTES, MAX_EDITS
        rep = layer['representation']
        if len(text.encode('utf-8')) > MAX_DERIVED_TEXT_BYTES or rep['text_scope']['start'] != 0 or rep['text_scope']['end'] != len(text):
            raise NativeTextBindingError('native derived content exceeds its whole-representation profile')
        operation = config['allowed_operations'][0]
        if operation not in {'text-layer.correct', 'text-layer.normalize'}:
            if len(text.encode('utf-8')) != config['material']['byte_size']:
                raise NativeTextBindingError('native supplied result size differs from its retained input')
            return
        binding = config['input']['binding']
        # This verifies independent predecessor rights before its bytes, while
        # never inheriting a verdict or granting access to the original File.
        self.resolve_layer(binding, verify_content=False)
        previous = self._record(binding['text_layer']['record_ref'], expected=binding['text_layer']['record_sha256'])
        prior = previous['representation']
        if config['source_access']['byte_size'] > MAX_DERIVED_TEXT_BYTES:
            raise NativeTextBindingError('native predecessor exceeds the bounded transformation profile')
        previous_raw = self._read(prior['content_ref'], expected=prior['content_sha256'], content=True)
        if len(previous_raw) != config['source_access']['byte_size']:
            raise NativeTextBindingError('native predecessor size differs from its retained input')
        try:
            previous_text = previous_raw.decode('utf-8')
            changes = layer['derivation']['change_payload']
            if changes['kind'] != 'explicit_operations' or not 1 <= len(changes['operations']) <= MAX_EDITS:
                raise NativeTextBindingError('native derived changes leave the exact explicit operation profile')
            from validate_source_witness_foundation import _replay_source_text_layer_edits
            _replay_source_text_layer_edits(previous_text, text, changes['operations'])
        except (ValueError, KeyError, TypeError) as error:
            raise NativeTextBindingError('native derived edit evidence does not replay against exact predecessor bytes') from error

    def resolve(self, binding: dict, *, verify_content=False, allow_private_content=False) -> dict:
        if type(verify_content) is not bool or type(allow_private_content) is not bool:
            raise NativeTextBindingError('native content-read controls must be explicit booleans')
        self._validate(binding, BINDING_SCHEMA)
        packet = self._record(binding['packet_ref'], expected=binding['packet_sha256'])
        self._validate(packet, 'source-text-unit-packet-v1.schema.json')
        if (packet['content_posture'] != 'source_bound'
                or packet['packet_id'] != binding['packet_id']
                or packet['packet_version'] != binding['packet_version']):
            raise NativeTextBindingError('native packet identity/version or source posture differs')
        layer_binding = binding['text_layer']
        if packet['source_layer']['text_layer_ref'] != layer_binding['record_ref']:
            raise NativeTextBindingError('native packet addresses another text-layer record')
        layer = self._record(layer_binding['record_ref'], expected=layer_binding['record_sha256'])
        self._validate(layer, 'source-text-layer.schema.json')
        if (layer['layer_id'] != layer_binding['layer_id']
                or layer['layer_version'] != layer_binding['layer_version']):
            raise NativeTextBindingError('native text-layer identity/version differs')

        # Reuse the source owner's pure mechanics; never its laboratory reads.
        from validate_source_witness_foundation import (
            _anchor_v2_semantic_issues, _source_text_layer_semantic_issues,
            _source_text_unit_v1_issues,
        )
        if (_source_text_unit_v1_issues(packet)
                or _source_text_layer_semantic_issues(layer)):
            raise NativeTextBindingError('native packet or layer violates its internal evidence contract')
        self._layer_dependencies(layer, record_ref=layer_binding['record_ref'])
        manifestation = self._source_scope(binding, packet['source_scope'], layer)
        rep = layer['representation']
        packet_layer = packet['source_layer']
        unicode_form = {'none': 'source_preserved'}.get(rep['character_normalization'], rep['character_normalization'])
        if (packet_layer['text_layer_sha256'] != rep['content_sha256']
                or packet_layer['language'] != rep['language']
                or packet_layer['unicode_form'] != unicode_form
                or packet_layer['visibility'] != rep['content_visibility']
                or packet_layer['publication_authorized'] != rep['publication_authorized']
                or rep['media_type'] not in {'text/plain', 'text/plain; charset=utf-8'}):
            raise NativeTextBindingError('native packet and UTF-8 layer declarations differ')
        scope = rep['text_scope']
        for anchor in packet['anchors']:
            if (anchor['source_return']['locator_ref'] != rep['content_ref']
                    or not scope['start'] <= anchor['selector']['start'] <= anchor['selector']['end'] <= scope['end']):
                raise NativeTextBindingError('native unit anchor leaves the exact representation scope')

        for target in layer['source_binding']['anchors']:
            anchor = self._record(target['anchor_record_ref'], expected=target['anchor_record_sha256'])
            self._validate(anchor, 'source-anchor-v2.schema.json')
            if (anchor['anchor_id'] != target['anchor_id']
                    or anchor['target']['item_id'] != packet['source_scope']['item_ref']
                    or anchor['target']['file_id'] != packet['source_scope']['file_ref']
                    or anchor['target']['file_sha256'] != packet['source_scope']['file_sha256']
                    or _anchor_v2_semantic_issues(anchor)):
                raise NativeTextBindingError('native text-layer source-anchor binding differs')
        # Rights records are fixed inputs, not new rights judgments. The exact
        # Item/File gate remains separate from a narrower textual-layer gate.
        rights_refs = set(packet['rights_and_visibility']['rights_record_refs'])
        declared_rights = {entry['ref'] for entry in rep['rights_record_refs']}
        if (not declared_rights or rights_refs != declared_rights
                or manifestation['rights_ref'] not in declared_rights):
            raise NativeTextBindingError('native packet/layer rights closure differs')
        relevant = {layer['layer_id'], rep['content_file_id'],
                    *(value for key, value in packet['source_scope'].items() if key.endswith('_ref'))}
        rights_records = []
        for target in rep['rights_record_refs']:
            rights = self._record(target['ref'], expected=target['sha256'])
            self._validate(rights, 'rights-record.schema.json')
            if not relevant.intersection(rights['scope_refs']):
                raise NativeTextBindingError('native rights record addresses a different source')
            if target['ref'] == manifestation['rights_ref'] and not {
                    packet['source_scope']['item_ref'], packet['source_scope']['file_ref']
                    }.issubset(rights['scope_refs']):
                raise NativeTextBindingError('native item rights do not cover the exact item and file')
            rights_records.append(rights)
        for target in rep['publication_authority_refs']:
            self._read(target['ref'], expected=target['sha256'], support=True)

        units = [unit for unit in packet['units'] if unit['unit_id'] == binding['unit_id']]
        segments = [segment for segment in packet['segmentations']
                    if segment['segmentation_id'] == binding['segmentation_id']]
        if len(units) != 1 or len(segments) != 1:
            raise NativeTextBindingError('native unit or segmentation identity is not unique in its packet')
        unit, segment = units[0], segments[0]
        if (unit['unit_version'] != binding['unit_version']
                or unit['ordered_anchor_refs'] != binding['ordered_anchor_refs']
                or unit['surface_posture'] != 'source_bearing'
                or segment['segmentation_version'] != binding['segmentation_version']
                or unit['unit_id'] not in segment['ordered_unit_refs']):
            raise NativeTextBindingError('native unit membership, version or ordered anchors differ')

        rights = packet['rights_and_visibility']
        declared_public = (rep['content_visibility'] == 'public'
            and rep['publication_authorized'] is True
            and rights['packet_visibility'] == rights['effective_visibility'] == 'public'
            and rights['publication_authorized'] is True and rights['private_source_used'] is False)
        if declared_public:
            # Exact layer/file decisions may be narrower than the original
            # Item's aggregate gate. A positive original-Work entry alone is
            # not such a decision. This checks recorded gates, not legal truth.
            exact_scope = {layer['layer_id'], rep['content_file_id']}
            applicable = [record for record in rights_records if exact_scope.intersection(record['scope_refs'])]
            applicable = applicable or rights_records
            if any(record['assessment_status'] not in {'public_domain_reviewed', 'licensed', 'permission_granted'}
                    or record['visibility'] != 'public_payload'
                    or record['redistribution_posture'] not in {'authorized', 'authorized_with_conditions'}
                    or record['derivative_posture'] not in {'allowed', 'allowed_with_conditions'}
                    or record['review_status'] in {'legal_review_requested', 'superseded'}
                    for record in applicable):
                raise NativeTextBindingError('native public-content declaration conflicts with its current rights gate')
        # A metadata-only read must not advertise a source address that this
        # transport cannot resolve. Validate the route without opening bytes.
        self._path(rep['content_ref'], content=True)
        if self._owner_context is not None and self._owner_context.role(rep['content_ref']) == 'owner-local-root':
            self._private_transport_used = True
        public_binding = declared_public and not self._private_transport_used
        if verify_content:
            if not public_binding and not allow_private_content:
                raise NativeTextBindingError('exact private text resolution requires explicit owner-local access')
            raw = self._read(rep['content_ref'], expected=rep['content_sha256'], content=True)
            try:
                text = raw.decode('utf-8')
            except UnicodeError as error:
                raise NativeTextBindingError('native text representation is not exact UTF-8') from error
            if not 0 <= scope['start'] <= scope['end'] <= len(text):
                raise NativeTextBindingError('native text-layer scope leaves the exact content')
            selected = text[scope['start']:scope['end']]
            if unicode_form in {'NFC', 'NFD', 'NFKC', 'NFKD'} and unicodedata.normalize(unicode_form, selected) != selected:
                raise NativeTextBindingError('native text contradicts its declared Unicode form')
            if _source_text_unit_v1_issues(packet, text=text):
                raise NativeTextBindingError('native unit anchors or coverage do not resolve exact bytes')
            self._derived_content(layer, text)
        # A cached resolver must not return a stale successful validation. A
        # command still rechecks this opaque snapshot at its publication edge.
        self.snapshot()
        return {
            'metadata_verified': True, 'content_verified': bool(verify_content),
            'original_payload_verified': False,
            'unit_id': unit['unit_id'], 'unit_version': unit['unit_version'],
            'unit_kind': unit['unit_kind'], 'segmentation_id': segment['segmentation_id'],
            'segmentation_version': segment['segmentation_version'],
            'layer_id': layer['layer_id'], 'layer_version': layer['layer_version'],
            'language': rep['language'], 'effective_visibility': (
                'local_only' if self._private_transport_used
                and rights['effective_visibility'] in {'public', 'public_metadata_only', 'controlled'}
                else rights['effective_visibility']),
            'public_content_declared': bool(public_binding),
            'public_content_available': bool(verify_content and public_binding),
            **({'owner_local_transport': self._private_transport_used} if self._owner_context is not None else {}),
            'native_status': {'unit_boundary_posture': unit['boundary_posture'],
                              'segmentation_status': segment['status'],
                              'layer_review_status': layer['admission']['review_status']},
            'assessment_applied': False,
        }

    def snapshot(self, *, read_bytes=None) -> str:
        """Recheck the exact closure; expose only an opaque fingerprint."""
        reader = read_bytes or self._reader
        context = self._context_snapshot()
        remaining = dict(self._budgets)
        for (ref, category), digest in sorted(self._inputs.items()):
            limit = remaining[category]
            if category != 'content':
                limit = min(limit, MAX_METADATA_FILE_BYTES)
            try:
                raw = self._transport_read(self._path(ref, content=category == 'content',
                            schema=ref in self.schema_digests, support=ref in self._support_refs), limit, reader)
            except (OSError, ValueError) as error:
                raise NativeTextBindingError('native binding dependency changed or became unreadable') from error
            if not isinstance(raw, bytes) or len(raw) > limit or _hash(raw) != digest:
                raise NativeTextBindingError('native binding dependency changed after resolution')
            remaining[category] -= len(raw)
        value = [[ref, category, digest] for (ref, category), digest in sorted(self._inputs.items())]
        if context is not None:
            if self._context_snapshot() != context:
                raise NativeTextBindingError('native owner transport changed during dependency recheck')
            value = {'owner_context': context, 'inputs': [
                [ref, category, self._owner_context.role(ref), digest]
                for (ref, category), digest in sorted(self._inputs.items())]}
        return 'sha256:' + _hash(json.dumps(value, separators=(',', ':'), ensure_ascii=True).encode())
